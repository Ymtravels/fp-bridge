// Assisted booking driver (ISOLATED world) for Smiles.
//  • Passenger page: a panel to fill the form (name, DOB, passport, email, phone, nationality).
//  • Auto-drive: once you've picked a fare, it agrees the terms + clicks Continuar, fills the
//    passenger + clicks Continuar, and STOPS at checkout for you (password + captcha + card).
// Nothing here submits payment. Later the passenger data is fed from the customer's order.
(function () {
  'use strict';
  const VER = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '?';
  const KEY = 'ymBookPax';       // passenger details
  const DRIVE = 'ymAutoDrive';   // { on, startedAt }
  const TARGET = 'ymBookTarget'; // { origin, destination, dep, cabin, miles:[club, std], summary } from the app's Book button
  const FIELDS = ['first', 'last', 'dob', 'passport', 'passportExp', 'email', 'ccode', 'area', 'phone'];
  const onEmission = () => /\/emission/.test(location.pathname);
  const onPax = () => /\/emission\/passenger-data/.test(location.pathname);
  const onCheckout = () => /\/emission\/checkout/.test(location.pathname);
  const q = (s) => document.querySelector(s);

  function setVal(el, val) {
    if (!el) return false;
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  function fillForm(d) {
    setVal(q('#firstName'), d.first || '');
    setVal(q('#lastName'), d.last || '');
    const nat = q('select[name="nationality"]');
    if (nat && d.nationality) setVal(nat, d.nationality);
    if (d.gender) { const g = /^f/i.test(d.gender) ? q('#female0') : q('#male0'); if (g) g.click(); }
    setVal(q('#birthday-0'), d.dob || '');
    setVal(q('#passport'), d.passport || '');
    setVal(q('#passportValidity0'), d.passportExp || '');
    setVal(q('#email'), d.email || '');
    setVal(q('#movilddi'), d.ccode || '54');
    setVal(q('#movilddd'), d.area || '');
    setVal(q('#movilnumber'), d.phone || '');
    flash('Filled ✓');
  }

  let statusEl = null, driveStatusEl = null, driveBtn = null;
  let lastTargetSeen = null;   // most recent target read in driveTick (for the diagnostic dump)
  function flash(m) { if (statusEl) statusEl.textContent = m; if (driveStatusEl) driveStatusEl.textContent = m; }

  // Which flight row does this fare label belong to? = the nearest ancestor holding exactly ONE
  // #flight-SEGMENT. Returns that segment element (or null if the label isn't inside a flight card).
  function segOfFare(lab) {
    let a = lab.parentElement;
    for (let k = 0; k < 12 && a; k++) {
      const s = a.querySelectorAll('[id^="flight-SEGMENT"]');
      if (s.length === 1) return s[0];
      if (s.length > 1) return null;
      a = a.parentElement;
    }
    return null;
  }
  const visFares = () => [...document.querySelectorAll('label.form-check-label')].filter(l => l.offsetParent && /tasas|millas/i.test(l.innerText || ''));

  // Diagnostic: dump the results-page structure (flight cards + fare labels) so we can see exactly
  // what's on the page when the fare-select gets stuck.
  function dumpFareInfo() {
    const info = { v: VER, url: location.href.replace(/[?#].*/, ''), title: (document.title || '').slice(0, 80), path: location.pathname };
    const segs = [...document.querySelectorAll('[id^="flight-SEGMENT"]')].slice(0, 8);
    info.rows = segs.map(s => {
      let row = s;                                                    // climb to the real flight row
      for (let k = 0; k < 6 && row.parentElement; k++) { row = row.parentElement; if ((row.innerText || '').length > 60) break; }
      const btns = [...row.querySelectorAll('button, a[role="button"], [role="button"]')].filter(b => b.offsetParent).slice(0, 8).map(b => (b.innerText || '').replace(/\s+/g, ' ').slice(0, 44)).filter(Boolean);
      return { id: s.id, text: (row.innerText || '').replace(/\s+/g, ' ').slice(0, 200), btns };
    });
    info.buttons = [...document.querySelectorAll('button')].filter(b => b.offsetParent && (b.innerText || '').trim()).slice(0, 40).map(b => (b.innerText || '').replace(/\s+/g, ' ').slice(0, 44));
    info.checks = [...document.querySelectorAll('input[type=checkbox]')].filter(c => c.offsetParent).slice(0, 10).map(c => ({ id: c.id || '', checked: !!c.checked, lab: ((c.labels && c.labels[0] && c.labels[0].innerText) || (c.closest('label') && c.closest('label').innerText) || '').replace(/\s+/g, ' ').slice(0, 50) }));
    const cont = document.querySelector('#btn-continue') || [...document.querySelectorAll('button')].find(b => /^\s*continuar\s*$/i.test(b.innerText || ''));
    info.continue = cont ? { id: cont.id || '', disabled: !!cont.disabled, cls: (typeof cont.className === 'string' ? cont.className : '').slice(0, 60) } : null;
    info.fareOptions = [...document.querySelectorAll('*')].filter(e => {
      if (!e.offsetParent) return false; const t = e.innerText || '';
      return t.length < 70 && /\d[\d.]{2,}\s*\+?\s*(tasas|millas)/i.test(t) && e.querySelectorAll('*').length < 6;
    }).slice(0, 12).map(e => {
      const clk = e.closest('label, button, [role="button"], a, li, [class*="fare"], [class*="card"]') || e;
      const inp = clk.querySelector && clk.querySelector('input');
      return { tag: e.tagName.toLowerCase(), cls: (typeof e.className === 'string' ? e.className : '').slice(0, 40), text: (e.innerText || '').replace(/\s+/g, ' ').slice(0, 50), clk: clk.tagName.toLowerCase() + '.' + ((typeof clk.className === 'string' ? clk.className : '').split(/\s+/)[0] || ''), checked: inp ? !!inp.checked : null };
    });
    info.target = lastTargetSeen ? { o: lastTargetSeen.origin, d: lastTargetSeen.destination, date: lastTargetSeen.date, dep: lastTargetSeen.dep, cabin: lastTargetSeen.cabin, miles: lastTargetSeen.miles } : null;
    info.flash = driveStatusEl ? driveStatusEl.textContent : '';
    info.fareMap = visFares().slice(0, 12).map(l => { const s = segOfFare(l); return { miles: fareMiles(l), seg: s ? s.id : null }; });
    info.loggedIn = !loggedOut();
    return JSON.stringify(info);
  }
  function copyDiag() {
    const t = dumpFareInfo();
    navigator.clipboard.writeText(t).then(() => flash('✓ Copied page info — paste it to Claude.')).catch(() => {
      const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;bottom:80px;right:12px;width:300px;height:150px;z-index:2147483647'; document.body.appendChild(ta); ta.focus(); ta.select(); flash('Select-all in the box + copy by hand.');
    });
  }

  // Find Smiles' "Guardar pasajero para futuras compras" checkbox (saves them to the account
  // favorites — treated as irreversible). We NEVER want it on by accident.
  function findSaveCheckbox() {
    const nodes = [...document.querySelectorAll('label, span, div')];
    const l = nodes.find(x => { const t = (x.innerText || '').trim(); return t.length < 90 && /guardar\s+pasajero/i.test(t); });
    if (!l) return null;
    if (l.htmlFor) { const el = document.getElementById(l.htmlFor); if (el && el.type === 'checkbox') return el; }
    let cb = l.querySelector && l.querySelector('input[type=checkbox]'); if (cb) return cb;
    for (const sib of [l.previousElementSibling, l.nextElementSibling]) if (sib && sib.matches && sib.matches('input[type=checkbox]')) return sib;
    cb = l.parentElement && l.parentElement.querySelector('input[type=checkbox]'); if (cb) return cb;
    return null;
  }
  // Returns true only if we can CONFIRM the save box is off. false = don't auto-continue.
  function ensureNotSaving() {
    const cb = findSaveCheckbox();
    if (!cb) return false;              // can't find it → refuse to continue
    if (cb.checked) cb.click();         // uncheck (React-friendly)
    return !cb.checked;                 // confirmed off?
  }

  // ---- fare selection on the results page (from the app's Book target) ----
  const digits = (s) => String(s == null ? '' : s).replace(/[^\d]/g, '');
  // A time like "06h30" / "6:30" → "0630" for comparing departure times.
  const hhmm = (s) => { const m = String(s == null ? '' : s).match(/(\d{1,2})\s*[:h]\s*(\d{2})/); return m ? (m[1].length < 2 ? '0' + m[1] : m[1]) + m[2] : ''; };
  // Logged out? Smiles shows an "Iniciá sesión" button and hides miles/selection until you log in.
  const loggedOut = () => [...document.querySelectorAll('button, a')].some(b => b.offsetParent && /inici[aá]r?\s*sesi[oó]n/i.test(b.innerText || ''));

  // NOTE: searching is done by the background loading the search URL in this same tab (the same
  // proven mechanism the background search uses; login survives a same-tab load). No in-page tricks.
  // Select the target flight by departure time + cabin (each flight is a #flight-SEGMENT_1-N row
  // like "LGA 06h30 … YUL 07h57 Clase Económica"). Click the row's select button (not "Detalles").
  function selectFare(target) {
    const wantTime = hhmm(target.dep);
    const wantExec = /business|ejecutiv/i.test(target.cabin || '');
    const O = (target.origin || '').toUpperCase(), D = (target.destination || '').toUpperCase();
    const segs = [...document.querySelectorAll('[id^="flight-SEGMENT"]')].filter(s => s.offsetParent);
    // CRITICAL: the #flight-SEGMENT element's own text is just "Detalles del vuelo" — the times/
    // route/cabin live on its ancestor CARD. Match the card's text, never the segment's.
    const cardOf = (s) => { let r = s; for (let k = 0; k < 6 && r.parentElement; k++) { r = r.parentElement; if ((r.innerText || '').length > 60) break; } return r; };
    const seg = segs.find(s => {
      const t = cardOf(s).innerText || '';
      const T = t.toUpperCase();
      if ((O && T.indexOf(O) === -1) || (D && T.indexOf(D) === -1)) return false;  // must be OUR route
      const dep = hhmm((t.match(/\d{1,2}h\d{2}/) || [''])[0]);   // first time in the card = departure
      const execRow = /ejecutiva/i.test(t);
      return dep === wantTime && (wantExec ? execRow : !execRow);   // economy/premium = "not Ejecutiva"
    });
    if (!seg) return { done: false, flights: segs.length, note: 'no ' + O + '→' + D + ' ' + wantTime + (wantExec ? ' exec' : ' econ') + ' row' };
    // Find the fare labels that BELONG to this flight (walk up from each label to its owning row).
    const fares = visFares().filter(l => segOfFare(l) === seg);
    if (!fares.length) {   // no inline fare in this flight's card — click the row to open its fare view
      const btn = [...seg.querySelectorAll('button, [role="button"], a')].find(b => b.offsetParent && !/detalles/i.test(b.innerText || ''));
      (btn || seg).click();
      return { done: true, note: 'clicked row' };
    }
    const wants = (target.miles || []).map(digits).filter(Boolean);
    const pick = fares.find(l => wants.indexOf(fareMiles(l)) !== -1) || fares[0];   // target miles, else cheapest/club
    pick.click();
    return { done: true };
  }

  // Leading miles on a fare label ("11.400 + tasas o impuestos Club…" → "11400").
  const fareMiles = (lab) => digits((lab.innerText || '').split(/\+|tasas|millas/i)[0]);
  const labelChecked = (lab) => {
    if (lab.htmlFor) { const el = document.getElementById(lab.htmlFor); if (el) return !!el.checked; }
    const inp = lab.querySelector && lab.querySelector('input'); if (inp) return !!inp.checked;
    const prev = lab.previousElementSibling; if (prev && prev.matches && prev.matches('input')) return !!prev.checked;
    return false;
  };
  // On the fare/tax step, pick the MILLAS fare matching the target miles (prefer club = first want).
  // Don't re-click one that's already selected — some are checkboxes and a 2nd click deselects.
  function selectMilesFare(target) {
    const wants = (target.miles || []).map(digits).filter(Boolean);
    const labels = [...document.querySelectorAll('label.form-check-label')].filter(l => l.offsetParent);
    for (const w of wants) {
      const m = labels.find(l => fareMiles(l) === w);
      if (m) { if (!labelChecked(m)) m.click(); return w; }
    }
    return null;
  }
  // On the fare/tax step? (fare options carrying "tasas/millas" text, the tax slider, or terms box.)
  function onFareTax() {
    return !!(q('#type-taxes-selected') || document.querySelector('label.form-check-label-emission.check-tc') ||
      [...document.querySelectorAll('label.form-check-label')].some(l => l.offsetParent && /tasas|millas/i.test(l.innerText || '')));
  }
  // Agree the terms checkbox — find it by nearby wording; only click if not already checked.
  function agreeTerms() {
    const cbs = [...document.querySelectorAll('input[type=checkbox]')].filter(c => c.offsetParent);
    for (const c of cbs) {
      const lab = (c.labels && c.labels[0] && c.labels[0].innerText) || (c.closest('label') && c.closest('label').innerText) || (c.parentElement && c.parentElement.innerText) || '';
      if (/acuerdo|acepto|t[eé]rminos|condiciones|pol[ií]tica/i.test(lab)) { if (!c.checked) c.click(); return true; }
    }
    const tc = document.querySelector('label.form-check-label-emission.check-tc');
    if (tc) { const inp = tc.htmlFor ? document.getElementById(tc.htmlFor) : (tc.querySelector('input') || null); if (!inp || !inp.checked) tc.click(); return true; }
    return false;
  }
  // Click "Continuar": by id, else by button text. Smiles disables it via a CSS class (not the
  // .disabled property), so check both. Returns 'clicked' | 'disabled' | 'none'.
  function clickContinue() {
    let c = document.querySelector('#btn-continue');
    if (!c) c = [...document.querySelectorAll('button, a[role="button"], [role="button"]')].find(b => b.offsetParent && /^\s*continuar\s*$/i.test(b.innerText || ''));
    if (!c) return 'none';
    if (c.disabled || /(^|\s)disabled(\s|$)/.test(typeof c.className === 'string' ? c.className : '')) return 'disabled';
    c.click(); return 'clicked';
  }

  // ---------------- auto-drive state machine ----------------
  // Smiles is a single-page app — navigations don't reload the script. Guard by the path we last
  // acted on (resets automatically when the step changes) instead of a once-per-load flag.
  let actedStep = '';
  let lastAdvance = 0;   // when we last clicked Continuar (cooldown so we don't double-submit)
  // Strip the search params my Book navigation put in the URL, so a plain user reload afterwards
  // does NOT re-run the last search. Called whenever the drive ends.
  function cleanUrl() { try { if (location.search) history.replaceState({}, '', location.pathname); } catch (e) {} }
  function startDrive() { chrome.storage.local.set({ [DRIVE]: { on: true, startedAt: Date.now() } }); flash('Auto-drive ON — agreeing terms → continue → fill → continue → stop at checkout.'); }
  function stopDrive() { chrome.storage.local.set({ [DRIVE]: { on: false }, [TARGET]: null }); cleanUrl(); flash('Auto-drive stopped.'); }
  // Which step of the booking we're on. fare + tax share /emission, so we can't guard by path alone.
  function currentStep() {
    if (onCheckout()) return 'checkout';
    if (onPax()) return 'pax';
    if (!onEmission()) return '';
    // Fare/tax step = the tax slider, terms box, or a Continuar button is present (these appear only
    // after a fare is selected — the plain results list has none of them).
    if (q('#type-taxes-selected') || document.querySelector('label.form-check-label-emission.check-tc') || q('#btn-continue')) return 'tax';
    // Results list = pick a flight/fare here.
    if (document.querySelector('[id^="flight-SEGMENT"]')) return 'fare';
    if (onFareTax()) return 'tax';
    return '';
  }
  function driveTick() {
    chrome.storage.local.get([DRIVE, KEY, TARGET], (st) => {
      const drive = (st && st[DRIVE]) || {};
      const data = (st && st[KEY]) || {};
      const target = (st && st[TARGET]) || null;
      lastTargetSeen = target;
      setDriveBtn(drive.on);
      if (!drive.on) { if (driveStatusEl) driveStatusEl.textContent = target ? ('Ready: ' + (target.summary || 'a flight') + ' — hit ▶ to book') : ''; return; }
      if (drive.startedAt && Date.now() - drive.startedAt > 6 * 60 * 1000) { chrome.storage.local.set({ [DRIVE]: { on: false }, [TARGET]: null }); cleanUrl(); return; } // stale drive: shut down + clean
      const step = currentStep();
      if (step === 'checkout') { chrome.storage.local.set({ [DRIVE]: { on: false }, [TARGET]: null }); flash('✋ Your turn — enter the Smiles password + captcha + card, then Confirmar pago.'); return; }
      if (loggedOut()) { flash('⚠ This Smiles tab is logged OUT — log into the account on THIS tab, then Book again.'); return; }
      if (!step) { if (target) flash('⏳ Loading ' + target.origin + '→' + target.destination + ' ' + (target.date || '') + '…'); return; }
      if (step !== 'tax' && actedStep === step) return;     // fare/pax: act once; tax: keep watching
      if (step === 'fare') {
        if (!target) { flash('👉 Click the fare you want — I take over from there.'); return; }
        const r = selectFare(target);
        if (r.done) { actedStep = 'fare'; flash('✓ Selected ' + (target.summary || 'your flight') + ' — continuing…'); }
        else flash('Finding your flight — ' + r.flights + ' shown; ' + (r.note || '') + '…');
        return;
      }
      if (step === 'pax') {
        if (!q('#firstName')) return;                       // form not rendered yet
        if (!data.first || !data.last) {
          flash('⚠ Fill the passenger (top-right panel) — I fill from there. Need at least first + last name.');
          const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#f59e0b';
          return;
        }
        const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#2b6cff';
        actedStep = 'pax'; fillForm(data);
        setTimeout(() => {
          if (!ensureNotSaving()) {   // couldn't guarantee "Guardar pasajero" is OFF → stop, don't advance
            chrome.storage.local.set({ [DRIVE]: { on: false } });
            flash('⛔ Filled, but I could NOT confirm "Guardar pasajero" is unchecked — stopped so no one is saved by accident. Uncheck it + click Continuar yourself.');
            return;
          }
          const b = q('#passengersConfirmButton'); if (b) b.click();
        }, 1000);
        return;
      }
      if (step === 'tax') {
        // Patient watcher: agree terms (idempotent) and click Continuar the moment it's enabled.
        // Don't touch the fare — you pick 11.400/13.000 (the one flaky click); I do the rest.
        agreeTerms();
        if (Date.now() - lastAdvance < 2500) return;         // just clicked — let the page move
        const r = clickContinue();
        if (r === 'clicked') { lastAdvance = Date.now(); flash('✓ Continuing…'); return; }
        flash(r === 'disabled'
          ? '👉 Pick the millas fare (11.400 / 13.000) — terms done; I continue the instant it\'s selected.'
          : 'Waiting for the fare page…');
        return;
      }
    });
  }

  // ---------------- UI ----------------
  function setDriveBtn(on) {
    if (!driveBtn) return;
    driveBtn.textContent = on ? '■ Stop auto-drive' : '▶ Auto-book to checkout';
    driveBtn.style.background = on ? '#dc2626' : '#4f46e5';
  }
  function buildDriveBar() {
    if (document.getElementById('__ymDrive')) return;
    const bar = document.createElement('div'); bar.id = '__ymDrive';
    bar.style.cssText = 'position:fixed;bottom:12px;right:12px;z-index:2147483646;background:#0b1220;color:#e6f0ff;font:12px system-ui,sans-serif;border:1px solid #4f46e5;border-radius:11px;padding:10px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
    bar.innerHTML = '<div style="font-weight:700;margin-bottom:6px">YM · auto-drive <span style="opacity:.55;font-weight:400">v' + VER + '</span></div><div style="font-size:11px;opacity:.8;margin-bottom:7px">Press Book in the processor — this tab searches, picks the flight, and stops at checkout.</div>';
    driveBtn = document.createElement('button');
    driveBtn.style.cssText = 'width:100%;cursor:pointer;border:0;border-radius:7px;padding:8px;color:#fff;font:13px system-ui;font-weight:700;background:#4f46e5';
    driveBtn.addEventListener('click', () => { chrome.storage.local.get(DRIVE, s => { const on = s && s[DRIVE] && s[DRIVE].on; if (on) stopDrive(); else { actedStep = ''; startDrive(); } }); });
    bar.appendChild(driveBtn);
    driveStatusEl = document.createElement('div'); driveStatusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; bar.appendChild(driveStatusEl);
    const diagBtn = document.createElement('button');
    diagBtn.textContent = '🔎 Copy page info';
    diagBtn.style.cssText = 'width:100%;margin-top:7px;cursor:pointer;border:1px solid #33507f;border-radius:7px;padding:6px;color:#cfe3ff;background:transparent;font:11px system-ui';
    diagBtn.addEventListener('click', copyDiag);
    bar.appendChild(diagBtn);
    document.body.appendChild(bar);
  }

  function buildPanel() {
    if (document.getElementById('__ymBook')) return;
    chrome.storage.local.get(KEY, (s) => {
      if (document.getElementById('__ymBook')) return;
      const d = (s && s[KEY]) || {};
      const box = document.createElement('div'); box.id = '__ymBook';
      box.style.cssText = 'position:fixed;top:74px;right:12px;z-index:2147483647;background:#0b1220;color:#e6f0ff;font:12px system-ui,-apple-system,sans-serif;border:1px solid #2b6cff;border-radius:11px;padding:11px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
      const v = (x) => (x || '').replace(/"/g, '&quot;');
      const fld = (id, ph, val, w) => `<input id="ymb_${id}" placeholder="${ph}" value="${v(val)}" style="width:${w || '100%'};margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box">`;
      box.innerHTML =
        '<div style="font-weight:700;margin-bottom:7px">YM · fill passenger</div>' +
        fld('first', 'First name', d.first) + fld('last', 'Last name', d.last) +
        '<select id="ymb_nationality" style="width:100%;margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box"><option value="">Nationality…</option></select>' +
        `<div style="margin:4px 0">Gender &nbsp;<label><input type="radio" name="ymb_gender" value="M" ${d.gender !== 'F' ? 'checked' : ''}> M</label> &nbsp;<label><input type="radio" name="ymb_gender" value="F" ${d.gender === 'F' ? 'checked' : ''}> F</label></div>` +
        fld('dob', 'DOB  DD/MM/YYYY', d.dob) + fld('passport', 'Passport #', d.passport) + fld('passportExp', 'Passport exp  DD/MM/YYYY', d.passportExp) +
        fld('email', 'Email', d.email) +
        `<div style="display:flex;gap:5px">${fld('ccode', 'Cód', d.ccode || '54', '46px')}${fld('area', 'Area', d.area, '58px')}${fld('phone', 'Phone', d.phone, 'auto')}</div>`;
      const btn = document.createElement('button');
      btn.textContent = 'Fill Smiles form';
      btn.style.cssText = 'width:100%;margin-top:8px;cursor:pointer;border:0;border-radius:7px;padding:8px;background:#16a34a;color:#fff;font:13px system-ui;font-weight:700';
      btn.addEventListener('click', saveAndFill);
      box.appendChild(btn);
      statusEl = document.createElement('div'); statusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; box.appendChild(statusEl);
      document.body.appendChild(box);
      const autosave = () => chrome.storage.local.set({ [KEY]: collect() });   // typing here = remembered; local only, NOT saved to Smiles
      box.querySelectorAll('input, select').forEach(el => { el.addEventListener('input', autosave); el.addEventListener('change', autosave); });
      const smilesNat = q('select[name="nationality"]'), panelNat = document.getElementById('ymb_nationality');
      if (smilesNat && panelNat && smilesNat.options.length) {
        panelNat.innerHTML = '<option value="">Nationality…</option>' + [...smilesNat.options].filter(o => o.value).map(o => `<option value="${(o.value || '').replace(/"/g, '&quot;')}">${(o.text || '').replace(/</g, '&lt;')}</option>`).join('');
        if (d.nationality) panelNat.value = d.nationality;
      }
    });
  }
  function collect() {
    const data = {}; FIELDS.forEach(k => { const el = document.getElementById('ymb_' + k); if (el) data[k] = el.value; });
    const gr = document.querySelector('input[name="ymb_gender"]:checked'); data.gender = gr ? gr.value : 'M';
    const natEl = document.getElementById('ymb_nationality'); data.nationality = natEl ? natEl.value : '';
    return data;
  }
  function saveAndFill() { const data = collect(); chrome.storage.local.set({ [KEY]: data }); fillForm(data); }

  function tick() {
    if (onEmission()) buildDriveBar(); else { const b = document.getElementById('__ymDrive'); if (b) { b.remove(); driveBtn = null; driveStatusEl = null; } }
    if (onPax()) buildPanel(); else { const b = document.getElementById('__ymBook'); if (b) { b.remove(); statusEl = null; } }
    driveTick();
  }
  tick();
  setInterval(tick, 1500);
})();
