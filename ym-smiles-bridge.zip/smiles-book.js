// Assisted booking driver (ISOLATED world) for Smiles.
//  • Passenger page: a panel to fill the form (name, DOB, passport, email, phone, nationality).
//  • Auto-drive: once you've picked a fare, it agrees the terms + clicks Continuar, fills the
//    passenger + clicks Continuar, and STOPS at checkout for you (password + captcha + card).
// Nothing here submits payment. Later the passenger data is fed from the customer's order.
(function () {
  'use strict';
  const VER = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '?';
  const KEY = 'ymBookPax';       // passenger details
  const DRIVE = 'ymAutoDrive';   // { on, startedAt }
  const TARGET = 'ymBookTarget'; // { origin, destination, dep, cabin, miles:[club, std], summary } from the app's Book button
  const FIELDS = ['first', 'last', 'dob', 'passport', 'passportExp', 'email', 'ccode', 'area', 'phone'];
  const onEmission = () => /\/emission/.test(location.pathname);
  const onPax = () => /\/emission\/passenger-data/.test(location.pathname);
  const onCheckout = () => /\/emission\/checkout/.test(location.pathname);

  // CRITICAL: Smiles ships BOTH layouts in every page — a `d-mobile` block and a `d-desktop`
  // block — carrying the SAME element ids (#calendarGo, #input-adult, #btn-continue, form
  // fields…). Whichever one your screen doesn't use is still in the DOM, just hidden by CSS,
  // and it comes FIRST. So document.querySelector('#x') hands back the INVISIBLE copy: we'd
  // read its state and type into it while the real control sits untouched. Every lookup here
  // must therefore return the visible match only.
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const st = getComputedStyle(el);
    return st.visibility !== 'hidden' && st.display !== 'none';
  }
  const qav = (s) => { try { return [...document.querySelectorAll(s)].filter(vis); } catch (e) { return []; } };
  const q = (s) => qav(s)[0] || null;
  const byId = (id) => qav('[id="' + id + '"]')[0] || null;
  const btnByText = (re, sels) => qav(sels || 'button, a, [role="button"], input[type=submit]')
    .find(b => re.test((b.innerText || b.value || '').trim())) || null;
  // Same-id lookup for elements we can't filter by visibility (styled checkboxes are 0x0):
  // pick the copy nearest `ref` in the DOM, i.e. the one in the section we're actually looking at.
  function idNear(id, ref) {
    let all = [];
    try { all = [...document.querySelectorAll('[id="' + id + '"]')]; } catch (e) { return null; }
    if (all.length <= 1) return all[0] || null;
    let a = ref;
    for (let k = 0; k < 8 && a; k++) { const hit = all.find(e => a.contains(e)); if (hit) return hit; a = a.parentElement; }
    return all.find(vis) || all[0];
  }

  function setVal(el, val) {
    if (!el) return false;
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  // React ignores a bare .click() on some controls — send the full pointer/mouse sequence.
  function realClick(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    try { el.dispatchEvent(new PointerEvent('pointerdown', o)); } catch (e) {}
    el.dispatchEvent(new MouseEvent('mousedown', o));
    try { el.dispatchEvent(new PointerEvent('pointerup', o)); } catch (e) {}
    el.dispatchEvent(new MouseEvent('mouseup', o));
    el.click();
    return true;
  }
  // Set a React-controlled input's value without the change/blur that would close an open
  // autocomplete list (setVal below is the heavier version used for the passenger form).
  function setNative(el, val) {
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
  async function typeInto(el, text) {
    el.focus();
    setNative(el, '');
    for (const ch of String(text)) {
      el.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true }));
      setNative(el, (el.value || '') + ch);
      el.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true }));
      await sleep(90);
    }
  }

  // Form fields: prefer the VISIBLE copy (so we never type into Smiles' hidden mobile markup),
  // but fall back to the element itself if no copy passes the visibility test. Radios and
  // checkboxes here are styled — the real input is zero-sized with a fake control drawn over it —
  // so a strict visible-only lookup finds nothing and the field silently goes unset, which is
  // what Smiles then rejects with "los parámetros … no fueron informados".
  const field = (sel) => { try { return q(sel) || document.querySelector(sel); } catch (e) { return null; } };

  function fillForm(d) {
    setVal(field('#firstName'), d.first || '');
    setVal(field('#lastName'), d.last || '');
    const nat = field('select[name="nationality"]');
    if (nat && d.nationality) setVal(nat, d.nationality);
    if (d.gender) { const g = /^f/i.test(d.gender) ? field('#female0') : field('#male0'); if (g) g.click(); }
    setVal(field('#birthday-0'), d.dob || '');
    setVal(field('#passport'), d.passport || '');
    setVal(field('#passportValidity0'), d.passportExp || '');
    setVal(field('#email'), d.email || '');
    setVal(field('#movilddi'), d.ccode || '54');
    setVal(field('#movilddd'), d.area || '');
    setVal(field('#movilnumber'), d.phone || '');
    flash('Filled ✓');
  }

  let statusEl = null, driveStatusEl = null, driveBtn = null;
  let lastTargetSeen = null;   // most recent target read in driveTick (for the diagnostic dump)
  // Also mirrored onto <html data-ym-status> so the current state is readable even on pages
  // where neither panel is drawn (the search runs on the home page, which has no drive bar).
  function flash(m) {
    if (statusEl) statusEl.textContent = m;
    if (driveStatusEl) driveStatusEl.textContent = m;
    try { document.documentElement.dataset.ymStatus = m; } catch (e) {}
  }

  // Which flight row does this fare label belong to? = the nearest ancestor holding exactly ONE
  // #flight-SEGMENT. Returns that segment element (or null if the label isn't inside a flight card).
  function segOfFare(lab) {
    let a = lab.parentElement;
    for (let k = 0; k < 12 && a; k++) {
      const s = a.querySelectorAll('[id^="flight-SEGMENT"]');
      if (s.length === 1) return s[0];
      if (s.length > 1) return null;
      a = a.parentElement;
    }
    return null;
  }
  const visFares = () => qav('label.form-check-label').filter(l => /tasas|millas/i.test(l.innerText || ''));

  // Diagnostic: dump the results-page structure (flight cards + fare labels) so we can see exactly
  // what's on the page when the fare-select gets stuck.
  function dumpFareInfo() {
    const info = { v: VER, url: location.href.replace(/[?#].*/, ''), title: (document.title || '').slice(0, 80), path: location.pathname };
    const segs = [...document.querySelectorAll('[id^="flight-SEGMENT"]')].slice(0, 8);
    info.rows = segs.map(s => {
      let row = s;                                                    // climb to the real flight row
      for (let k = 0; k < 6 && row.parentElement; k++) { row = row.parentElement; if ((row.innerText || '').length > 60) break; }
      const btns = [...row.querySelectorAll('button, a[role="button"], [role="button"]')].filter(b => b.offsetParent).slice(0, 8).map(b => (b.innerText || '').replace(/\s+/g, ' ').slice(0, 44)).filter(Boolean);
      return { id: s.id, text: (row.innerText || '').replace(/\s+/g, ' ').slice(0, 200), btns };
    });
    info.buttons = [...document.querySelectorAll('button')].filter(b => b.offsetParent && (b.innerText || '').trim()).slice(0, 40).map(b => (b.innerText || '').replace(/\s+/g, ' ').slice(0, 44));
    info.checks = [...document.querySelectorAll('input[type=checkbox]')].filter(c => c.offsetParent).slice(0, 10).map(c => ({ id: c.id || '', checked: !!c.checked, lab: ((c.labels && c.labels[0] && c.labels[0].innerText) || (c.closest('label') && c.closest('label').innerText) || '').replace(/\s+/g, ' ').slice(0, 50) }));
    const cont = document.querySelector('#btn-continue') || [...document.querySelectorAll('button')].find(b => /^\s*continuar\s*$/i.test(b.innerText || ''));
    info.continue = cont ? { id: cont.id || '', disabled: !!cont.disabled, cls: (typeof cont.className === 'string' ? cont.className : '').slice(0, 60) } : null;
    info.fareOptions = [...document.querySelectorAll('*')].filter(e => {
      if (!e.offsetParent) return false; const t = e.innerText || '';
      return t.length < 70 && /\d[\d.]{2,}\s*\+?\s*(tasas|millas)/i.test(t) && e.querySelectorAll('*').length < 6;
    }).slice(0, 12).map(e => {
      const clk = e.closest('label, button, [role="button"], a, li, [class*="fare"], [class*="card"]') || e;
      const inp = clk.querySelector && clk.querySelector('input');
      return { tag: e.tagName.toLowerCase(), cls: (typeof e.className === 'string' ? e.className : '').slice(0, 40), text: (e.innerText || '').replace(/\s+/g, ' ').slice(0, 50), clk: clk.tagName.toLowerCase() + '.' + ((typeof clk.className === 'string' ? clk.className : '').split(/\s+/)[0] || ''), checked: inp ? !!inp.checked : null };
    });
    info.target = lastTargetSeen ? { o: lastTargetSeen.origin, d: lastTargetSeen.destination, date: lastTargetSeen.date, dep: lastTargetSeen.dep, cabin: lastTargetSeen.cabin, miles: lastTargetSeen.miles } : null;
    info.flash = driveStatusEl ? driveStatusEl.textContent : '';
    info.fareMap = visFares().slice(0, 12).map(l => { const s = segOfFare(l); return { miles: fareMiles(l), seg: s ? s.id : null }; });
    info.loggedIn = !loggedOut();
    info.search = {
      qs: location.search.slice(0, 150),
      onTarget: lastTargetSeen ? urlMatchesTarget(lastTargetSeen) : null,
      hasBox: !!byId('airport-origin'), state: searchState, fareTries: fareTries
    };
    // total/visible count per id — Smiles duplicates ids across its mobile + desktop markup
    info.dupIds = ['btn-continue', 'type-taxes-selected', 'firstName', 'passengersConfirmButton', 'calendarGo', 'airport-origin']
      .map(id => { const all = document.querySelectorAll('[id="' + id + '"]'); return id + ' ' + all.length + '/' + [...all].filter(vis).length; });
    // Every field on the page and what it currently holds — SHAPE only: digits become # and
    // letters a, so we can see "##/##/####" vs empty vs a wrong format without the diagnostic
    // ever carrying the passenger's real name, passport or phone number.
    const shape = (s) => String(s == null ? '' : s).replace(/\d/g, '#').replace(/[A-Za-zÀ-ÿ]/g, 'a');
    info.inputs = qav('input, select').slice(0, 30).map(el => ({
      id: el.id || '', name: el.getAttribute('name') || '',
      cls: (typeof el.className === 'string' ? el.className : '').slice(0, 46),
      ph: (el.placeholder || '').slice(0, 24),
      type: el.type || '',
      val: shape(el.value).slice(0, 24),
      len: (el.value || '').length,
      checked: (el.type === 'checkbox' || el.type === 'radio') ? !!el.checked : null
    }));
    info.saveBox = (() => { const c = findSaveCheckbox(); return c ? { found: true, checked: !!c.checked, id: c.id || '' } : { found: false }; })();
    return JSON.stringify(info);
  }
  function copyDiag() {
    const t = dumpFareInfo();
    navigator.clipboard.writeText(t).then(() => flash('✓ Copied page info — paste it to Claude.')).catch(() => {
      const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;bottom:80px;right:12px;width:300px;height:150px;z-index:2147483647'; document.body.appendChild(ta); ta.focus(); ta.select(); flash('Select-all in the box + copy by hand.');
    });
  }

  // Find Smiles' "Guardar pasajero para futuras compras" checkbox (saves them to the account
  // favorites — treated as irreversible). We NEVER want it on by accident.
  function findSaveCheckbox() {
    // Visible nodes only: a hidden duplicate reading "unchecked" would let us continue while
    // the real, on-screen box is ticked — exactly the accident this guard exists to prevent.
    const nodes = qav('label, span, div');
    const l = nodes.find(x => { const t = (x.innerText || '').trim(); return t.length < 90 && /guardar\s+pasajero/i.test(t); });
    if (!l) return null;
    // A styled checkbox is often 0x0/opacity:0, so we can't filter the INPUT by visibility —
    // instead take the copy of that id sitting inside the same section as the visible label.
    if (l.htmlFor) { const el = idNear(l.htmlFor, l); if (el && el.type === 'checkbox') return el; }
    let cb = l.querySelector && l.querySelector('input[type=checkbox]'); if (cb) return cb;
    for (const sib of [l.previousElementSibling, l.nextElementSibling]) if (sib && sib.matches && sib.matches('input[type=checkbox]')) return sib;
    cb = l.parentElement && l.parentElement.querySelector('input[type=checkbox]'); if (cb) return cb;
    return null;
  }
  // Returns true only if we can CONFIRM the save box is off. false = don't auto-continue.
  function ensureNotSaving() {
    const cb = findSaveCheckbox();
    if (!cb) return false;              // can't find it → refuse to continue
    if (cb.checked) cb.click();         // uncheck (React-friendly)
    return !cb.checked;                 // confirmed off?
  }

  // ---- fare selection on the results page (from the app's Book target) ----
  const digits = (s) => String(s == null ? '' : s).replace(/[^\d]/g, '');
  // A time like "06h30" / "6:30" → "0630" for comparing departure times.
  const hhmm = (s) => { const m = String(s == null ? '' : s).match(/(\d{1,2})\s*[:h]\s*(\d{2})/); return m ? (m[1].length < 2 ? '0' + m[1] : m[1]) + m[2] : ''; };
  // Logged out? Smiles shows an "Iniciá sesión" button and hides miles/selection until you log in.
  const loggedOut = () => [...document.querySelectorAll('button, a')].some(b => b.offsetParent && /inici[aá]r?\s*sesi[oó]n/i.test(b.innerText || ''));

  // ---------- in-page search: drive Smiles' OWN search box, never navigate ----------
  // Measured on the live site: clicking Smiles' "Buscar" swaps the URL to /emission?... through
  // the SPA router WITHOUT reloading the document (a marker set on window survives it). Loading
  // that same URL directly is a real document load: the app reboots, and because the session is
  // held in memory it comes back signed out. That is the "every reload signs me out" problem —
  // so we fill the site's own form and press its own button instead.
  const MES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

  // Type an IATA code into an airport box and click the suggestion that carries "(CODE)".
  async function pickAirport(id, code) {
    const el = byId(id);
    if (!el) return 'no ' + id + ' box on this page';
    // the box holds the picked airport's full name ("Guarulhos (GRU)"), not the code we typed
    const taken = () => { const v = ((byId(id) || {}).value || ''); return v.toUpperCase().indexOf(code.toUpperCase()) !== -1 && v.length > code.length; };
    realClick(el); await sleep(250);
    await typeInto(el, code);
    for (let i = 0; i < 16 && !taken(); i++) {
      await sleep(400);
      const opt = qav('li').filter(l => (l.innerText || '').indexOf('(' + code + ')') !== -1 && !l.querySelector('li')).pop();
      if (!opt) continue;
      // The row is <li><a>San Pablo, Brasil, Guarulhos (GRU)</a></li> and the handler sits on
      // the INNER <a> — clicking the <li> itself does nothing at all.
      const hit = opt.querySelector('a') || opt.firstElementChild || opt;
      hit.click(); await sleep(500);
      if (!taken()) { realClick(hit); await sleep(500); }
    }
    const v = ((byId(id) || {}).value || '');
    return taken() ? '' : 'could not pick ' + code + ' (box shows "' + v + '")';
  }

  // Pick a date in the react-dates calendar. Day cells carry a Spanish aria-label
  // ("viernes, 16 de octubre de 2026"); unavailable ones are prefixed "Not available.".
  async function pickDate(iso) {
    const p = String(iso || '').split('-');
    if (p.length !== 3) return 'no search date on this flight';
    const y = p[0], mi = +p[1] - 1, day = String(+p[2]);
    const cal = byId('calendarGo');
    if (!cal) return 'no date field on this page';
    // Two react-dates quirks: it opens on FOCUS (a synthetic click doesn't move focus the way a
    // real one does), and it keeps the neighbouring months mounted at visibility:hidden — those
    // cells click just fine, so day cells are filtered by being RENDERED, never by visibility.
    const days = () => { try { return [...document.querySelectorAll('[class*="CalendarDay"]')].filter(e => e.getClientRects().length); } catch (e) { return []; } };
    try { cal.focus(); } catch (e) {}
    realClick(cal);
    for (let i = 0; i < 12 && !days().length; i++) await sleep(300);
    if (!days().length) return 'the date calendar would not open';
    const want = ('0' + (+p[2])).slice(-2) + '/' + ('0' + (mi + 1)).slice(-2) + '/' + y;
    const set = () => ((byId('calendarGo') || {}).value || '') === want;
    for (let hop = 0; hop < 14 && !set(); hop++) {
      const cell = days().find(c => {
        const a = (c.getAttribute('aria-label') || '').toLowerCase();
        if (!a || a.indexOf('not available') === 0) return false;
        return a.indexOf(MES[mi]) !== -1 && a.indexOf(y) !== -1 && new RegExp('(^|\\D)' + day + '(\\D|$)').test(a);
      });
      if (cell) {
        cell.click(); await sleep(600);
        if (!set()) { realClick(cell); await sleep(600); }
        if (!set() && cell.firstElementChild) { cell.firstElementChild.click(); await sleep(600); }
        break;
      }
      // month arrows are role=button divs labelled "Move forward to switch to the next month."
      const fwd = document.querySelector('[aria-label*="Move forward" i]')
        || [...document.querySelectorAll('.DayPickerNavigation_button, [class*="DayPickerNavigation"] [role="button"]')].pop();
      if (!fwd) break;
      fwd.click(); await sleep(700);
    }
    const got = ((byId('calendarGo') || {}).value || '');
    return got === want ? '' : 'could not set the date (field shows "' + got + '", wanted ' + want + ')';
  }

  // Fill the whole search form and press Buscar. Returns '' on success, else why it stopped.
  async function searchInPage(t) {
    if (!byId('airport-origin')) {                       // results page: reveal the form
      const mod = btnByText(/modificar/i);
      if (mod) { realClick(mod); await sleep(1400); }
    }
    if (!byId('airport-origin')) return 'no search box on this page — open smiles.com.ar in this tab, then press Book again';
    const solo = btnByText(/^s[óo]lo ida$/i);            // one-way, else it wants a return date
    if (solo && !/search-btn-active/.test((solo.className || '').toString())) { realClick(solo); await sleep(900); }
    let e = await pickAirport('airport-origin', t.origin); if (e) return e;
    e = await pickAirport('airport-destination', t.destination); if (e) return e;
    e = await pickDate(t.date); if (e) return e;
    const ad = byId('input-adult');                      // passengers: click +, the box is React-controlled
    if (ad) {
      const want = Math.max(1, t.adults || 1);
      let cur = parseInt(ad.value, 10) || 1;
      const inc = ad.parentElement && ad.parentElement.querySelector('button.control.increase');
      for (let i = 0; i < 8 && cur < want && inc; i++) { realClick(inc); await sleep(320); cur = parseInt(((byId('input-adult') || {}).value), 10) || cur; }
    }
    const go = btnByText(/^buscar/i);
    if (!go) return 'could not find the Buscar button';
    realClick(go);
    return '';
  }

  // Are we already looking at the results for the flight we were asked to book?
  function urlMatchesTarget(t) {
    let p; try { p = new URLSearchParams(location.search); } catch (e) { return false; }
    return (p.get('originAirportCode') || '').toUpperCase() === (t.origin || '').toUpperCase()
      && (p.get('destinationAirportCode') || '').toUpperCase() === (t.destination || '').toUpperCase()
      && (p.get('departureDate') || '') === (t.date || '');
  }

  // Select the target flight by departure time + cabin (each flight is a #flight-SEGMENT_1-N row
  // like "LGA 06h30 … YUL 07h57 Clase Económica"). Click the row's select button (not "Detalles").
  function selectFare(target) {
    const wantTime = hhmm(target.dep);
    const wantExec = /business|ejecutiv/i.test(target.cabin || '');
    const O = (target.origin || '').toUpperCase(), D = (target.destination || '').toUpperCase();
    const segs = qav('[id^="flight-SEGMENT"]');
    // CRITICAL: the #flight-SEGMENT element's own text is just "Detalles del vuelo" — the times/
    // route/cabin live on its ancestor CARD. Match the card's text, never the segment's. Stop
    // climbing before an ancestor that holds two flights, or we'd read the neighbour's times.
    const cardOf = (s) => {
      let r = s, best = s;
      for (let k = 0; k < 8 && r.parentElement; k++) {
        r = r.parentElement;
        if (r.querySelectorAll('[id^="flight-SEGMENT"]').length > 1) break;
        best = r;
        if ((r.innerText || '').length > 60) break;
      }
      return best;
    };
    const cards = segs.map(s => {
      const c = cardOf(s), t = c.innerText || '';
      // EVERY time on the card, in order — the first one is NOT always the departure (a
      // duration like "1h27" reads the same), so we match the departure first, then any time.
      return { seg: s, card: c, t: t, T: t.toUpperCase(), times: (t.match(/\d{1,2}\s*[h:]\s*\d{2}/g) || []).map(hhmm) };
    });
    const routeOk = (c) => (!O || c.T.indexOf(O) !== -1) && (!D || c.T.indexOf(D) !== -1);
    const cabinOk = (c) => { const ex = /ejecutiva|business/i.test(c.t); return wantExec ? ex : !ex; };
    const m = cards.find(c => routeOk(c) && cabinOk(c) && c.times[0] === wantTime)
      || cards.find(c => routeOk(c) && cabinOk(c) && c.times.indexOf(wantTime) !== -1)
      || cards.find(c => routeOk(c) && c.times[0] === wantTime)
      || cards.find(c => routeOk(c) && c.times.indexOf(wantTime) !== -1);
    if (!m) return { done: false, flights: segs.length, note: 'no ' + O + '→' + D + ' ' + wantTime + (wantExec ? ' exec' : ' econ') + ' row' };
    // Find the fare labels that BELONG to this flight (walk up from each label to its owning row).
    const fares = visFares().filter(l => segOfFare(l) === m.seg);
    if (!fares.length) {   // no inline fare in this flight's card — click the row to open its fare view
      const pickBtn = (root) => [...root.querySelectorAll('button, [role="button"], a')].filter(vis).find(b => !/detalles/i.test(b.innerText || ''));
      realClick(pickBtn(m.seg) || pickBtn(m.card) || m.seg);
      return { done: true, note: 'clicked row' };
    }
    const wants = (target.miles || []).map(digits).filter(Boolean);
    const pick = fares.find(l => wants.indexOf(fareMiles(l)) !== -1) || fares[0];   // target miles, else cheapest/club
    realClick(pick);
    return { done: true };
  }

  // Leading miles on a fare label ("11.400 + tasas o impuestos Club…" → "11400").
  const fareMiles = (lab) => digits((lab.innerText || '').split(/\+|tasas|millas/i)[0]);
  const labelChecked = (lab) => {
    if (lab.htmlFor) { const el = document.getElementById(lab.htmlFor); if (el) return !!el.checked; }
    const inp = lab.querySelector && lab.querySelector('input'); if (inp) return !!inp.checked;
    const prev = lab.previousElementSibling; if (prev && prev.matches && prev.matches('input')) return !!prev.checked;
    return false;
  };
  // On the fare/tax step, pick the MILLAS fare matching the target miles (prefer club = first want).
  // Don't re-click one that's already selected — some are checkboxes and a 2nd click deselects.
  function selectMilesFare(target) {
    const wants = (target.miles || []).map(digits).filter(Boolean);
    const labels = [...document.querySelectorAll('label.form-check-label')].filter(l => l.offsetParent);
    for (const w of wants) {
      const m = labels.find(l => fareMiles(l) === w);
      if (m) { if (!labelChecked(m)) m.click(); return w; }
    }
    return null;
  }
  // On the fare/tax step? (fare options carrying "tasas/millas" text, the tax slider, or terms box.)
  function onFareTax() {
    return !!(q('#type-taxes-selected') || q('label.form-check-label-emission.check-tc') || visFares().length);
  }
  // Agree the terms checkbox — find it by nearby wording; only click if not already checked.
  function agreeTerms() {
    const cbs = [...document.querySelectorAll('input[type=checkbox]')].filter(c => c.offsetParent);
    for (const c of cbs) {
      const lab = (c.labels && c.labels[0] && c.labels[0].innerText) || (c.closest('label') && c.closest('label').innerText) || (c.parentElement && c.parentElement.innerText) || '';
      if (/acuerdo|acepto|t[eé]rminos|condiciones|pol[ií]tica/i.test(lab)) { if (!c.checked) c.click(); return true; }
    }
    const tc = q('label.form-check-label-emission.check-tc');
    if (tc) { const inp = tc.htmlFor ? idNear(tc.htmlFor, tc) : (tc.querySelector('input') || null); if (!inp || !inp.checked) realClick(tc); return true; }
    return false;
  }
  // Click "Continuar": by id, else by button text. Smiles disables it via a CSS class (not the
  // .disabled property), so check both. Returns 'clicked' | 'disabled' | 'none'.
  function clickContinue() {
    let c = byId('btn-continue');
    if (!c) c = btnByText(/^\s*continuar\s*$/i);
    if (!c) return 'none';
    if (c.disabled || /(^|\s)disabled(\s|$)/.test(typeof c.className === 'string' ? c.className : '')) return 'disabled';
    realClick(c); return 'clicked';
  }

  // ---------------- auto-drive state machine ----------------
  // Smiles is a single-page app — navigations don't reload the script. Guard by the path we last
  // acted on (resets automatically when the step changes) instead of a once-per-load flag.
  let actedStep = '';
  let lastAdvance = 0;   // when we last clicked Continuar (cooldown so we don't double-submit)
  let lastFareTry = 0;   // the flight pick RETRIES: one shot was the old bug (a missed click stuck forever)
  let fareTries = 0, fareClicked = false;   // fareClicked: we already picked the row — never click it again
  let loggedOutTicks = 0;                                  // the SPA renders "Iniciá sesión" while booting
  let searchState = { key: '', phase: '', err: '', tries: 0 };   // in-page search bookkeeping
  const targetKey = (t) => [t.origin, t.destination, t.date].join('|').toUpperCase();
  // Strip the search params my Book navigation put in the URL, so a plain user reload afterwards
  // does NOT re-run the last search. Called whenever the drive ends.
  function cleanUrl() { try { if (location.search) history.replaceState({}, '', location.pathname); } catch (e) {} }
  function resetDriveState() { actedStep = ''; fareTries = 0; fareClicked = false; lastFareTry = 0; loggedOutTicks = 0; searchState = { key: '', phase: '', err: '', tries: 0 }; }
  function startDrive() { resetDriveState(); chrome.storage.local.set({ [DRIVE]: { on: true, startedAt: Date.now() } }); flash('Auto-drive ON — search → pick the flight → terms → fill → stop at checkout.'); }
  function stopDrive() { chrome.storage.local.set({ [DRIVE]: { on: false }, [TARGET]: null }); cleanUrl(); flash('Auto-drive stopped.'); }
  // Which step of the booking we're on. fare + tax share /emission, so we can't guard by path alone.
  function currentStep() {
    if (onCheckout()) return 'checkout';
    if (onPax()) return 'pax';
    if (!onEmission()) return '';
    // Fare/tax step = the tax slider, terms box, or a Continuar button is present (these appear only
    // after a fare is selected — the plain results list has none of them).
    if (q('#type-taxes-selected') || document.querySelector('label.form-check-label-emission.check-tc') || q('#btn-continue')) return 'tax';
    // Results list = pick a flight/fare here.
    if (document.querySelector('[id^="flight-SEGMENT"]')) return 'fare';
    if (onFareTax()) return 'tax';
    return '';
  }
  function driveTick() {
    chrome.storage.local.get([DRIVE, KEY, TARGET], (st) => {
      const drive = (st && st[DRIVE]) || {};
      const data = (st && st[KEY]) || {};
      const target = (st && st[TARGET]) || null;
      lastTargetSeen = target;
      setDriveBtn(drive.on);
      if (!drive.on) { if (driveStatusEl) driveStatusEl.textContent = target ? ('Ready: ' + (target.summary || 'a flight') + ' — hit ▶ to book') : ''; return; }
      if (drive.startedAt && Date.now() - drive.startedAt > 6 * 60 * 1000) { chrome.storage.local.set({ [DRIVE]: { on: false }, [TARGET]: null }); cleanUrl(); return; } // stale drive: shut down + clean
      const step = currentStep();
      if (step === 'checkout') { chrome.storage.local.set({ [DRIVE]: { on: false }, [TARGET]: null }); flash('✋ Your turn — enter the Smiles password + captcha + card, then Confirmar pago.'); return; }
      // Not on the results for this flight yet? Run Smiles' OWN search here, in-page. We never
      // load a URL into this tab: that reboots the app and signs the account out. Searching
      // needs no account, so this runs BEFORE the logged-in check — being signed out should
      // never stop us getting the results on screen.
      if (target && !onPax() && !onCheckout() && step !== 'tax' && !urlMatchesTarget(target)) {
        const key = targetKey(target);
        if (searchState.key !== key) searchState = { key: key, phase: '', err: '', tries: 0 };
        const where = target.origin + '→' + target.destination + ' ' + (target.date || '');
        if (searchState.phase === 'running') { flash('🔎 Searching ' + where + ' in this tab…'); return; }
        if (searchState.tries >= 3) { flash('⚠ Could not run the search here: ' + (searchState.err || '?') + ' — search it yourself in this tab and I\'ll take over.'); return; }
        searchState.phase = 'running'; searchState.tries++;
        flash('🔎 Searching ' + where + '…');
        searchInPage(target).then(err => {
          searchState.err = err || ''; searchState.phase = err ? 'failed' : 'done';
          if (err) flash('⚠ ' + err);
        }).catch(ex => { searchState.err = String(ex); searchState.phase = 'failed'; });
        return;
      }

      // Past the search, everything left (picking a fare, continuing, the passenger form) needs
      // the account. Don't panic at the first sight of "Iniciá sesión" though — the SPA paints
      // the logged-out header for a moment while it restores the session; only flag it if it sticks.
      if (loggedOut()) {
        if (++loggedOutTicks < 4) { flash('⏳ Checking the session…'); return; }
        flash('⚠ This Smiles tab is logged OUT — log into the account on THIS tab, then Book again.');
        return;
      }
      loggedOutTicks = 0;

      if (!step) { if (target) flash('⏳ Loading ' + target.origin + '→' + target.destination + ' ' + (target.date || '') + '…'); return; }
      if (step === 'pax' && actedStep === step) return;      // pax: fill once; fare/tax: keep watching
      if (step === 'fare') {
        if (!target) { flash('👉 Click the fare you want — I take over from there.'); return; }
        // Retry only while we have NOT managed to click the row. Clicking a fare that is already
        // selected DESELECTS it on Smiles, which throws away the flight/fare the rest of the
        // booking is built on — the next step then fails with "Los parámetros de la solicitud
        // no fueron informados". A missed click is recoverable by you; a deselect is not.
        if (fareClicked) {
          if (Date.now() - lastFareTry > 12000) flash('👉 I clicked ' + (target.summary || 'your flight') + ' but the page hasn\'t moved on — click the fare yourself and I\'ll carry on from there.');
          return;
        }
        if (Date.now() - lastFareTry < 4000) return;         // give the page time between attempts
        lastFareTry = Date.now(); fareTries++;
        const r = selectFare(target);
        if (r.done) { fareClicked = true; flash('✓ Selected ' + (target.summary || 'your flight') + ' — continuing…'); }
        else if (fareTries > 6) flash('⚠ Still can\'t find ' + (target.summary || 'that flight') + ' among ' + r.flights + ' shown (' + (r.note || '') + ') — click it yourself and I\'ll carry on.');
        else flash('Finding your flight — ' + r.flights + ' shown; ' + (r.note || '') + '…');
        return;
      }
      if (step === 'pax') {
        if (!q('#firstName')) return;                       // form not rendered yet
        if (!data.first || !data.last) {
          flash('⚠ Fill the passenger (top-right panel) — I fill from there. Need at least first + last name.');
          const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#f59e0b';
          return;
        }
        const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#2b6cff';
        actedStep = 'pax'; fillForm(data);
        setTimeout(() => {
          if (!ensureNotSaving()) {   // couldn't guarantee "Guardar pasajero" is OFF → stop, don't advance
            chrome.storage.local.set({ [DRIVE]: { on: false } });
            flash('⛔ Filled, but I could NOT confirm "Guardar pasajero" is unchecked — stopped so no one is saved by accident. Uncheck it + click Continuar yourself.');
            return;
          }
          const b = byId('passengersConfirmButton'); if (b) realClick(b);
        }, 1000);
        return;
      }
      if (step === 'tax') {
        // Patient watcher: agree terms (idempotent) and click Continuar the moment it's enabled.
        // Don't touch the fare — you pick 11.400/13.000 (the one flaky click); I do the rest.
        agreeTerms();
        if (Date.now() - lastAdvance < 2500) return;         // just clicked — let the page move
        const r = clickContinue();
        if (r === 'clicked') { lastAdvance = Date.now(); flash('✓ Continuing…'); return; }
        flash(r === 'disabled'
          ? '👉 Pick the millas fare (11.400 / 13.000) — terms done; I continue the instant it\'s selected.'
          : 'Waiting for the fare page…');
        return;
      }
    });
  }

  // ---------------- UI ----------------
  function setDriveBtn(on) {
    if (!driveBtn) return;
    driveBtn.textContent = on ? '■ Stop auto-drive' : '▶ Auto-book to checkout';
    driveBtn.style.background = on ? '#dc2626' : '#4f46e5';
  }
  function buildDriveBar() {
    if (document.getElementById('__ymDrive')) return;
    const bar = document.createElement('div'); bar.id = '__ymDrive';
    bar.style.cssText = 'position:fixed;bottom:12px;right:12px;z-index:2147483646;background:#0b1220;color:#e6f0ff;font:12px system-ui,sans-serif;border:1px solid #4f46e5;border-radius:11px;padding:10px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
    bar.innerHTML = '<div style="font-weight:700;margin-bottom:6px">YM · auto-drive <span style="opacity:.55;font-weight:400">v' + VER + '</span></div><div style="font-size:11px;opacity:.8;margin-bottom:7px">Press Book in the processor — this tab searches, picks the flight, and stops at checkout.</div>';
    driveBtn = document.createElement('button');
    driveBtn.style.cssText = 'width:100%;cursor:pointer;border:0;border-radius:7px;padding:8px;color:#fff;font:13px system-ui;font-weight:700;background:#4f46e5';
    driveBtn.addEventListener('click', () => { chrome.storage.local.get(DRIVE, s => { const on = s && s[DRIVE] && s[DRIVE].on; if (on) stopDrive(); else startDrive(); }); });
    bar.appendChild(driveBtn);
    driveStatusEl = document.createElement('div'); driveStatusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; bar.appendChild(driveStatusEl);
    const diagBtn = document.createElement('button');
    diagBtn.textContent = '🔎 Copy page info';
    diagBtn.style.cssText = 'width:100%;margin-top:7px;cursor:pointer;border:1px solid #33507f;border-radius:7px;padding:6px;color:#cfe3ff;background:transparent;font:11px system-ui';
    diagBtn.addEventListener('click', copyDiag);
    bar.appendChild(diagBtn);
    document.body.appendChild(bar);
  }

  function buildPanel() {
    if (document.getElementById('__ymBook')) return;
    chrome.storage.local.get(KEY, (s) => {
      if (document.getElementById('__ymBook')) return;
      const d = (s && s[KEY]) || {};
      const box = document.createElement('div'); box.id = '__ymBook';
      box.style.cssText = 'position:fixed;top:74px;right:12px;z-index:2147483647;background:#0b1220;color:#e6f0ff;font:12px system-ui,-apple-system,sans-serif;border:1px solid #2b6cff;border-radius:11px;padding:11px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
      const v = (x) => (x || '').replace(/"/g, '&quot;');
      const fld = (id, ph, val, w) => `<input id="ymb_${id}" placeholder="${ph}" value="${v(val)}" style="width:${w || '100%'};margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box">`;
      box.innerHTML =
        '<div style="font-weight:700;margin-bottom:7px">YM · fill passenger</div>' +
        fld('first', 'First name', d.first) + fld('last', 'Last name', d.last) +
        '<select id="ymb_nationality" style="width:100%;margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box"><option value="">Nationality…</option></select>' +
        `<div style="margin:4px 0">Gender &nbsp;<label><input type="radio" name="ymb_gender" value="M" ${d.gender !== 'F' ? 'checked' : ''}> M</label> &nbsp;<label><input type="radio" name="ymb_gender" value="F" ${d.gender === 'F' ? 'checked' : ''}> F</label></div>` +
        fld('dob', 'DOB  DD/MM/YYYY', d.dob) + fld('passport', 'Passport #', d.passport) + fld('passportExp', 'Passport exp  DD/MM/YYYY', d.passportExp) +
        fld('email', 'Email', d.email) +
        `<div style="display:flex;gap:5px">${fld('ccode', 'Cód', d.ccode || '54', '46px')}${fld('area', 'Area', d.area, '58px')}${fld('phone', 'Phone', d.phone, 'auto')}</div>`;
      const btn = document.createElement('button');
      btn.textContent = 'Fill Smiles form';
      btn.style.cssText = 'width:100%;margin-top:8px;cursor:pointer;border:0;border-radius:7px;padding:8px;background:#16a34a;color:#fff;font:13px system-ui;font-weight:700';
      btn.addEventListener('click', saveAndFill);
      box.appendChild(btn);
      statusEl = document.createElement('div'); statusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; box.appendChild(statusEl);
      document.body.appendChild(box);
      const autosave = () => chrome.storage.local.set({ [KEY]: collect() });   // typing here = remembered; local only, NOT saved to Smiles
      box.querySelectorAll('input, select').forEach(el => { el.addEventListener('input', autosave); el.addEventListener('change', autosave); });
      const smilesNat = q('select[name="nationality"]'), panelNat = document.getElementById('ymb_nationality');
      if (smilesNat && panelNat && smilesNat.options.length) {
        panelNat.innerHTML = '<option value="">Nationality…</option>' + [...smilesNat.options].filter(o => o.value).map(o => `<option value="${(o.value || '').replace(/"/g, '&quot;')}">${(o.text || '').replace(/</g, '&lt;')}</option>`).join('');
        if (d.nationality) panelNat.value = d.nationality;
      }
    });
  }
  function collect() {
    const data = {}; FIELDS.forEach(k => { const el = document.getElementById('ymb_' + k); if (el) data[k] = el.value; });
    const gr = document.querySelector('input[name="ymb_gender"]:checked'); data.gender = gr ? gr.value : 'M';
    const natEl = document.getElementById('ymb_nationality'); data.nationality = natEl ? natEl.value : '';
    return data;
  }
  function saveAndFill() { const data = collect(); chrome.storage.local.set({ [KEY]: data }); fillForm(data); }

  function tick() {
    if (onEmission()) buildDriveBar(); else { const b = document.getElementById('__ymDrive'); if (b) { b.remove(); driveBtn = null; driveStatusEl = null; } }
    if (onPax()) buildPanel(); else { const b = document.getElementById('__ymBook'); if (b) { b.remove(); statusEl = null; } }
    driveTick();
  }
  tick();
  setInterval(tick, 1500);
})();
