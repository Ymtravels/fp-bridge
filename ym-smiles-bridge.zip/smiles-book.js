// Assisted booking driver (ISOLATED world) for Smiles.
//  • Passenger page: a panel to fill the form (name, DOB, passport, email, phone, nationality).
//  • Auto-drive: once you've picked a fare, it agrees the terms + clicks Continuar, fills the
//    passenger + clicks Continuar, and STOPS at checkout for you (password + captcha + card).
// Nothing here submits payment. Later the passenger data is fed from the customer's order.
(function () {
  'use strict';
  const VER = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '?';
  // This file gets re-injected into live tabs when the extension reloads — that is how a new
  // version reaches an open Smiles tab WITHOUT a page reload, which would sign you out. Two
  // copies must never drive at once, so each injection claims ownership and any older copy
  // stands down on its next tick. Clear the previous copy's panels too.
  const ME = 'ym' + Date.now() + Math.random().toString(36).slice(2, 6);
  window.__ymDriverOwner = ME;
  ['__ymDrive', '__ymBook'].forEach(id => { const e = document.getElementById(id); if (e) e.remove(); });
  const KEY = 'ymBookPax';       // passenger details
  const DRIVE = 'ymAutoDrive';   // { on, startedAt }
  const TARGET = 'ymBookTarget'; // { origin, destination, dep, cabin, miles:[club, std], summary } from the app's Book button
  const FIELDS = ['first', 'last', 'dob', 'passport', 'passportExp', 'email', 'ccode', 'area', 'phone'];
  const onEmission = () => /\/emission/.test(location.pathname);
  const onPax = () => /\/emission\/passenger-data/.test(location.pathname);
  const onCheckout = () => /\/emission\/checkout/.test(location.pathname);
  const onLogin = () => /\/login/.test(location.pathname);
  const ACCTS = 'ymAccounts';   // [{name, dni, pass}] — this browser profile only, never sent anywhere

  // CRITICAL: Smiles ships BOTH layouts in every page — a `d-mobile` block and a `d-desktop`
  // block — carrying the SAME element ids (#calendarGo, #input-adult, #btn-continue, form
  // fields…). Whichever one your screen doesn't use is still in the DOM, just hidden by CSS,
  // and it comes FIRST. So document.querySelector('#x') hands back the INVISIBLE copy: we'd
  // read its state and type into it while the real control sits untouched. Every lookup here
  // must therefore return the visible match only.
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const st = getComputedStyle(el);
    return st.visibility !== 'hidden' && st.display !== 'none';
  }
  const qav = (s) => { try { return [...document.querySelectorAll(s)].filter(vis); } catch (e) { return []; } };
  // Reloading the extension orphans the copy of this script already running in open tabs: every
  // later chrome.* call throws "Extension context invalidated" and fills the error list. There
  // is nothing useful an orphan can do, so it checks first and shuts itself down instead.
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };
  // Minutes left on the Smiles session. sessionStorage.expiresToken is a plain ms timestamp —
  // a time, never a credential. This is the number that actually governs everything: reloads
  // are harmless while it is positive, and the account drops when it runs out.
  function sessionLeftMin() {
    try {
      const raw = sessionStorage.getItem('expiresToken');
      if (!raw || !/^[0-9]{10,13}$/.test(raw)) return null;
      const ms = raw.length <= 10 ? +raw * 1000 : +raw;
      return Math.round((ms - Date.now()) / 60000);
    } catch (e) { return null; }
  }
  // Every storage call goes through these. Checking alive() once per tick is not enough: the
  // callbacks fire later, and the panel's own buttons don't go through tick at all, so an
  // extension reload mid-flight still threw "Extension context invalidated". Callbacks are
  // still invoked when we skip, so nothing waiting on one hangs.
  function sGet(keys, cb) {
    if (!alive()) return;
    try { chrome.storage.local.get(keys, (r) => { if (!alive()) return; try { cb(r); } catch (e) {} }); } catch (e) {}
  }
  function sSet(obj, cb) {
    const done = () => { if (cb) { try { cb(); } catch (e) {} } };
    if (!alive()) { done(); return; }
    try { chrome.storage.local.set(obj, done); } catch (e) { done(); }
  }
  const q = (s) => qav(s)[0] || null;
  const byId = (id) => qav('[id="' + id + '"]')[0] || null;
  const btnByText = (re, sels) => qav(sels || 'button, a, [role="button"], input[type=submit]')
    .find(b => re.test((b.innerText || b.value || '').trim())) || null;
  // Same-id lookup for elements we can't filter by visibility (styled checkboxes are 0x0):
  // pick the copy nearest `ref` in the DOM, i.e. the one in the section we're actually looking at.
  function idNear(id, ref) {
    let all = [];
    try { all = [...document.querySelectorAll('[id="' + id + '"]')]; } catch (e) { return null; }
    if (all.length <= 1) return all[0] || null;
    let a = ref;
    for (let k = 0; k < 8 && a; k++) { const hit = all.find(e => a.contains(e)); if (hit) return hit; a = a.parentElement; }
    return all.find(vis) || all[0];
  }

  function setVal(el, val) {
    if (!el) return false;
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  // React ignores a bare .click() on some controls — send the full pointer/mouse sequence.
  function realClick(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    try { el.dispatchEvent(new PointerEvent('pointerdown', o)); } catch (e) {}
    el.dispatchEvent(new MouseEvent('mousedown', o));
    try { el.dispatchEvent(new PointerEvent('pointerup', o)); } catch (e) {}
    el.dispatchEvent(new MouseEvent('mouseup', o));
    el.click();
    return true;
  }
  // Set a React-controlled input's value without the change/blur that would close an open
  // autocomplete list (setVal below is the heavier version used for the passenger form).
  function setNative(el, val) {
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
  async function typeInto(el, text) {
    el.focus();
    setNative(el, '');
    for (const ch of String(text)) {
      el.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true }));
      setNative(el, (el.value || '') + ch);
      el.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true }));
      await sleep(90);
    }
  }

  // Form fields: prefer the VISIBLE copy (so we never type into Smiles' hidden mobile markup),
  // but fall back to the element itself if no copy passes the visibility test. Radios and
  // checkboxes here are styled — the real input is zero-sized with a fake control drawn over it —
  // so a strict visible-only lookup finds nothing and the field silently goes unset, which is
  // what Smiles then rejects with "los parámetros … no fueron informados".
  const field = (sel) => { try { return q(sel) || document.querySelector(sel); } catch (e) { return null; } };

  // Fill one field and CONFIRM it took. A React-controlled widget can happily show the text we
  // assigned while its own state stays empty — the form then LOOKS complete and submits with
  // the field missing, which is exactly what Smiles rejects as "los parámetros de la solicitud
  // no fueron informados". So we read the value back, and if it didn't stick we type it in
  // keystroke by keystroke, the way these widgets do accept input.
  async function fillField(sel, val, name) {
    if (val == null || val === '') return null;
    let el = field(sel);
    if (!el) return null;                                   // not on this page — nothing to do
    setVal(el, val);
    if (((field(sel) || {}).value) === val) return null;
    el = field(sel) || el;
    await typeInto(el, val);
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return ((field(sel) || {}).value === val) ? null : name;
  }

  // Returns the list of fields it could NOT fill. Empty list = safe to submit.
  async function fillForm(d) {
    const bad = [];
    const add = (x) => { if (x) bad.push(x); };
    add(await fillField('#firstName', d.first, 'first name'));
    add(await fillField('#lastName', d.last, 'last name'));
    const nat = field('select[name="nationality"]');
    if (nat && d.nationality) { setVal(nat, d.nationality); if (nat.value !== d.nationality) bad.push('nationality'); }
    if (d.gender) {
      const g = /^f/i.test(d.gender) ? field('#female0') : field('#male0');
      if (g) {
        g.click();
        if (!g.checked) { const lab = (g.closest && g.closest('label')) || (g.id ? document.querySelector('label[for="' + g.id + '"]') : null); if (lab) realClick(lab); }
        if (!g.checked) bad.push('gender');
      }
    }
    add(await fillField('#birthday-0', d.dob, 'date of birth'));
    add(await fillField('#passport', d.passport, 'passport number'));
    add(await fillField('#passportValidity0', d.passportExp, 'passport expiry'));
    add(await fillField('#email', d.email, 'email'));
    add(await fillField('#movilddi', d.ccode || '54', 'phone country code'));
    add(await fillField('#movilddd', d.area, 'phone area code'));
    add(await fillField('#movilnumber', d.phone, 'phone number'));
    flash(bad.length ? ('⚠ Could not set: ' + bad.join(', ')) : 'Filled ✓');
    return bad;
  }

  let statusEl = null, driveStatusEl = null, driveBtn = null, sessionEl = null;
  let lastTargetSeen = null;   // most recent target read in driveTick (for the diagnostic dump)
  // Also mirrored onto <html data-ym-status> so the current state is readable even on pages
  // where neither panel is drawn (the search runs on the home page, which has no drive bar).
  function flash(m) {
    if (statusEl) statusEl.textContent = m;
    if (driveStatusEl) driveStatusEl.textContent = m;
    try { document.documentElement.dataset.ymStatus = m; } catch (e) {}
  }

  // Which flight row does this fare label belong to? = the nearest ancestor holding exactly ONE
  // #flight-SEGMENT. Returns that segment element (or null if the label isn't inside a flight card).
  function segOfFare(lab) {
    let a = lab.parentElement;
    for (let k = 0; k < 12 && a; k++) {
      const s = a.querySelectorAll('[id^="flight-SEGMENT"]');
      if (s.length === 1) return s[0];
      if (s.length > 1) return null;
      a = a.parentElement;
    }
    return null;
  }
  const visFares = () => qav('label.form-check-label').filter(l => /tasas|millas/i.test(l.innerText || ''));

  // Diagnostic: dump the results-page structure (flight cards + fare labels) so we can see exactly
  // what's on the page when the fare-select gets stuck.
  function dumpFareInfo() {
    const info = { v: VER, url: location.href.replace(/[?#].*/, ''), title: (document.title || '').slice(0, 80), path: location.pathname };
    const segs = [...document.querySelectorAll('[id^="flight-SEGMENT"]')].slice(0, 8);
    info.rows = segs.map(s => {
      let row = s;                                                    // climb to the real flight row
      for (let k = 0; k < 6 && row.parentElement; k++) { row = row.parentElement; if ((row.innerText || '').length > 60) break; }
      const btns = [...row.querySelectorAll('button, a[role="button"], [role="button"]')].filter(b => b.offsetParent).slice(0, 8).map(b => (b.innerText || '').replace(/\s+/g, ' ').slice(0, 44)).filter(Boolean);
      return { id: s.id, text: (row.innerText || '').replace(/\s+/g, ' ').slice(0, 200), btns };
    });
    info.buttons = [...document.querySelectorAll('button')].filter(b => b.offsetParent && (b.innerText || '').trim()).slice(0, 40).map(b => (b.innerText || '').replace(/\s+/g, ' ').slice(0, 44));
    info.checks = [...document.querySelectorAll('input[type=checkbox]')].filter(c => c.offsetParent).slice(0, 10).map(c => ({ id: c.id || '', checked: !!c.checked, lab: ((c.labels && c.labels[0] && c.labels[0].innerText) || (c.closest('label') && c.closest('label').innerText) || '').replace(/\s+/g, ' ').slice(0, 50) }));
    const cont = document.querySelector('#btn-continue') || [...document.querySelectorAll('button')].find(b => /^\s*continuar\s*$/i.test(b.innerText || ''));
    info.continue = cont ? { id: cont.id || '', disabled: !!cont.disabled, cls: (typeof cont.className === 'string' ? cont.className : '').slice(0, 60) } : null;
    info.fareOptions = [...document.querySelectorAll('*')].filter(e => {
      if (!e.offsetParent) return false; const t = e.innerText || '';
      return t.length < 70 && /\d[\d.]{2,}\s*\+?\s*(tasas|millas)/i.test(t) && e.querySelectorAll('*').length < 6;
    }).slice(0, 12).map(e => {
      const clk = e.closest('label, button, [role="button"], a, li, [class*="fare"], [class*="card"]') || e;
      const inp = clk.querySelector && clk.querySelector('input');
      return { tag: e.tagName.toLowerCase(), cls: (typeof e.className === 'string' ? e.className : '').slice(0, 40), text: (e.innerText || '').replace(/\s+/g, ' ').slice(0, 50), clk: clk.tagName.toLowerCase() + '.' + ((typeof clk.className === 'string' ? clk.className : '').split(/\s+/)[0] || ''), checked: inp ? !!inp.checked : null };
    });
    info.target = lastTargetSeen ? { o: lastTargetSeen.origin, d: lastTargetSeen.destination, date: lastTargetSeen.date, dep: lastTargetSeen.dep, cabin: lastTargetSeen.cabin, miles: lastTargetSeen.miles } : null;
    info.flash = driveStatusEl ? driveStatusEl.textContent : '';
    info.fareMap = visFares().slice(0, 12).map(l => { const s = segOfFare(l); return { miles: fareMiles(l), seg: s ? s.id : null }; });
    info.loggedIn = !loggedOut();
    info.fareState = visFares().slice(0, 10).map(l => { const i = fareInput(l); const s2 = segOfFare(l); return { miles: fareMiles(l), seg: s2 ? s2.id : null, input: i ? (i.type || '?') : 'none', checked: i ? !!i.checked : null, disabled: i ? !!i.disabled : null }; });
    info.fareAttempt = fareAttempt;
    // WHERE DOES THE SESSION ACTUALLY LIVE? If a reload loses it, the token is held in memory
    // and nothing can survive a page load. If it is in storage or a cookie, then reload-logout
    // is a bug with a workaround. Every check so far was on a logged-OUT page, so this has been
    // assumed rather than known. NAMES AND LENGTHS ONLY — never the values: a session token in
    // a chat log is a stolen account.
    info.store = (() => {
      const size = (v) => '(' + String(v == null ? '' : v).length + ')';
      const pick = (store) => { try { return Object.keys(store).filter(k => /tok|auth|user|sess|login|oauth|jwt|bearer|member|client/i.test(k)).slice(0, 14).map(k => k + size(store.getItem(k))); } catch (e) { return ['err']; } };
      let lsAll = 0, ssKeys = [];
      try { lsAll = Object.keys(localStorage).length; } catch (e) {}
      try { ssKeys = Object.keys(sessionStorage).slice(0, 14).map(k => k + size(sessionStorage.getItem(k))); } catch (e) {}
      let cookies = [];
      try { cookies = document.cookie.split(';').map(c => c.split('=')[0].trim()).filter(Boolean).slice(0, 20); } catch (e) {}
      // expiresToken is a plain timestamp (not a secret): it says exactly when this session
      // dies. Reported as minutes remaining so we can see whether activity extends it.
      let expiresInMin = null, raw = null;
      try { raw = sessionStorage.getItem('expiresToken'); } catch (e) {}
      if (raw && /^\d{10,13}$/.test(raw)) { const ms = raw.length <= 10 ? +raw * 1000 : +raw; expiresInMin = Math.round((ms - Date.now()) / 60000); }
      return { loggedIn: !loggedOut(), sessionExpiresInMin: expiresInMin, lsTotal: lsAll, lsAuthish: pick(localStorage), ss: ssKeys, cookieNames: cookies };
    })();
    // The trace hook.js wrote to sessionStorage — survives a reload, so it shows what the app
    // did in the seconds BEFORE the session was lost, including who called location.reload().
    info.trace = (() => {
      try {
        const arr = JSON.parse(sessionStorage.getItem('__ymTrace') || '[]');
        return arr.slice(-22).map(e => Math.round((Date.now() - e.t) / 1000) + 's ' + e.k + ' ' + e.d);
      } catch (e) { return ['unavailable']; }
    })();
    info.expired = { showing: !!redoSearchBtn(), redone: redoCount };
    info.pax = { seenMsAgo: paxSeenAt ? Date.now() - paxSeenAt : null, waitMs: paxWaitMs, submits: paxSubmits, aviso: avisoUp() };
    info.search = {
      qs: location.search.slice(0, 150),
      onTarget: lastTargetSeen ? urlMatchesTarget(lastTargetSeen) : null,
      hasBox: !!byId('airport-origin'), state: searchState, fareTries: fareTries
    };
    // total/visible count per id — Smiles duplicates ids across its mobile + desktop markup
    info.dupIds = ['btn-continue', 'type-taxes-selected', 'firstName', 'passengersConfirmButton', 'calendarGo', 'airport-origin']
      .map(id => { const all = document.querySelectorAll('[id="' + id + '"]'); return id + ' ' + all.length + '/' + [...all].filter(vis).length; });
    // Every field on the page and what it currently holds — SHAPE only: digits become # and
    // letters a, so we can see "##/##/####" vs empty vs a wrong format without the diagnostic
    // ever carrying the passenger's real name, passport or phone number.
    const shape = (s) => String(s == null ? '' : s).replace(/\d/g, '#').replace(/[A-Za-zÀ-ÿ]/g, 'a');
    info.inputs = [...document.querySelectorAll('input, select')]
      .filter(el => el.type !== 'password' && !/^(ymacct_|ymb_)/.test(el.id || ''))   // never dump credentials
      .slice(0, 30).map(el => ({
      vis: vis(el),
      id: el.id || '', name: el.getAttribute('name') || '',
      cls: (typeof el.className === 'string' ? el.className : '').slice(0, 46),
      ph: (el.placeholder || '').slice(0, 24),
      type: el.type || '',
      val: shape(el.value).slice(0, 24),
      len: (el.value || '').length,
      checked: (el.type === 'checkbox' || el.type === 'radio') ? !!el.checked : null
    }));
    info.saveBox = (() => { const c = findSaveCheckbox(); return c ? { found: true, checked: !!c.checked, id: c.id || '' } : { found: false }; })();
    info.session = sessionLogCache.slice(-24).map(e => Math.round((Date.now() - e.t) / 60000) + 'm [' + (e.tab || '?') + '] ' + (e.in ? 'in' : 'OUT') + ' ' + e.st);
    info.thisTab = TABID;
    return JSON.stringify(info);
  }
  function copyDiag() {
    const t = dumpFareInfo();
    navigator.clipboard.writeText(t).then(() => flash('✓ Copied page info — paste it to Claude.')).catch(() => {
      const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;bottom:80px;right:12px;width:300px;height:150px;z-index:2147483647'; document.body.appendChild(ta); ta.focus(); ta.select(); flash('Select-all in the box + copy by hand.');
    });
  }

  // Find Smiles' "Guardar pasajero para futuras compras" checkbox (saves them to the account
  // favorites — treated as irreversible). We NEVER want it on by accident.
  function findSaveCheckbox() {
    // Visible nodes only: a hidden duplicate reading "unchecked" would let us continue while
    // the real, on-screen box is ticked — exactly the accident this guard exists to prevent.
    const nodes = qav('label, span, div');
    const l = nodes.find(x => { const t = (x.innerText || '').trim(); return t.length < 90 && /guardar\s+pasajero/i.test(t); });
    if (!l) return null;
    // A styled checkbox is often 0x0/opacity:0, so we can't filter the INPUT by visibility —
    // instead take the copy of that id sitting inside the same section as the visible label.
    if (l.htmlFor) { const el = idNear(l.htmlFor, l); if (el && el.type === 'checkbox') return el; }
    let cb = l.querySelector && l.querySelector('input[type=checkbox]'); if (cb) return cb;
    for (const sib of [l.previousElementSibling, l.nextElementSibling]) if (sib && sib.matches && sib.matches('input[type=checkbox]')) return sib;
    cb = l.parentElement && l.parentElement.querySelector('input[type=checkbox]'); if (cb) return cb;
    return null;
  }
  // Returns true only if we can CONFIRM the save box is off. false = don't auto-continue.
  function ensureNotSaving() {
    const cb = findSaveCheckbox();
    if (!cb) return false;              // can't find it → refuse to continue
    if (cb.checked) cb.click();         // uncheck (React-friendly)
    return !cb.checked;                 // confirmed off?
  }

  // ---- fare selection on the results page (from the app's Book target) ----
  const digits = (s) => String(s == null ? '' : s).replace(/[^\d]/g, '');
  // A time like "06h30" / "6:30" → "0630" for comparing departure times.
  const hhmm = (s) => { const m = String(s == null ? '' : s).match(/(\d{1,2})\s*[:h]\s*(\d{2})/); return m ? (m[1].length < 2 ? '0' + m[1] : m[1]) + m[2] : ''; };
  // Logged out? Smiles shows an "Iniciá sesión" button and hides miles/selection until you log in.
  // "Salir" showing = definitely logged in, and it settles the question before we go looking for
  // a login button. Without that first check, a page mid-render (neither control drawn yet)
  // reads as logged OUT and produces false alarms — the spurious OUT entries in the session log.
  const loggedOut = () => {
    // The header LIES once the token has expired: it still shows the account name and "Salir"
    // while the API is already answering 401. Confirmed — the keepalive went 200 at 3 minutes
    // left and 401 at -1. So the clock beats the header.
    const left = sessionLeftMin();
    if (left != null && left <= 0) return true;
    const btns = qav('button, a');
    if (btns.some(b => /^\s*salir\s*$/i.test(b.innerText || ''))) return false;
    return btns.some(b => /inici[aá]r?\s*sesi[oó]n/i.test(b.innerText || ''));
  };

  // ---------- in-page search: drive Smiles' OWN search box, never navigate ----------
  // Measured on the live site: clicking Smiles' "Buscar" swaps the URL to /emission?... through
  // the SPA router WITHOUT reloading the document (a marker set on window survives it). Loading
  // that same URL directly is a real document load: the app reboots, and because the session is
  // held in memory it comes back signed out. That is the "every reload signs me out" problem —
  // so we fill the site's own form and press its own button instead.
  const MES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

  // Type an IATA code into an airport box and click the suggestion that carries "(CODE)".
  async function pickAirport(id, code) {
    const el = byId(id);
    if (!el) return 'no ' + id + ' box on this page';
    // the box holds the picked airport's full name ("Guarulhos (GRU)"), not the code we typed
    const taken = () => { const v = ((byId(id) || {}).value || ''); return v.toUpperCase().indexOf(code.toUpperCase()) !== -1 && v.length > code.length; };
    realClick(el); await sleep(250);
    await typeInto(el, code);
    for (let i = 0; i < 16 && !taken(); i++) {
      await sleep(400);
      const opt = qav('li').filter(l => (l.innerText || '').indexOf('(' + code + ')') !== -1 && !l.querySelector('li')).pop();
      if (!opt) continue;
      // The row is <li><a>San Pablo, Brasil, Guarulhos (GRU)</a></li> and the handler sits on
      // the INNER <a> — clicking the <li> itself does nothing at all.
      const hit = opt.querySelector('a') || opt.firstElementChild || opt;
      hit.click(); await sleep(500);
      if (!taken()) { realClick(hit); await sleep(500); }
    }
    const v = ((byId(id) || {}).value || '');
    return taken() ? '' : 'could not pick ' + code + ' (box shows "' + v + '")';
  }

  // Pick a date in the react-dates calendar. Day cells carry a Spanish aria-label
  // ("viernes, 16 de octubre de 2026"); unavailable ones are prefixed "Not available.".
  async function pickDate(iso) {
    const p = String(iso || '').split('-');
    if (p.length !== 3) return 'no search date on this flight';
    const y = p[0], mi = +p[1] - 1, day = String(+p[2]);
    const cal = byId('calendarGo');
    if (!cal) return 'no date field on this page';
    // Two react-dates quirks: it opens on FOCUS (a synthetic click doesn't move focus the way a
    // real one does), and it keeps the neighbouring months mounted at visibility:hidden — those
    // cells click just fine, so day cells are filtered by being RENDERED, never by visibility.
    const days = () => { try { return [...document.querySelectorAll('[class*="CalendarDay"]')].filter(e => e.getClientRects().length); } catch (e) { return []; } };
    try { cal.focus(); } catch (e) {}
    realClick(cal);
    for (let i = 0; i < 12 && !days().length; i++) await sleep(300);
    if (!days().length) return 'the date calendar would not open';
    const want = ('0' + (+p[2])).slice(-2) + '/' + ('0' + (mi + 1)).slice(-2) + '/' + y;
    const set = () => ((byId('calendarGo') || {}).value || '') === want;
    for (let hop = 0; hop < 14 && !set(); hop++) {
      const cell = days().find(c => {
        const a = (c.getAttribute('aria-label') || '').toLowerCase();
        if (!a || a.indexOf('not available') === 0) return false;
        return a.indexOf(MES[mi]) !== -1 && a.indexOf(y) !== -1 && new RegExp('(^|\\D)' + day + '(\\D|$)').test(a);
      });
      if (cell) {
        cell.click(); await sleep(600);
        if (!set()) { realClick(cell); await sleep(600); }
        if (!set() && cell.firstElementChild) { cell.firstElementChild.click(); await sleep(600); }
        break;
      }
      // month arrows are role=button divs labelled "Move forward to switch to the next month."
      const fwd = document.querySelector('[aria-label*="Move forward" i]')
        || [...document.querySelectorAll('.DayPickerNavigation_button, [class*="DayPickerNavigation"] [role="button"]')].pop();
      if (!fwd) break;
      fwd.click(); await sleep(700);
    }
    const got = ((byId('calendarGo') || {}).value || '');
    return got === want ? '' : 'could not set the date (field shows "' + got + '", wanted ' + want + ')';
  }

  // Fill the whole search form and press Buscar. Returns '' on success, else why it stopped.
  // Get back to the home page WITHOUT a document load, by clicking the site's own home link
  // (the Smiles logo / "Buscá tu vuelo", both href="/"). Measured: the SPA router handles that
  // click, the page never reloads, and the session comes through intact.
  async function goHomeInPage() {
    const links = qav('a').filter(a => (a.getAttribute('href') || '') === '/');
    const home = links.find(a => /smiles/i.test(a.innerText || '') || /logo|brand/i.test((a.className || '').toString())) || links[0];
    if (!home) { logSession({ st: 'search: NO home link found', ok: false, in: !loggedOut() }); return false; }
    logSession({ st: 'search: clicking home link "' + (home.innerText || '').trim().slice(0, 16) + '"', ok: true, in: !loggedOut() });
    home.click();                                        // plain click: the router intercepts it
    for (let i = 0; i < 20 && !byId('airport-origin'); i++) await sleep(400);
    const ok = !!byId('airport-origin');
    logSession({ st: 'search: home ' + (ok ? 'reached, box up' : 'NOT reached'), ok: ok, in: !loggedOut() });
    return ok;
  }

  async function searchInPage(t) {
    // NEVER search from the results page — its Buscar RELOADS the document (measured), and a
    // reload signs the account out. Leave for the home page FIRST, every time: a search box
    // being visible here is not good enough, because it is the wrong Buscar.
    logSession({ st: 'search: start on ' + location.pathname, ok: true, in: !loggedOut() });
    if (onEmission()) {
      if (!await goHomeInPage()) return 'could not reach the Smiles home page without reloading — search it yourself in this tab';
    }
    if (!byId('airport-origin')) return 'no search box on this page — open smiles.com.ar in this tab, then press Book again';
    const solo = btnByText(/^s[óo]lo ida$/i);            // one-way, else it wants a return date
    if (solo && !/search-btn-active/.test((solo.className || '').toString())) { realClick(solo); await sleep(900); }
    let e = await pickAirport('airport-origin', t.origin); if (e) return e;
    e = await pickAirport('airport-destination', t.destination); if (e) return e;
    e = await pickDate(t.date); if (e) return e;
    const ad = byId('input-adult');                      // passengers: click +, the box is React-controlled
    if (ad) {
      const want = Math.max(1, t.adults || 1);
      let cur = parseInt(ad.value, 10) || 1;
      const inc = ad.parentElement && ad.parentElement.querySelector('button.control.increase');
      for (let i = 0; i < 8 && cur < want && inc; i++) { realClick(inc); await sleep(320); cur = parseInt(((byId('input-adult') || {}).value), 10) || cur; }
    }
    const go = btnByText(/^buscar/i);
    if (!go) return 'could not find the Buscar button';
    // Belt and braces. Pressing Buscar on /emission reloads the document and signs the account
    // out — it is the one action that has actually cost sessions. Even if everything above
    // silently failed, we refuse to press it from there.
    if (onEmission()) { logSession({ st: 'search: REFUSED Buscar on /emission', ok: false, in: !loggedOut() }); return 'still on the results page — not pressing Buscar there (it reloads and signs you out)'; }
    logSession({ st: 'search: pressing Buscar on ' + location.pathname, ok: true, in: !loggedOut() });
    realClick(go);
    return '';
  }

  // Smiles expires a search after a while: "Límite de tiempo caducado — la información y los
  // valores de los vuelos deben actualizarse constantemente… es necesario hacer una nueva
  // búsqueda", offering its own "Rehacer búsqueda" button. This is NOT a logout — the account
  // stays signed in, only the prices went stale. Pressing that button re-runs the search in
  // place, so it is also the safe way to refresh availability: no page load, no lost session.
  const redoSearchBtn = () => btnByText(/rehacer\s+b[uú]squeda/i);

  // Are we already looking at the results for the flight we were asked to book?
  function urlMatchesTarget(t) {
    let p; try { p = new URLSearchParams(location.search); } catch (e) { return false; }
    return (p.get('originAirportCode') || '').toUpperCase() === (t.origin || '').toUpperCase()
      && (p.get('destinationAirportCode') || '').toUpperCase() === (t.destination || '').toUpperCase()
      && (p.get('departureDate') || '') === (t.date || '');
  }

  // Select the target flight by departure time + cabin (each flight is a #flight-SEGMENT_1-N row
  // like "LGA 06h30 … YUL 07h57 Clase Económica"). Click the row's select button (not "Detalles").
  function selectFare(target) {
    const wantTime = hhmm(target.dep);
    const wantExec = /business|ejecutiv/i.test(target.cabin || '');
    const O = (target.origin || '').toUpperCase(), D = (target.destination || '').toUpperCase();
    const segs = qav('[id^="flight-SEGMENT"]');
    // CRITICAL: the #flight-SEGMENT element's own text is just "Detalles del vuelo" — the times/
    // route/cabin live on its ancestor CARD. Match the card's text, never the segment's. Stop
    // climbing before an ancestor that holds two flights, or we'd read the neighbour's times.
    const cardOf = (s) => {
      let r = s, best = s;
      for (let k = 0; k < 8 && r.parentElement; k++) {
        r = r.parentElement;
        if (r.querySelectorAll('[id^="flight-SEGMENT"]').length > 1) break;
        best = r;
        if ((r.innerText || '').length > 60) break;
      }
      return best;
    };
    const cards = segs.map(s => {
      const c = cardOf(s), t = c.innerText || '';
      // EVERY time on the card, in order — the first one is NOT always the departure (a
      // duration like "1h27" reads the same), so we match the departure first, then any time.
      return { seg: s, card: c, t: t, T: t.toUpperCase(), times: (t.match(/\d{1,2}\s*[h:]\s*\d{2}/g) || []).map(hhmm) };
    });
    const routeOk = (c) => (!O || c.T.indexOf(O) !== -1) && (!D || c.T.indexOf(D) !== -1);
    const cabinOk = (c) => { const ex = /ejecutiva|business/i.test(c.t); return wantExec ? ex : !ex; };
    const m = cards.find(c => routeOk(c) && cabinOk(c) && c.times[0] === wantTime)
      || cards.find(c => routeOk(c) && cabinOk(c) && c.times.indexOf(wantTime) !== -1)
      || cards.find(c => routeOk(c) && c.times[0] === wantTime)
      || cards.find(c => routeOk(c) && c.times.indexOf(wantTime) !== -1);
    if (!m) return { done: false, flights: segs.length, note: 'no ' + O + '→' + D + ' ' + wantTime + (wantExec ? ' exec' : ' econ') + ' row' };
    // Find the fare labels that BELONG to this flight (walk up from each label to its owning row).
    const fares = visFares().filter(l => segOfFare(l) === m.seg);
    if (!fares.length) {   // no inline fare in this flight's card — click the row to open its fare view
      const pickBtn = (root) => [...root.querySelectorAll('button, [role="button"], a')].filter(vis).find(b => !/detalles/i.test(b.innerText || ''));
      realClick(pickBtn(m.seg) || pickBtn(m.card) || m.seg);
      return { done: true, note: 'clicked row' };
    }
    // One of this flight's fares already selected? Then a previous click landed — touch nothing.
    // (Clicking a selected fare DESELECTS it and takes the booking context with it.)
    if (fares.some(labelChecked)) return { done: true, note: 'fare selected' };
    // We book the fare we QUOTED — normally the Club price, the first entry in target.miles.
    // Never quietly fall back to a dearer fare: taking 13.000 when the quote said 11.400 costs
    // real miles on every booking. If the fare we want won't select, we stop and say so.
    const wants = (target.miles || []).map(digits).filter(Boolean);
    const want = wants.find(w => fares.some(l => fareMiles(l) === w));
    const lab = want ? fares.find(l => fareMiles(l) === want) : null;
    if (!lab) return { done: false, flights: segs.length, note: 'no ' + (wants[0] || '?') + ' fare here (this flight offers ' + fares.map(fareMiles).join('/') + ')' };
    const inp = fareInput(lab);
    if (inp && inp.disabled) return { done: false, flights: segs.length, note: want + ' is DISABLED for this account — pick the fare yourself' };
    // Which element carries the handler varies (we've already been bitten by it living on an
    // inner <a> and on a row <li>), so work through input → label → row, one per pass, checking
    // in between whether it took. Each target is tried once: a second click would deselect.
    const targets = [inp, lab, lab.closest('li, .form-check')].filter(Boolean);
    if (fareAttempt >= targets.length) return { done: false, flights: segs.length, note: 'clicked the ' + want + ' fare every way I know and it will not select — click it yourself and I\'ll carry on' };
    const hit = targets[fareAttempt++];
    realClick(hit);
    return { done: true, note: 'picked ' + want + ' (via ' + (hit.tagName || '?').toLowerCase() + ')' };
  }

  // Leading miles on a fare label ("11.400 + tasas o impuestos Club…" → "11400").
  const fareMiles = (lab) => digits((lab.innerText || '').split(/\+|tasas|millas/i)[0]);
  // The radio behind a fare label. htmlFor goes through idNear, not getElementById, because a
  // hidden duplicate of that id would otherwise answer for the real one.
  function fareInput(lab) {
    if (!lab) return null;
    if (lab.htmlFor) { const el = idNear(lab.htmlFor, lab); if (el && /^(radio|checkbox)$/.test(el.type || '')) return el; }
    const inside = lab.querySelector && lab.querySelector('input'); if (inside) return inside;
    const prev = lab.previousElementSibling; if (prev && prev.matches && prev.matches('input')) return prev;
    const box = lab.closest && lab.closest('li, .form-check');
    return (box && box.querySelector('input')) || null;
  }
  const labelChecked = (lab) => { const i = fareInput(lab); return !!(i && i.checked); };
  // A fare this account can't take (Club-only pricing, or sold out) — clicking it does nothing.
  function fareDisabled(lab) {
    const inp = fareInput(lab);
    if (inp && inp.disabled) return true;
    const box = lab.closest('li, .form-check');
    return !!(box && /disabled/i.test((box.className || '').toString()));
  }
  // On the fare/tax step, pick the MILLAS fare matching the target miles (prefer club = first want).
  // Don't re-click one that's already selected — some are checkboxes and a 2nd click deselects.
  function selectMilesFare(target) {
    const wants = (target.miles || []).map(digits).filter(Boolean);
    const labels = [...document.querySelectorAll('label.form-check-label')].filter(l => l.offsetParent);
    for (const w of wants) {
      const m = labels.find(l => fareMiles(l) === w);
      if (m) { if (!labelChecked(m)) m.click(); return w; }
    }
    return null;
  }
  // On the fare/tax step? (fare options carrying "tasas/millas" text, the tax slider, or terms box.)
  function onFareTax() {
    return !!(q('#type-taxes-selected') || q('label.form-check-label-emission.check-tc') || visFares().length);
  }
  // Agree the terms checkbox — find it by nearby wording; only click if not already checked.
  function agreeTerms() {
    const cbs = [...document.querySelectorAll('input[type=checkbox]')].filter(c => c.offsetParent);
    for (const c of cbs) {
      const lab = (c.labels && c.labels[0] && c.labels[0].innerText) || (c.closest('label') && c.closest('label').innerText) || (c.parentElement && c.parentElement.innerText) || '';
      if (/acuerdo|acepto|t[eé]rminos|condiciones|pol[ií]tica/i.test(lab)) { if (!c.checked) c.click(); return true; }
    }
    const tc = q('label.form-check-label-emission.check-tc');
    if (tc) { const inp = tc.htmlFor ? idNear(tc.htmlFor, tc) : (tc.querySelector('input') || null); if (!inp || !inp.checked) realClick(tc); return true; }
    return false;
  }
  // Click "Continuar": by id, else by button text. Smiles disables it via a CSS class (not the
  // .disabled property), so check both. Returns 'clicked' | 'disabled' | 'none'.
  function clickContinue() {
    let c = byId('btn-continue');
    if (!c) c = btnByText(/^\s*continuar\s*$/i);
    if (!c) return 'none';
    if (c.disabled || /(^|\s)disabled(\s|$)/.test(typeof c.className === 'string' ? c.className : '')) return 'disabled';
    realClick(c); return 'clicked';
  }

  // ---------------- auto-drive state machine ----------------
  // Smiles is a single-page app — navigations don't reload the script. Guard by the path we last
  // acted on (resets automatically when the step changes) instead of a once-per-load flag.
  let actedStep = '';
  let lastAdvance = 0;   // when we last clicked Continuar (cooldown so we don't double-submit)
  let lastFareTry = 0;   // the flight pick RETRIES: one shot was the old bug (a missed click stuck forever)
  let fareTries = 0;
  let fareAttempt = 0;   // which click target we're on for the wanted fare (never repeat one)
  let lastRedo = 0, redoCount = 0, lastExpirySeen = 0, lastLogoutLog = 0;
  let forceSearch = false;   // expiry dialog is up: re-search even though the URL still matches   // Smiles' "Límite de tiempo caducado" -> Rehacer búsqueda
  let paxSeenAt = 0, paxWaitMs = 5000, paxSubmits = 0;   // the passenger page needs time to load its booking
  // Smiles' error popup ("Aviso … Entendí") — its OK button is the reliable marker.
  const avisoUp = () => !!btnByText(/^entend[ií]$/i);
  let loggedOutTicks = 0;                                  // the SPA renders "Iniciá sesión" while booting
  let searchState = { key: '', phase: '', err: '', tries: 0 };   // in-page search bookkeeping
  const targetKey = (t) => [t.origin, t.destination, t.date].join('|').toUpperCase();
  // Strip the search params my Book navigation put in the URL, so a plain user reload afterwards
  // does NOT re-run the last search. Called whenever the drive ends.
  // NOTE: we used to strip the query string when a drive ended, so a later reload wouldn't
  // re-run the last search. That belonged to the old flow where Book put the search into the
  // URL itself. It must never come back: rewriting the URL of a live SPA leaves /emission with
  // no route or date, the results page has nothing to render, and you get a WHITE PAGE. Smiles
  // now puts those params there itself, exactly as it would for a person — leave them alone.
  function resetDriveState() { actedStep = ''; fareTries = 0; fareAttempt = 0; forceSearch = false; paxSeenAt = 0; paxWaitMs = 5000; paxSubmits = 0; lastFareTry = 0; loggedOutTicks = 0; searchState = { key: '', phase: '', err: '', tries: 0 }; }
  function startDrive() { resetDriveState(); sSet({ [DRIVE]: { on: true, startedAt: Date.now() } }); flash('Auto-drive ON — search → pick the flight → terms → fill → stop at checkout.'); }
  function stopDrive() { sSet({ [DRIVE]: { on: false }, [TARGET]: null }); flash('Auto-drive stopped.'); }
  // Which step of the booking we're on. fare + tax share /emission, so we can't guard by path alone.
  function currentStep() {
    if (onCheckout()) return 'checkout';
    if (onPax()) return 'pax';
    if (!onEmission()) return '';
    // Fare/tax step = the tax slider, terms box, or a Continuar button is present (these appear only
    // after a fare is selected — the plain results list has none of them).
    if (q('#type-taxes-selected') || document.querySelector('label.form-check-label-emission.check-tc') || q('#btn-continue')) return 'tax';
    // Results list = pick a flight/fare here.
    if (document.querySelector('[id^="flight-SEGMENT"]')) return 'fare';
    if (onFareTax()) return 'tax';
    return '';
  }
  function driveTick() {
    sGet([DRIVE, KEY, TARGET], (st) => {
      const drive = (st && st[DRIVE]) || {};
      const data = (st && st[KEY]) || {};
      const target = (st && st[TARGET]) || null;
      lastTargetSeen = target;
      setDriveBtn(drive.on);
      if (!drive.on) { if (driveStatusEl) driveStatusEl.textContent = target ? ('Ready: ' + (target.summary || 'a flight') + ' — hit ▶ to book') : ''; return; }
      if (drive.startedAt && Date.now() - drive.startedAt > 6 * 60 * 1000) { sSet({ [DRIVE]: { on: false }, [TARGET]: null }); return; }  // stale drive: shut down, but NEVER touch the URL
      const step = currentStep();
      if (step === 'checkout') { sSet({ [DRIVE]: { on: false }, [TARGET]: null }); flash('✋ Your turn — enter the Smiles password + captcha + card, then Confirmar pago.'); return; }

      // Search expired ("Límite de tiempo caducado"). Touch NOTHING here.
      // Measured: Smiles' own "Rehacer búsqueda" reloads the document. And v0.90's idea —
      // quietly re-running our own search from this page instead — reloaded it too, which is
      // how a signed-in tab went straight from "in 200" to "PAGE-LOAD(reload)" and out. From
      // the results page there is currently NO known way to refresh a search without a reload,
      // so we stop and say so rather than spend the session guessing.
      // Search expired ("Límite de tiempo caducado")? Never press Smiles' own button — it
      // reloads. Instead force our own search, which now goes home first and searches from
      // there: the one route measured to refresh results without a document load.
      // Search expired. The dialog greys the page out for a PERSON — the only thing you can
      // click is Smiles' own button, and that reloads. Our clicks go straight to the element,
      // so we can still reach the home link underneath it. That makes this the only route out
      // that keeps the session, and it is now fenced: searchInPage always leaves /emission
      // first and flatly refuses to press Buscar there.
      if (redoSearchBtn() && target) forceSearch = true;
      // A booking takes about a minute. Starting one with almost no session left just burns the
      // search and strands you mid-flow, so say it up front instead of failing at checkout.
      const leftMin = sessionLeftMin();
      if (target && leftMin != null && leftMin < 2) {
        flash('⛔ Session expires in ' + leftMin + ' min — log in again on this tab first, then press Book. Starting now would die mid-booking.');
        return;
      }

      // Not on the results for this flight yet? Run Smiles' OWN search here, in-page. We never
      // load a URL into this tab: that reboots the app and signs the account out. Searching
      // needs no account, so this runs BEFORE the logged-in check — being signed out should
      // never stop us getting the results on screen.
      if (target && !onPax() && !onCheckout() && step !== 'tax' && (!urlMatchesTarget(target) || forceSearch)) {
        const key = targetKey(target);
        if (searchState.key !== key) searchState = { key: key, phase: '', err: '', tries: 0 };
        const where = target.origin + '→' + target.destination + ' ' + (target.date || '');
        if (searchState.phase === 'running') { flash('🔎 Searching ' + where + ' in this tab…'); return; }
        if (searchState.tries >= 3) { flash('⚠ Could not run the search here: ' + (searchState.err || '?') + ' — search it yourself in this tab and I\'ll take over.'); return; }
        searchState.phase = 'running'; searchState.tries++; forceSearch = false;
        flash('🔎 ' + (redoSearchBtn() ? 'Search expired — running a fresh one for ' : 'Searching ') + where + '…');
        searchInPage(target).then(err => {
          searchState.err = err || ''; searchState.phase = err ? 'failed' : 'done';
          if (err) flash('⚠ ' + err);
        }).catch(ex => { searchState.err = String(ex); searchState.phase = 'failed'; });
        return;
      }

      // Past the search, everything left (picking a fare, continuing, the passenger form) needs
      // the account. Don't panic at the first sight of "Iniciá sesión" though — the SPA paints
      // the logged-out header for a moment while it restores the session; only flag it if it sticks.
      if (loggedOut()) {
        const lm = sessionLeftMin();
        if (lm != null && lm <= 0) { flash('⛔ Session EXPIRED (the page still shows you logged in — it is wrong). Log in again on this tab, then press Book.'); return; }
        if (++loggedOutTicks < 4) { flash('⏳ Checking the session…'); return; }
        // Logging back in means a captcha, which can take a while. Hold the 6-minute stale-drive
        // timer off while we're waiting, so the flight you pressed Book on is still armed when
        // you get back in and the booking carries on instead of starting over.
        if (drive.startedAt && Date.now() - drive.startedAt > 3 * 60 * 1000) {
          sSet({ [DRIVE]: { on: true, startedAt: Date.now() } });
        }
        if (Date.now() - lastLogoutLog > 60000) { lastLogoutLog = Date.now(); logSession({ st: 'LOGGED OUT while driving ' + location.pathname, ok: false, in: false }); }
        flash('⚠ This Smiles tab is logged OUT — log in on THIS tab and I\'ll pick up where I left off (your flight is still armed).');
        return;
      }
      loggedOutTicks = 0;

      if (!step) { if (target) flash('⏳ Loading ' + target.origin + '→' + target.destination + ' ' + (target.date || '') + '…'); return; }
      if (step === 'fare') {
        if (!target) { flash('👉 Click the fare you want — I take over from there.'); return; }
        // selectFare never clicks the same fare twice (that would DESELECT it and throw away the
        // booking context), so retrying here is safe: each pass either confirms the selection
        // took or moves on to the next fare this account can actually use.
        if (Date.now() - lastFareTry < 5000) return;          // give React time to settle
        lastFareTry = Date.now(); fareTries++;
        const r = selectFare(target);
        if (r.done) flash('✓ ' + (r.note || 'Selected ' + (target.summary || 'your flight')) + ' — continuing…');
        else if (fareTries > 6) flash('⚠ ' + (r.note || 'could not find ' + (target.summary || 'that flight') + ' among ' + r.flights + ' shown') + ' — click it yourself and I\'ll carry on.');
        else flash('Finding your flight — ' + r.flights + ' shown; ' + (r.note || '') + '…');
        return;
      }
      if (step === 'pax') {
        if (!field('#firstName')) { paxSeenAt = 0; return; }  // form not rendered yet
        if (!paxSeenAt) paxSeenAt = Date.now();

        // Smiles' own "Aviso" popup after we submitted = it took the request while the booking
        // wasn't loaded. Nothing was created, so dismiss it, wait longer, and try once more.
        if (actedStep === 'pax' && avisoUp()) {
          if (paxSubmits >= 2) {
            sSet({ [DRIVE]: { on: false } });
            flash('⛔ Smiles rejected the submit twice. The form IS filled correctly — dismiss the notice and click Continuar yourself.');
            return;
          }
          const ok = btnByText(/^entend[ií]$/i);
          if (ok) realClick(ok);
          actedStep = ''; paxSeenAt = Date.now(); paxWaitMs = 12000;
          flash('↻ Smiles said the request was incomplete — letting the page settle and trying once more…');
          return;
        }
        if (actedStep === 'pax') return;                     // filled + submitted; waiting on the page

        // THE FORM RENDERS BEFORE THE BOOKING IS LOADED. Fill and submit into that gap and
        // Smiles answers "los parámetros de la solicitud no fueron informados" — every field
        // present on screen, the reservation simply not there yet. So wait for the price
        // summary (Total / pasajero) to appear, and give it a moment beyond that.
        const body = document.body.innerText || '';
        const summaryUp = /total/i.test(body) && /pasajer/i.test(body);
        const waited = Date.now() - paxSeenAt;
        if (waited < paxWaitMs || (!summaryUp && waited < 20000)) {
          flash('⏳ Letting the passenger page finish loading' + (summaryUp ? '' : ' (waiting for the price summary)') + '…');
          return;
        }
        if (!data.first || !data.last) {
          flash('⚠ Fill the passenger (top-right panel) — I fill from there. Need at least first + last name.');
          const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#f59e0b';
          return;
        }
        const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#2b6cff';
        actedStep = 'pax';
        fillForm(data).then((bad) => {
          // Never submit a form we know is incomplete — that is what produces Smiles' useless
          // "los parámetros … no fueron informados" popup. Name the field instead.
          if (bad.length) {
            sSet({ [DRIVE]: { on: false } });
            flash('⛔ Stopped before submitting — Smiles would not accept: ' + bad.join(', ') + '. Fill ' + (bad.length > 1 ? 'those' : 'that') + ' by hand and click Continuar.');
            return;
          }
          setTimeout(() => {
            if (!ensureNotSaving()) {   // couldn't guarantee "Guardar pasajero" is OFF → stop, don't advance
              sSet({ [DRIVE]: { on: false } });
              flash('⛔ Filled, but I could NOT confirm "Guardar pasajero" is unchecked — stopped so no one is saved by accident. Uncheck it + click Continuar yourself.');
              return;
            }
            const b = byId('passengersConfirmButton');
            if (b) { paxSubmits++; realClick(b); flash('✓ Passenger submitted — waiting for checkout…'); }
          }, 2200);
        }).catch((ex) => {
          sSet({ [DRIVE]: { on: false } });
          flash('⛔ Stopped while filling the passenger: ' + String(ex).slice(0, 80));
        });
        return;
      }
      if (step === 'tax') {
        // Patient watcher: agree terms (idempotent) and click Continuar the moment it's enabled.
        // Don't touch the fare — you pick 11.400/13.000 (the one flaky click); I do the rest.
        agreeTerms();
        if (Date.now() - lastAdvance < 2500) return;         // just clicked — let the page move
        const r = clickContinue();
        if (r === 'clicked') { lastAdvance = Date.now(); flash('✓ Continuing…'); return; }
        flash(r === 'disabled'
          ? '👉 Pick the millas fare (11.400 / 13.000) — terms done; I continue the instant it\'s selected.'
          : 'Waiting for the fare page…');
        return;
      }
    });
  }

  // ---------------- UI ----------------
  function setDriveBtn(on) {
    if (!driveBtn) return;
    driveBtn.textContent = on ? '■ Stop auto-drive' : '▶ Auto-book to checkout';
    driveBtn.style.background = on ? '#dc2626' : '#4f46e5';
  }
  function buildDriveBar() {
    if (document.getElementById('__ymDrive')) return;
    const bar = document.createElement('div'); bar.id = '__ymDrive';
    bar.style.cssText = 'position:fixed;bottom:12px;right:12px;z-index:2147483646;background:#0b1220;color:#e6f0ff;font:12px system-ui,sans-serif;border:1px solid #4f46e5;border-radius:11px;padding:10px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
    bar.innerHTML = '<div style="font-weight:700;margin-bottom:6px">YM · auto-drive <span style="opacity:.55;font-weight:400">v' + VER + '</span></div><div style="font-size:11px;opacity:.8;margin-bottom:7px">Press Book in the processor — this tab searches, picks the flight, and stops at checkout.</div>';
    driveBtn = document.createElement('button');
    driveBtn.style.cssText = 'width:100%;cursor:pointer;border:0;border-radius:7px;padding:8px;color:#fff;font:13px system-ui;font-weight:700;background:#4f46e5';
    driveBtn.addEventListener('click', () => { sGet(DRIVE, s => { const on = s && s[DRIVE] && s[DRIVE].on; if (on) stopDrive(); else startDrive(); }); });
    bar.appendChild(driveBtn);
    driveStatusEl = document.createElement('div'); driveStatusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; bar.appendChild(driveStatusEl);
    sessionEl = document.createElement('div'); sessionEl.style.cssText = 'margin-top:5px;font-size:11px;opacity:.75'; bar.appendChild(sessionEl);
    const diagBtn = document.createElement('button');
    diagBtn.textContent = '🔎 Copy page info';
    diagBtn.style.cssText = 'width:100%;margin-top:7px;cursor:pointer;border:1px solid #33507f;border-radius:7px;padding:6px;color:#cfe3ff;background:transparent;font:11px system-ui';
    diagBtn.addEventListener('click', copyDiag);
    bar.appendChild(diagBtn);
    document.body.appendChild(bar);
  }


  // ---------------- saved accounts: fill the login, human does the captcha ----------------
  // Fills #dni and #password so signing in is one captcha tick and one click. The captcha is
  // deliberately left alone: it is the site's anti-automation control, and defeating it across a
  // pool of accounts holding bought miles is how the pool gets lost. Credentials live in this
  // browser profile's extension storage, are never transmitted, and never enter the dump.
  function buildLoginPanel() {
    if (document.getElementById('__ymLogin')) return;
    sGet(ACCTS, (st) => {
      if (document.getElementById('__ymLogin')) return;
      const accts = (st && st[ACCTS]) || [];
      const esc = (x) => String(x || '').replace(/"/g, '&quot;').replace(/</g, '&lt;');
      const F = 'width:100%;margin:3px 0;padding:6px 7px;border:1px solid #2f6b45;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box';
      const box = document.createElement('div');
      box.id = '__ymLogin';
      box.style.cssText = 'position:fixed;top:90px;right:12px;z-index:2147483647;background:#0b1220;color:#e6f0ff;font:12px system-ui,-apple-system,sans-serif;border:1px solid #16a34a;border-radius:11px;padding:11px;width:250px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
      box.innerHTML =
        '<div style="font-weight:700;margin-bottom:6px">YM · accounts <span style="opacity:.55;font-weight:400">v' + VER + '</span></div>' +
        '<select id="ymacct_pick" style="' + F + '"><option value="">— pick a saved account —</option>' +
        accts.map((a, i) => '<option value="' + i + '">' + esc(a.name || a.dni) + '</option>').join('') + '</select>' +
        '<div style="font-size:11px;opacity:.7;margin:8px 0 2px">Add / update an account</div>' +
        '<input id="ymacct_name" placeholder="Label (e.g. Antonella)" style="' + F + '">' +
        '<input id="ymacct_dni" placeholder="DNI" style="' + F + '">' +
        '<input id="ymacct_pass" type="password" placeholder="Password" style="' + F + '">';
      const status = document.createElement('div');
      status.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px';
      const fill = (a) => {
        if (!a) return;
        setVal(field('#dni'), a.dni || '');
        setVal(field('#password'), a.pass || '');
        status.textContent = 'Filled ' + (a.name || a.dni) + ' — tick the captcha, then Iniciá sesión.';
      };
      const btn = document.createElement('button');
      btn.textContent = 'Save this account';
      btn.style.cssText = 'width:100%;margin-top:8px;cursor:pointer;border:0;border-radius:7px;padding:8px;background:#16a34a;color:#fff;font:12px system-ui;font-weight:700';
      btn.addEventListener('click', () => {
        const g = (id) => (document.getElementById(id) || {}).value || '';
        const a = { name: g('ymacct_name'), dni: g('ymacct_dni'), pass: g('ymacct_pass') };
        if (!a.dni || !a.pass) { status.textContent = 'Need a DNI and a password.'; return; }
        sGet(ACCTS, (s2) => {
          const list = (s2 && s2[ACCTS]) || [];
          const at = list.findIndex(x => x.dni === a.dni);
          if (at >= 0) list[at] = a; else list.push(a);
          sSet({ [ACCTS]: list }, () => { status.textContent = 'Saved. It is in the list next time this page loads.'; fill(a); });
        });
      });
      box.appendChild(btn);
      box.appendChild(status);
      document.body.appendChild(box);
      const pick = document.getElementById('ymacct_pick');
      if (pick) pick.addEventListener('change', () => fill(accts[+pick.value]));
      if (accts.length === 1) fill(accts[0]);        // only one saved? fill it on sight
    });
  }

  function buildPanel() {
    if (document.getElementById('__ymBook')) return;
    sGet(KEY, (s) => {
      if (document.getElementById('__ymBook')) return;
      const d = (s && s[KEY]) || {};
      const box = document.createElement('div'); box.id = '__ymBook';
      box.style.cssText = 'position:fixed;top:74px;right:12px;z-index:2147483647;background:#0b1220;color:#e6f0ff;font:12px system-ui,-apple-system,sans-serif;border:1px solid #2b6cff;border-radius:11px;padding:11px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
      const v = (x) => (x || '').replace(/"/g, '&quot;');
      const fld = (id, ph, val, w) => `<input id="ymb_${id}" placeholder="${ph}" value="${v(val)}" style="width:${w || '100%'};margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box">`;
      box.innerHTML =
        '<div style="font-weight:700;margin-bottom:7px">YM · fill passenger</div>' +
        fld('first', 'First name', d.first) + fld('last', 'Last name', d.last) +
        '<select id="ymb_nationality" style="width:100%;margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box"><option value="">Nationality…</option></select>' +
        `<div style="margin:4px 0">Gender &nbsp;<label><input type="radio" name="ymb_gender" value="M" ${d.gender !== 'F' ? 'checked' : ''}> M</label> &nbsp;<label><input type="radio" name="ymb_gender" value="F" ${d.gender === 'F' ? 'checked' : ''}> F</label></div>` +
        fld('dob', 'DOB  DD/MM/YYYY', d.dob) + fld('passport', 'Passport #', d.passport) + fld('passportExp', 'Passport exp  DD/MM/YYYY', d.passportExp) +
        fld('email', 'Email', d.email) +
        `<div style="display:flex;gap:5px">${fld('ccode', 'Cód', d.ccode || '54', '46px')}${fld('area', 'Area', d.area, '58px')}${fld('phone', 'Phone', d.phone, 'auto')}</div>`;
      const btn = document.createElement('button');
      btn.textContent = 'Fill Smiles form';
      btn.style.cssText = 'width:100%;margin-top:8px;cursor:pointer;border:0;border-radius:7px;padding:8px;background:#16a34a;color:#fff;font:13px system-ui;font-weight:700';
      btn.addEventListener('click', saveAndFill);
      box.appendChild(btn);
      statusEl = document.createElement('div'); statusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; box.appendChild(statusEl);
      document.body.appendChild(box);
      const autosave = () => sSet({ [KEY]: collect() });   // typing here = remembered; local only, NOT saved to Smiles
      box.querySelectorAll('input, select').forEach(el => { el.addEventListener('input', autosave); el.addEventListener('change', autosave); });
      const smilesNat = q('select[name="nationality"]'), panelNat = document.getElementById('ymb_nationality');
      if (smilesNat && panelNat && smilesNat.options.length) {
        panelNat.innerHTML = '<option value="">Nationality…</option>' + [...smilesNat.options].filter(o => o.value).map(o => `<option value="${(o.value || '').replace(/"/g, '&quot;')}">${(o.text || '').replace(/</g, '&lt;')}</option>`).join('');
        if (d.nationality) panelNat.value = d.nationality;
      }
    });
  }
  function collect() {
    const data = {}; FIELDS.forEach(k => { const el = document.getElementById('ymb_' + k); if (el) data[k] = el.value; });
    const gr = document.querySelector('input[name="ymb_gender"]:checked'); data.gender = gr ? gr.value : 'M';
    const natEl = document.getElementById('ymb_nationality'); data.nationality = natEl ? natEl.value : '';
    return data;
  }
  function saveAndFill() { const data = collect(); sSet({ [KEY]: data }); fillForm(data); }

  // ---------------- session keepalive + timeout probe ----------------
  // Smiles drops the session after roughly an hour. Whether that clock RESETS on use (idle
  // timeout) or runs regardless (hard expiry) decides whether accounts can be kept warm or need
  // a captcha login every hour — so we poke the session every few minutes and log what came
  // back. The log is the evidence for which of the two it is.
  const SESSLOG = 'ymSessionLog';
  // Every Smiles tab writes to one shared log — including the throwaway tabs the background
  // search opens — so an entry is ambiguous without knowing which tab it came from.
  // sessionStorage is per-tab AND survives a reload, so it gives each tab a stable short name.
  let TABID = '?';
  try {
    TABID = sessionStorage.getItem('__ymTab') || Math.random().toString(36).slice(2, 6);
    sessionStorage.setItem('__ymTab', TABID);
  } catch (e) {}
  let lastKeepAlive = 0, keepAliveWaiting = false;
  let sessionLogCache = [];    // mirrored in memory so the diagnostic dump can read it synchronously
  sGet(SESSLOG, (s) => { sessionLogCache = (s && s[SESSLOG]) || []; });
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || !e.data.__ymKeepAliveRes) return;
    keepAliveWaiting = false;
    logSession({ st: e.data.__ymKeepAliveRes.status, ok: !!e.data.__ymKeepAliveRes.ok, in: !loggedOut() });
  });
  // One log, written by EVERY Smiles tab — including the short-lived tabs the background search
  // opens. Two problems that made the log lie to us: writes are read-modify-write, so entries
  // logged close together overwrote each other (that is why PAGE-LOAD entries went missing),
  // and a search tab's entries are indistinguishable from your booking tab's. So: writes are
  // queued one at a time, and every entry is stamped with its tab.
  let logChain = Promise.resolve();
  function logSession(entry) {
    if (!alive()) return;
    entry.t = Date.now();
    entry.tab = TABID;
    logChain = logChain.then(() => new Promise((done) => {
      sGet(SESSLOG, (s) => {
        let arr = (s && s[SESSLOG]) || [];
        arr.push(entry);
        if (arr.length > 80) arr = arr.slice(-80);
        sessionLogCache = arr;
        sSet({ [SESSLOG]: arr }, () => done());
      });
    })).catch(() => {});
  }
  function keepAliveTick() {
    if (!onSmilesApp()) return;
    if (Date.now() - lastKeepAlive < 4 * 60 * 1000) return;   // every 4 min ≈ 15 calls/hour
    lastKeepAlive = Date.now();
    // The keepalive is CLEARED by the logs: 30+ minutes of 200s with the session intact, and
    // every logout instead lands right after a PAGE-LOAD entry. So it stays.
    const left = sessionLeftMin();
    // Record what the countdown said AT the moment the session actually dropped. That is what
    // proves (or kills) the reading of expiresToken as the session's expiry: if it hits zero and
    // the account drops right then, the interpretation is right. If it drops at 12 minutes left,
    // the number means something else and should be ignored.
    if (loggedOut()) { logSession({ st: 'logged-out (countdown said ' + (left == null ? '?' : left + 'm') + ')', ok: false, in: false }); return; }
    logSession({ st: 'session ' + (left == null ? '?' : left + 'm left'), ok: true, in: true });
    if (keepAliveWaiting) return;
    keepAliveWaiting = true;
    window.postMessage({ __ymKeepAlive: 1 }, '*');
    setTimeout(() => { keepAliveWaiting = false; }, 20000);
  }
  const onSmilesApp = () => /smiles\.com\.ar$/i.test(location.hostname) || /smiles\.com\.ar$/i.test(location.hostname.replace(/^www\./, ''));

  // Clear Smiles' "Límite de tiempo caducado" by pressing its own "Rehacer búsqueda". Runs
  // whether or not a drive is on: that notice makes a results page you left sitting useless,
  // and redoing the search is the only thing to do with it — fresh prices, no page load, still
  // logged in. NOT on the passenger or checkout step: there, redoing the search would throw
  // away a booking in progress, so we leave that decision to you.
  function handleSearchExpiry(driving) {
    const redo = redoSearchBtn();
    if (!redo || onPax() || onCheckout()) return false;
    // Only ever press it as part of a booking you started. v0.86 clicked it on any idle page
    // and logouts began right after — unproven, but this button is Smiles' own and we do not
    // know whether it reloads. Not worth risking an account to save you one click.
    if (!driving) {
      if (Date.now() - lastExpirySeen > 60000) { lastExpirySeen = Date.now(); logSession({ st: 'search-expired notice showing (not touched)', ok: true, in: !loggedOut() }); }
      return false;
    }
    if (Date.now() - lastRedo < 8000) return true;
    lastRedo = Date.now(); redoCount++;
    fareAttempt = 0; lastFareTry = 0;          // the results are about to be replaced
    logSession({ st: 'search expired -> rehacer busqueda', ok: true, in: !loggedOut() });
    realClick(redo);
    return true;
  }

  function tick() {
    if (window.__ymDriverOwner !== ME) { if (timer) clearInterval(timer); return; }  // superseded
    if (!alive()) {                       // orphaned by an extension reload — clean up and stop
      if (timer) clearInterval(timer);
      ['__ymDrive', '__ymBook'].forEach(id => { const e = document.getElementById(id); if (e) e.remove(); });
      driveBtn = driveStatusEl = statusEl = null;
      return;
    }
    buildDriveBar();   // on EVERY Smiles page: the driver routes through the home page mid-search, and the session countdown is worth seeing anywhere
    if (onPax()) buildPanel(); else { const b = document.getElementById('__ymBook'); if (b) { b.remove(); statusEl = null; } }
    if (onLogin()) buildLoginPanel(); else { const b = document.getElementById('__ymLogin'); if (b) b.remove(); }
    handleSearchExpiry(false);
    if (sessionEl) {
      const m = sessionLeftMin();
      sessionEl.textContent = loggedOut() ? '🔴 signed out' : (m == null ? '' : (m > 5 ? '🟢' : '🟠') + ' session ' + m + ' min left');
    }
    driveTick();
    keepAliveTick();
  }
  // Let the background ask this tab whether it is signed in, so Book can pick the tab you
  // actually logged into instead of whichever Smiles tab happens to be in front.
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.ymWho) { sendResponse({ loggedIn: !loggedOut(), tab: TABID, path: location.pathname }); return true; }
    });
  } catch (e) {}

  // Record every DOCUMENT load. This script only re-runs when the page genuinely reloads, so an
  // entry here is proof that a real page load happened — including any Smiles triggers itself,
  // which we cannot prevent. Logging the session state right after, and again once the app has
  // had time to boot, shows whether that load is what signed the account out and exactly which
  // page it happened on.
  (function recordLoad() {
    let nav = '?';
    try { nav = (performance.getEntriesByType('navigation')[0] || {}).type || '?'; } catch (e) {}
    logSession({ st: 'PAGE-LOAD(' + nav + ') ' + location.pathname, ok: true, in: !loggedOut() });
    setTimeout(() => logSession({ st: 'settled ' + location.pathname, ok: true, in: !loggedOut() }), 9000);
  })();

  let timer = null;
  tick();
  timer = setInterval(tick, 1500);
})();
