// Assisted booking (ISOLATED world). On the Smiles passenger page (/emission/passenger-data)
// it shows a small panel: drop in a passenger's details, hit "Fill Smiles form", and it
// populates the real Smiles fields. Later this same fill gets fed automatically from the
// customer's website order. Human still does the checkout (password + captcha + card).
(function () {
  'use strict';
  const KEY = 'ymBookPax';
  const FIELDS = ['first', 'last', 'nationality', 'dob', 'passport', 'passportExp', 'email', 'ccode', 'area', 'phone'];
  const onPax = () => /\/emission\/passenger-data/.test(location.pathname);
  const q = (s) => document.querySelector(s);

  // Set a value the way React accepts it (native setter + input/change events).
  function setVal(el, val) {
    if (!el) return false;
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }

  function fillForm(d) {
    let n = 0;
    if (setVal(q('#firstName'), d.first || '')) n++;
    if (setVal(q('#lastName'), d.last || '')) n++;
    const nat = q('select[name="nationality"]');
    if (nat && d.nationality) { const o = [...nat.options].find(o => (o.text || '').toLowerCase().includes(d.nationality.toLowerCase())); if (o) setVal(nat, o.value); }
    if (d.gender) { const g = /^f/i.test(d.gender) ? q('#female0') : q('#male0'); if (g) g.click(); }
    setVal(q('#birthday-0'), d.dob || '');
    setVal(q('#passport'), d.passport || '');
    setVal(q('#passportValidity0'), d.passportExp || '');
    setVal(q('#email'), d.email || '');
    setVal(q('#movilddi'), d.ccode || '54');
    setVal(q('#movilddd'), d.area || '');
    setVal(q('#movilnumber'), d.phone || '');
    flash('Filled ✓ — review it, then hit Continuar.');
  }

  let statusEl = null;
  function flash(m) { if (statusEl) statusEl.textContent = m; }

  function build() {
    if (document.getElementById('__ymBook')) return;
    chrome.storage.local.get(KEY, (s) => {
      if (document.getElementById('__ymBook')) return;
      const d = (s && s[KEY]) || {};
      const box = document.createElement('div'); box.id = '__ymBook';
      box.style.cssText = 'position:fixed;top:74px;right:12px;z-index:2147483647;background:#0b1220;color:#e6f0ff;font:12px system-ui,-apple-system,sans-serif;border:1px solid #2b6cff;border-radius:11px;padding:11px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
      const v = (x) => (x || '').replace(/"/g, '&quot;');
      const fld = (id, ph, val, w) => `<input id="ymb_${id}" placeholder="${ph}" value="${v(val)}" style="width:${w || '100%'};margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box">`;
      box.innerHTML =
        '<div style="font-weight:700;margin-bottom:7px">YM · fill passenger</div>' +
        fld('first', 'First name', d.first) + fld('last', 'Last name', d.last) +
        fld('nationality', 'Nationality (e.g. Americano)', d.nationality) +
        `<div style="margin:4px 0">Gender &nbsp;<label><input type="radio" name="ymb_gender" value="M" ${d.gender !== 'F' ? 'checked' : ''}> M</label> &nbsp;<label><input type="radio" name="ymb_gender" value="F" ${d.gender === 'F' ? 'checked' : ''}> F</label></div>` +
        fld('dob', 'DOB  DD/MM/YYYY', d.dob) + fld('passport', 'Passport #', d.passport) + fld('passportExp', 'Passport exp  DD/MM/YYYY', d.passportExp) +
        fld('email', 'Email', d.email) +
        `<div style="display:flex;gap:5px">${fld('ccode', 'Cód', d.ccode || '54', '46px')}${fld('area', 'Area', d.area, '58px')}${fld('phone', 'Phone', d.phone, 'auto')}</div>`;
      const btn = document.createElement('button');
      btn.textContent = 'Fill Smiles form';
      btn.style.cssText = 'width:100%;margin-top:8px;cursor:pointer;border:0;border-radius:7px;padding:8px;background:#16a34a;color:#fff;font:13px system-ui;font-weight:700';
      btn.addEventListener('click', () => {
        const data = {}; FIELDS.forEach(k => { const el = document.getElementById('ymb_' + k); if (el) data[k] = el.value; });
        const gr = document.querySelector('input[name="ymb_gender"]:checked'); data.gender = gr ? gr.value : 'M';
        chrome.storage.local.set({ [KEY]: data });
        fillForm(data);
      });
      box.appendChild(btn);
      statusEl = document.createElement('div'); statusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; box.appendChild(statusEl);
      document.body.appendChild(box);
    });
  }

  function tick() { if (onPax()) build(); else { const b = document.getElementById('__ymBook'); if (b) { b.remove(); statusEl = null; } } }
  tick();
  setInterval(tick, 1500);
})();
