// Assisted booking driver (ISOLATED world) for Smiles.
//  • Passenger page: a panel to fill the form (name, DOB, passport, email, phone, nationality).
//  • Auto-drive: once you've picked a fare, it agrees the terms + clicks Continuar, fills the
//    passenger + clicks Continuar, and STOPS at checkout for you (password + captcha + card).
// Nothing here submits payment. Later the passenger data is fed from the customer's order.
(function () {
  'use strict';
  const KEY = 'ymBookPax';       // passenger details
  const DRIVE = 'ymAutoDrive';   // { on, startedAt }
  const FIELDS = ['first', 'last', 'dob', 'passport', 'passportExp', 'email', 'ccode', 'area', 'phone'];
  const onEmission = () => /\/emission/.test(location.pathname);
  const onPax = () => /\/emission\/passenger-data/.test(location.pathname);
  const onCheckout = () => /\/emission\/checkout/.test(location.pathname);
  const q = (s) => document.querySelector(s);

  function setVal(el, val) {
    if (!el) return false;
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  function fillForm(d) {
    setVal(q('#firstName'), d.first || '');
    setVal(q('#lastName'), d.last || '');
    const nat = q('select[name="nationality"]');
    if (nat && d.nationality) setVal(nat, d.nationality);
    if (d.gender) { const g = /^f/i.test(d.gender) ? q('#female0') : q('#male0'); if (g) g.click(); }
    setVal(q('#birthday-0'), d.dob || '');
    setVal(q('#passport'), d.passport || '');
    setVal(q('#passportValidity0'), d.passportExp || '');
    setVal(q('#email'), d.email || '');
    setVal(q('#movilddi'), d.ccode || '54');
    setVal(q('#movilddd'), d.area || '');
    setVal(q('#movilnumber'), d.phone || '');
    flash('Filled ✓');
  }

  let statusEl = null, driveStatusEl = null, driveBtn = null;
  function flash(m) { if (statusEl) statusEl.textContent = m; if (driveStatusEl) driveStatusEl.textContent = m; }

  // Find Smiles' "Guardar pasajero para futuras compras" checkbox (saves them to the account
  // favorites — treated as irreversible). We NEVER want it on by accident.
  function findSaveCheckbox() {
    const nodes = [...document.querySelectorAll('label, span, div')];
    const l = nodes.find(x => { const t = (x.innerText || '').trim(); return t.length < 90 && /guardar\s+pasajero/i.test(t); });
    if (!l) return null;
    if (l.htmlFor) { const el = document.getElementById(l.htmlFor); if (el && el.type === 'checkbox') return el; }
    let cb = l.querySelector && l.querySelector('input[type=checkbox]'); if (cb) return cb;
    for (const sib of [l.previousElementSibling, l.nextElementSibling]) if (sib && sib.matches && sib.matches('input[type=checkbox]')) return sib;
    cb = l.parentElement && l.parentElement.querySelector('input[type=checkbox]'); if (cb) return cb;
    return null;
  }
  // Returns true only if we can CONFIRM the save box is off. false = don't auto-continue.
  function ensureNotSaving() {
    const cb = findSaveCheckbox();
    if (!cb) return false;              // can't find it → refuse to continue
    if (cb.checked) cb.click();         // uncheck (React-friendly)
    return !cb.checked;                 // confirmed off?
  }

  // ---------------- auto-drive state machine ----------------
  let acted = false; // guard: only act once per page load
  function startDrive() { chrome.storage.local.set({ [DRIVE]: { on: true, startedAt: Date.now() } }); flash('Auto-drive ON — agreeing terms → continue → fill → continue → stop at checkout.'); }
  function stopDrive() { chrome.storage.local.set({ [DRIVE]: { on: false } }); flash('Auto-drive stopped.'); }
  function driveTick() {
    chrome.storage.local.get([DRIVE, KEY], (st) => {
      const drive = (st && st[DRIVE]) || {};
      const data = (st && st[KEY]) || {};
      setDriveBtn(drive.on);
      if (!drive.on) return;
      if (drive.startedAt && Date.now() - drive.startedAt > 6 * 60 * 1000) { chrome.storage.local.set({ [DRIVE]: { on: false } }); return; }
      if (onCheckout()) { chrome.storage.local.set({ [DRIVE]: { on: false } }); flash('✋ Your turn — enter the Smiles password + captcha + card, then Confirmar pago.'); return; }
      if (acted) return;
      if (onPax()) {
        if (!q('#firstName')) return;                       // form not rendered yet
        if (!data.first || !data.last) {
          flash('⚠ Fill the passenger (top-right panel) — I fill from there. Need at least first + last name.');
          const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#f59e0b';
          return;
        }
        const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#2b6cff';
        acted = true; fillForm(data);
        setTimeout(() => {
          if (!ensureNotSaving()) {   // couldn't guarantee "Guardar pasajero" is OFF → stop, don't advance
            chrome.storage.local.set({ [DRIVE]: { on: false } });
            flash('⛔ Filled, but I could NOT confirm "Guardar pasajero" is unchecked — stopped so no one is saved by accident. Uncheck it + click Continuar yourself.');
            return;
          }
          const b = q('#passengersConfirmButton'); if (b) b.click();
        }, 1000);
        return;
      }
      // Fare/tax step on /emission: #btn-continue only exists once a fare is selected.
      const cont = q('#btn-continue');
      if (cont) {
        acted = true;
        const tc = q('label.form-check-label-emission.check-tc'); if (tc) tc.click(); // agree terms
        setTimeout(() => { const c = q('#btn-continue'); if (c && !c.disabled) c.click(); }, 700);
      }
    });
  }

  // ---------------- UI ----------------
  function setDriveBtn(on) {
    if (!driveBtn) return;
    driveBtn.textContent = on ? '■ Stop auto-drive' : '▶ Auto-book to checkout';
    driveBtn.style.background = on ? '#dc2626' : '#4f46e5';
  }
  function buildDriveBar() {
    if (document.getElementById('__ymDrive')) return;
    const bar = document.createElement('div'); bar.id = '__ymDrive';
    bar.style.cssText = 'position:fixed;bottom:12px;right:12px;z-index:2147483646;background:#0b1220;color:#e6f0ff;font:12px system-ui,sans-serif;border:1px solid #4f46e5;border-radius:11px;padding:10px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
    bar.innerHTML = '<div style="font-weight:700;margin-bottom:6px">YM · auto-drive</div><div style="font-size:11px;opacity:.8;margin-bottom:7px">Pick a fare first, then this agrees terms, continues, fills the passenger, and stops at checkout.</div>';
    driveBtn = document.createElement('button');
    driveBtn.style.cssText = 'width:100%;cursor:pointer;border:0;border-radius:7px;padding:8px;color:#fff;font:13px system-ui;font-weight:700;background:#4f46e5';
    driveBtn.addEventListener('click', () => { chrome.storage.local.get(DRIVE, s => { const on = s && s[DRIVE] && s[DRIVE].on; if (on) stopDrive(); else { acted = false; startDrive(); } }); });
    bar.appendChild(driveBtn);
    driveStatusEl = document.createElement('div'); driveStatusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; bar.appendChild(driveStatusEl);
    document.body.appendChild(bar);
  }

  function buildPanel() {
    if (document.getElementById('__ymBook')) return;
    chrome.storage.local.get(KEY, (s) => {
      if (document.getElementById('__ymBook')) return;
      const d = (s && s[KEY]) || {};
      const box = document.createElement('div'); box.id = '__ymBook';
      box.style.cssText = 'position:fixed;top:74px;right:12px;z-index:2147483647;background:#0b1220;color:#e6f0ff;font:12px system-ui,-apple-system,sans-serif;border:1px solid #2b6cff;border-radius:11px;padding:11px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
      const v = (x) => (x || '').replace(/"/g, '&quot;');
      const fld = (id, ph, val, w) => `<input id="ymb_${id}" placeholder="${ph}" value="${v(val)}" style="width:${w || '100%'};margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box">`;
      box.innerHTML =
        '<div style="font-weight:700;margin-bottom:7px">YM · fill passenger</div>' +
        fld('first', 'First name', d.first) + fld('last', 'Last name', d.last) +
        '<select id="ymb_nationality" style="width:100%;margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box"><option value="">Nationality…</option></select>' +
        `<div style="margin:4px 0">Gender &nbsp;<label><input type="radio" name="ymb_gender" value="M" ${d.gender !== 'F' ? 'checked' : ''}> M</label> &nbsp;<label><input type="radio" name="ymb_gender" value="F" ${d.gender === 'F' ? 'checked' : ''}> F</label></div>` +
        fld('dob', 'DOB  DD/MM/YYYY', d.dob) + fld('passport', 'Passport #', d.passport) + fld('passportExp', 'Passport exp  DD/MM/YYYY', d.passportExp) +
        fld('email', 'Email', d.email) +
        `<div style="display:flex;gap:5px">${fld('ccode', 'Cód', d.ccode || '54', '46px')}${fld('area', 'Area', d.area, '58px')}${fld('phone', 'Phone', d.phone, 'auto')}</div>`;
      const btn = document.createElement('button');
      btn.textContent = 'Fill Smiles form';
      btn.style.cssText = 'width:100%;margin-top:8px;cursor:pointer;border:0;border-radius:7px;padding:8px;background:#16a34a;color:#fff;font:13px system-ui;font-weight:700';
      btn.addEventListener('click', saveAndFill);
      box.appendChild(btn);
      statusEl = document.createElement('div'); statusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; box.appendChild(statusEl);
      document.body.appendChild(box);
      const autosave = () => chrome.storage.local.set({ [KEY]: collect() });   // typing here = remembered; local only, NOT saved to Smiles
      box.querySelectorAll('input, select').forEach(el => { el.addEventListener('input', autosave); el.addEventListener('change', autosave); });
      const smilesNat = q('select[name="nationality"]'), panelNat = document.getElementById('ymb_nationality');
      if (smilesNat && panelNat && smilesNat.options.length) {
        panelNat.innerHTML = '<option value="">Nationality…</option>' + [...smilesNat.options].filter(o => o.value).map(o => `<option value="${(o.value || '').replace(/"/g, '&quot;')}">${(o.text || '').replace(/</g, '&lt;')}</option>`).join('');
        if (d.nationality) panelNat.value = d.nationality;
      }
    });
  }
  function collect() {
    const data = {}; FIELDS.forEach(k => { const el = document.getElementById('ymb_' + k); if (el) data[k] = el.value; });
    const gr = document.querySelector('input[name="ymb_gender"]:checked'); data.gender = gr ? gr.value : 'M';
    const natEl = document.getElementById('ymb_nationality'); data.nationality = natEl ? natEl.value : '';
    return data;
  }
  function saveAndFill() { const data = collect(); chrome.storage.local.set({ [KEY]: data }); fillForm(data); }

  function tick() {
    if (onEmission()) buildDriveBar(); else { const b = document.getElementById('__ymDrive'); if (b) { b.remove(); driveBtn = null; driveStatusEl = null; } }
    if (onPax()) buildPanel(); else { const b = document.getElementById('__ymBook'); if (b) { b.remove(); statusEl = null; } }
    driveTick();
  }
  tick();
  setInterval(tick, 1500);
})();
