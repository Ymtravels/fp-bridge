// Assisted booking driver (ISOLATED world) for Smiles.
//  • Passenger page: a panel to fill the form (name, DOB, passport, email, phone, nationality).
//  • Auto-drive: once you've picked a fare, it agrees the terms + clicks Continuar, fills the
//    passenger + clicks Continuar, and STOPS at checkout for you (password + captcha + card).
// Nothing here submits payment. Later the passenger data is fed from the customer's order.
(function () {
  'use strict';
  const VER = (chrome.runtime && chrome.runtime.getManifest) ? chrome.runtime.getManifest().version : '?';
  // This file gets re-injected into live tabs when the extension reloads — that is how a new
  // version reaches an open Smiles tab WITHOUT a page reload, which would sign you out. Two
  // copies must never drive at once, so each injection claims ownership and any older copy
  // stands down on its next tick. Clear the previous copy's panels too.
  const ME = 'ym' + Date.now() + Math.random().toString(36).slice(2, 6);
  window.__ymDriverOwner = ME;
  ['__ymDrive', '__ymBook'].forEach(id => { const e = document.getElementById(id); if (e) e.remove(); });
  const KEY = 'ymBookPax';       // passenger 1 (kept as-is so nothing else has to change)
  const PAXL = 'ymBookPaxL';     // ALL passengers, in order — index 0 mirrors KEY
  const DRIVE = 'ymAutoDrive';   // { on, startedAt }
  const TARGET = 'ymBookTarget'; // { origin, destination, dep, cabin, miles:[club, std], summary } from the app's Book button
  const FIELDS = ['first', 'last', 'dob', 'passport', 'passportExp', 'email', 'ccode', 'area', 'phone'];
  const onEmission = () => /\/emission/.test(location.pathname);
  const onPax = () => /\/emission\/passenger-data/.test(location.pathname);
  const onCheckout = () => /\/emission\/checkout/.test(location.pathname);
  // The login is a MODAL that opens over the current page ("Ingresá a tu cuenta Smiles",
  // DNI + Contraseña + reCAPTCHA + Entrar) — there is no /login route to test for. So find the
  // form itself, and locate its fields by shape rather than by id, which differs between the
  // modal and the standalone page.
  function loginFields() {
    const pass = qav('input[type=password]')[0];
    if (!pass) return null;
    let dni = byId('dni');
    if (!dni) {
      const form = pass.closest('form') || pass.parentElement;
      const near = form ? [...form.querySelectorAll('input')].filter(e => vis(e) && e.type !== 'password') : [];
      dni = near[0] || qav('input').find(e => e.type !== 'password' && /dni|smiles|usuario/i.test((e.placeholder || '') + ' ' + (e.getAttribute('name') || '')));
    }
    return dni ? { dni: dni, pass: pass } : null;
  }
  const onLogin = () => !!loginFields();
  const ACCTS = 'ymAccounts';   // [{name, dni, pass}] — this browser profile only, never sent anywhere
  const ACTIVE = 'ymActiveAccount';   // dni of the account this booking should run on
  const ORDERS = 'ymOrders', CURRENT = 'ymCurrentOrder';   // the queue, and which order is running

  // CRITICAL: Smiles ships BOTH layouts in every page — a `d-mobile` block and a `d-desktop`
  // block — carrying the SAME element ids (#calendarGo, #input-adult, #btn-continue, form
  // fields…). Whichever one your screen doesn't use is still in the DOM, just hidden by CSS,
  // and it comes FIRST. So document.querySelector('#x') hands back the INVISIBLE copy: we'd
  // read its state and type into it while the real control sits untouched. Every lookup here
  // must therefore return the visible match only.
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const st = getComputedStyle(el);
    return st.visibility !== 'hidden' && st.display !== 'none';
  }
  const qav = (s) => { try { return [...document.querySelectorAll(s)].filter(vis); } catch (e) { return []; } };
  // Reloading the extension orphans the copy of this script already running in open tabs: every
  // later chrome.* call throws "Extension context invalidated" and fills the error list. There
  // is nothing useful an orphan can do, so it checks first and shuts itself down instead.
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; } };
  // Is the page still working? readyState alone is useless here: the SPA swaps pages with no
  // document load, so it reads 'complete' the whole way through. Smiles says so on screen
  // instead ("AGUARDÁ… Buscando vuelo…"), and that is the signal to sit still. Waiting has no
  // downside; acting early gives half-filled forms and clicks into controls that have not mounted.
  let busySince = 0;
  // Chrome's page translation rewrites the button text, and almost everything here is found by
  // its Spanish wording — "Buscar", "Confirmar pago", "Sólo ida". Translated, none of it matches,
  // which is exactly why a search failed earlier with "could not find the Buscar button".
  const pageTranslated = () => {
    try { return /translated-(ltr|rtl)/.test(document.documentElement.className || '') || !!document.querySelector('.skiptranslate iframe'); } catch (e) { return false; }
  };

  // Tracks when the page last changed. "Loaded" is best read as "stopped changing": we proceed
  // the moment the DOM has been quiet briefly, however long that took — not after a set timer.
  let hadRealLoad = document.readyState === 'complete';
  window.addEventListener('load', () => { hadRealLoad = true; lastDomChange = Date.now(); });
  let lastDomChange = Date.now();
  try {
    const mo = new MutationObserver(() => { lastDomChange = Date.now(); });
    mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: true });
  } catch (e) {}
  const domQuietMs = () => Date.now() - lastDomChange;

  // Watch ONLY Smiles' own network calls to know when it is still loading — not the DOM (our own
  // status text mutates the DOM every tick, which made "is it loading?" true forever), and not
  // analytics/tracking beacons (they fire constantly and never mean the page is busy). A request
  // to a smiles.com.ar / yuno API finishing = the page is fetching real data; wait for that.
  let lastSmilesNetAt = 0;
  let lastFrames = [];   // real URLs of every frame in this tab, from the background
  const isSmilesReq = (url) => /smiles\.com\.(ar|br)|api\.y\.uno/i.test(url || '') && !/analytics|doubleclick|hotjar|datadog|google|facebook|clarity/i.test(url || '');
  try {
    const po = new PerformanceObserver((list) => {
      for (const e of list.getEntries()) { if (isSmilesReq(e.name)) { lastSmilesNetAt = Date.now(); break; } }
    });
    po.observe({ type: 'resource', buffered: true });
  } catch (e) {}
  // Still loading if Smiles shows its own working words, OR a Smiles API call finished very
  // recently (more may follow). No fixed timeout — slow Wi-Fi keeps this true until it truly stops.
  const netQuiet = () => (lastSmilesNetAt ? Date.now() - lastSmilesNetAt : 999999);
  const smilesLoading = () => !!pageBusy() || netQuiet() < 2500;

  // The page itself says when it is loading — a spinner node, aria-busy, a progressbar. That is a
  // FACT to read, not a heuristic to invent. A class-presence check was tried before and failed
  // because Smiles keeps those nodes in the DOM permanently, so it matched forever and blocked
  // every step. Two things fix that: only count a loader that is actually VISIBLE, and ignore one
  // that has been on screen continuously for 25s — that is decoration, not a load in progress.
  const LOADER_SEL = '[aria-busy="true"], [role="progressbar"], [class*="spinner" i], [class*="loader" i], [class*="loading" i], [class*="skeleton" i], [class*="shimmer" i]';
  // The moment loading stops, so every step can let the page settle before acting. "Once it stops
  // loading, wait a second or two, then do its thing" — clicking the instant a spinner clears is
  // how you hit a control that has mounted but not wired itself up yet.
  let busyEndedAt = 0, wasBusyLast = false;
  const SETTLE_AFTER_LOAD = 1600;
  function noteBusyEdge() {
    const b = !!pageBusy();
    if (b) { wasBusyLast = true; busyEndedAt = 0; }
    else if (wasBusyLast) { wasBusyLast = false; busyEndedAt = Date.now(); }
  }
  const settledFor = () => (wasBusyLast ? 0 : (busyEndedAt ? Date.now() - busyEndedAt : 999999));
  function visibleLoaders() {
    let els = [];
    try { els = [...document.querySelectorAll(LOADER_SEL)].filter(vis); } catch (e) { return []; }
    return els.filter(e => {                                   // never count our own panels
      try { return !/^__ym/.test(e.id || '') && !e.closest('#__ymDrive, #__ymBook, #__ymLogin, #__ymConsoleFrame'); }
      catch (x) { return true; }
    });
  }
  const loaderBusy = () => visibleLoaders().length > 0;

  function pageBusy() {
    let why = '';
    try {
      if (document.readyState !== 'complete') return 'page loading';   // factual and self-limiting
      const t = (document.body && document.body.innerText) || '';
      if (/aguard[aá]|buscando vuelo|procesando tu|cargando/i.test(t.slice(0, 4000))) why = 'Smiles is working';
      else if (loaderBusy()) why = 'the page is showing a loader';
    } catch (e) {}
    if (!why) { busySince = 0; return ''; }
    if (!busySince) busySince = Date.now();
    // NO TIME LIMIT on how long a load may take. A 20s cap was a guess, and on a site this slow a
    // genuine load can run past any number we pick — at which point the cap would let us act on a
    // page that really is still loading, which is the whole problem. So the signal is believed for
    // as long as Smiles is still FETCHING: 40s, 90s, however long it needs.
    if (netQuiet() < 12000) return why;
    // Signal still showing, but nothing has been fetched for 12s. That is not slow, it is STUCK —
    // and the answer to stuck is the watchdog restarting it, never us acting on a half-built page.
    // (Also covers a decorative spinner Smiles leaves on screen, which fetches nothing.)
    busySince = 0;
    return '';
  }


  // Minutes left on the Smiles session. sessionStorage.expiresToken is a plain ms timestamp —
  // a time, never a credential. This is the number that actually governs everything: reloads
  // are harmless while it is positive, and the account drops when it runs out.
  function sessionLeftMin() {
    try {
      const raw = sessionStorage.getItem('expiresToken');
      if (!raw || !/^[0-9]{10,13}$/.test(raw)) return null;
      const ms = raw.length <= 10 ? +raw * 1000 : +raw;
      return Math.round((ms - Date.now()) / 60000);
    } catch (e) { return null; }
  }
  // Every storage call goes through these. Checking alive() once per tick is not enough: the
  // callbacks fire later, and the panel's own buttons don't go through tick at all, so an
  // extension reload mid-flight still threw "Extension context invalidated". Callbacks are
  // still invoked when we skip, so nothing waiting on one hangs.
  function sGet(keys, cb) {
    if (!alive()) return;
    try { chrome.storage.local.get(keys, (r) => { if (!alive()) return; try { cb(r); } catch (e) {} }); } catch (e) {}
  }
  function sSet(obj, cb) {
    const done = () => { if (cb) { try { cb(); } catch (e) {} } };
    if (!alive()) { done(); return; }
    try { chrome.storage.local.set(obj, done); } catch (e) { done(); }
  }
  const q = (s) => qav(s)[0] || null;
  const byId = (id) => qav('[id="' + id + '"]')[0] || null;
  const btnByText = (re, sels) => qav(sels || 'button, a, [role="button"], input[type=submit]')
    .find(b => re.test((b.innerText || b.value || '').trim())) || null;
  // Same-id lookup for elements we can't filter by visibility (styled checkboxes are 0x0):
  // pick the copy nearest `ref` in the DOM, i.e. the one in the section we're actually looking at.
  function idNear(id, ref) {
    let all = [];
    try { all = [...document.querySelectorAll('[id="' + id + '"]')]; } catch (e) { return null; }
    if (all.length <= 1) return all[0] || null;
    let a = ref;
    for (let k = 0; k < 8 && a; k++) { const hit = all.find(e => a.contains(e)); if (hit) return hit; a = a.parentElement; }
    return all.find(vis) || all[0];
  }

  function setVal(el, val) {
    if (!el) return false;
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  // React ignores a bare .click() on some controls — send the full pointer/mouse sequence.
  function realClick(el) {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
    const r = el.getBoundingClientRect();
    const o = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
    try { el.dispatchEvent(new PointerEvent('pointerdown', o)); } catch (e) {}
    el.dispatchEvent(new MouseEvent('mousedown', o));
    try { el.dispatchEvent(new PointerEvent('pointerup', o)); } catch (e) {}
    el.dispatchEvent(new MouseEvent('mouseup', o));
    el.click();
    return true;
  }
  // Set a React-controlled input's value without the change/blur that would close an open
  // autocomplete list (setVal below is the heavier version used for the passenger form).
  function setNative(el, val) {
    const proto = el.tagName === 'SELECT' ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) desc.set.call(el, val); else el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }
  async function typeInto(el, text) {
    // Select the existing text and clear it first. Just assigning '' left the old airport behind
    // in some states, so "YUL" was appended to whatever was already there and the autocomplete
    // matched nothing.
    el.focus();
    try { el.select(); } catch (e) {}
    el.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', ctrlKey: true, bubbles: true }));
    setNative(el, '');
    el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Backspace', bubbles: true }));
    await sleep(80);
    setNative(el, '');
    for (const ch of String(text)) {
      el.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true }));
      setNative(el, (el.value || '') + ch);
      el.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true }));
      await sleep(90);
    }
  }

  // Form fields: prefer the VISIBLE copy (so we never type into Smiles' hidden mobile markup),
  // but fall back to the element itself if no copy passes the visibility test. Radios and
  // checkboxes here are styled — the real input is zero-sized with a fake control drawn over it —
  // so a strict visible-only lookup finds nothing and the field silently goes unset, which is
  // what Smiles then rejects with "los parámetros … no fueron informados".
  const field = (sel) => { try { return q(sel) || document.querySelector(sel); } catch (e) { return null; } };

  // Fill one field and CONFIRM it took. A React-controlled widget can happily show the text we
  // assigned while its own state stays empty — the form then LOOKS complete and submits with
  // the field missing, which is exactly what Smiles rejects as "los parámetros de la solicitud
  // no fueron informados". So we read the value back, and if it didn't stick we type it in
  // keystroke by keystroke, the way these widgets do accept input.
  async function fillField(sel, val, name) {
    if (val == null || val === '') return null;
    let el = field(sel);
    if (!el) return null;                                   // not on this page — nothing to do
    setVal(el, val);
    if (((field(sel) || {}).value) === val) return null;
    el = field(sel) || el;
    await typeInto(el, val);
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return ((field(sel) || {}).value === val) ? null : name;
  }

  // ---- passengers -------------------------------------------------------------------------
  // Smiles renders ONE BLOCK PER TRAVELLER ("Adulto 1", "Adulto 2"). The ids are suffixed
  // unevenly (birthday-0, passportValidity0, male0 — but plain firstName/lastName/passport), so
  // guessing passenger 2's ids would be exactly that: a guess. The NAME attributes repeat inside
  // every block, so instead we locate each block and fill by name within it. One passenger
  // behaves exactly as before; several work without knowing the id pattern.
  const inBlk = (root, sel) => { try { return [...root.querySelectorAll(sel)].filter(vis); } catch (e) { return []; } };

  function blockOf(fi) {
    let el = fi, best = fi;
    for (let k = 0; k < 10 && el.parentElement; k++) {
      el = el.parentElement;
      // stop before swallowing a container that holds SEVERAL passengers
      if (el.querySelectorAll('[name="firstName"]').length > 1) break;
      best = el;
      if (el.querySelector('[name="lastName"]') && el.querySelector('[name="passport"]')) break;
    }
    return best;
  }
  function paxBlocks() { return qav('[name="firstName"]').map(blockOf); }
  // EVERY traveller's block, including the collapsed ones. Smiles renders all of them up front but
  // expands only the one being filled, so the visible-only list is never the whole party.
  function allPaxFirstNames() { try { return [...document.querySelectorAll('[name="firstName"]')]; } catch (e) { return []; } }

  async function fillEl(el, val, name) {
    if (el == null || val == null || val === '') return null;
    setVal(el, val);
    if (el.value === val) return null;
    await typeInto(el, val);
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
    return el.value === val ? null : name;
  }

  // Fill ONE passenger block. `n` is the traveller number, used only for clear error text.
  // Smiles keeps the travellers you have booked before as chips under "Mis pasajeros favoritos".
  // Clicking one fills that whole block from Smiles' own record — every field, in Smiles' own
  // format — which is more reliable than us typing nine fields and hoping each one takes. So we
  // try the chip first and VERIFY it landed; if it did not, we fall back to typing exactly as
  // before. Nothing is lost when the chip is missing, and nothing is saved to the account.
  function favouriteChips() {
    let host = null;
    try {
      host = qav('div, section').filter(e => /pasajeros favoritos/i.test(e.innerText || ''))
        .sort((a, b) => (a.innerText || '').length - (b.innerText || '').length)[0] || null;
    } catch (e) {}
    if (!host) return [];
    let els = [];
    try { els = [...host.querySelectorAll('button, a, li, span, div')].filter(vis); } catch (e) { return []; }
    return els
      .filter(e => e.children.length === 0)
      .map(e => ({ el: e, txt: (e.innerText || '').replace(/\s+/g, ' ').trim() }))
      .filter(c => c.txt && c.txt.length <= 28 && !/pasajeros favoritos/i.test(c.txt));
  }

  // A chip reads like "Judith F." — only a first name and an initial, which is not enough to tell
  // two people apart. So the chip is used to SHORTLIST, and the DATE OF BIRTH decides: after
  // clicking, the birthday Smiles filled in must match the one we hold, or that is not our
  // traveller. Two people can share a name; they do not share a name and a birthday.
  function matchFavourites(d) {
    if (!d || !d.first) return [];
    const want = String(d.first).trim().toLowerCase();
    const wantInitial = String(d.last || '').trim().charAt(0).toLowerCase();
    return favouriteChips().filter(c => {
      const parts = c.txt.toLowerCase().split(/\s+/);
      if (parts[0] !== want) return false;
      if (!wantInitial || parts.length < 2) return true;
      return parts[1].charAt(0) === wantInitial;
    });
  }
  // Clearing a rejected traveller has to be COMPLETE. Smiles fills nationality from the saved
  // record too, and leaving that behind would put the wrong person's nationality on the ticket
  // while every visible name field looked right.
  function clearBlock(one) {
    ['firstName', 'lastName', 'birthday', 'passport', 'passportValidity', 'nationality'].forEach(nm => {
      const el = one(nm); if (el) setVal(el, '');
    });
  }

  async function fillPassenger(block, d, n) {
    const bad = [];
    const tag = (t) => (n > 1 ? t + ' (traveller ' + n + ')' : t);
    const add = (x) => { if (x) bad.push(x); };
    const one = (nm) => inBlk(block, '[name="' + nm + '"]')[0] || null;

    // Try Smiles' own saved travellers, confirming each by DATE OF BIRTH before accepting it.
    const cands = ((one('firstName') || {}).value || '').trim() ? [] : matchFavourites(d);
    for (const fav of cands.slice(0, 4)) {
      flash('👤 Trying saved traveller "' + fav.txt + '"…');
      realClick(fav.el);
      for (let i = 0; i < 12 && !((one('firstName') || {}).value || '').trim(); i++) await sleep(250);
      const gotName = ((one('firstName') || {}).value || '').trim().toLowerCase();
      const gotDob = digits((one('birthday') || {}).value);
      const wantDob = digits(d.dob);
      const nameOk = gotName === String(d.first).trim().toLowerCase();
      // With a birthday on file, it is the decider. Without one we cannot be sure it is the right
      // person, so we refuse the shortcut and type — a booking in the wrong name is unfixable.
      const dobOk = wantDob ? (gotDob === wantDob) : false;
      if (nameOk && dobOk) { flash('👤 Matched saved traveller "' + fav.txt + '" by date of birth.'); break; }
      clearBlock(one);
      flash(wantDob ? '⚠ "' + fav.txt + '" is a different birthday — not this person.'
                    : '⚠ No date of birth on file to confirm who this is — typing the details instead.');
      if (!wantDob) break;
    }

    add(await fillEl(one('firstName'), d.first, tag('first name')));
    add(await fillEl(one('lastName'), d.last, tag('last name')));
    // Nationality on Smiles is a dropdown, so a value typed in the console ("Canadian", "Canadá")
    // will not be one of its option values. Match the option by value first, then by its visible
    // text, so what the operator types actually lands.
    const nat = one('nationality');
    if (nat && d.nationality) {
      const want = String(d.nationality).trim().toLowerCase();
      let opt = [...(nat.options || [])].find(o => (o.value || '').toLowerCase() === want)
        || [...(nat.options || [])].find(o => (o.text || '').trim().toLowerCase() === want)
        || [...(nat.options || [])].find(o => (o.text || '').trim().toLowerCase().indexOf(want) === 0);
      if (opt) setVal(nat, opt.value); else setVal(nat, d.nationality);
      if (!nat.value) bad.push(tag('nationality'));
    }
    if (d.gender) {
      const wantF = /^f/i.test(d.gender);
      const radios = inBlk(block, '[name="gender"]');
      const g = radios.find(r => wantF ? /female|^F$/i.test(r.id || r.value || '') : /male/i.test(r.id || '') && !/female/i.test(r.id || ''))
        || radios[wantF ? 1 : 0];
      if (g) {
        g.click();
        if (!g.checked) { const lab = (g.closest && g.closest('label')) || (g.id ? document.querySelector('label[for="' + g.id + '"]') : null); if (lab) realClick(lab); }
        if (!g.checked) bad.push(tag('gender'));
      }
    }
    add(await fillEl(one('birthday'), d.dob, tag('date of birth')));
    add(await fillEl(one('passport'), d.passport, tag('passport number')));
    add(await fillEl(one('passportValidity'), d.passportExp, tag('passport expiry')));
    // contact details live once on the form (the buyer), not per traveller
    add(await fillEl(one('email') || field('#email'), d.email, tag('email')));
    add(await fillEl(one('movilddi') || field('#movilddi'), d.ccode || '54', tag('phone country code')));
    add(await fillEl(one('movilddd') || field('#movilddd'), d.area, tag('phone area code')));
    add(await fillEl(one('movilnumber') || field('#movilnumber'), d.phone, tag('phone number')));
    return bad;
  }

  // Returns the list of fields it could NOT fill. Empty list = safe to submit.
  // Accepts one passenger object or a list of them.
  async function fillForm(input) {
    const list = Array.isArray(input) ? input : [input || {}];
    const blocks = paxBlocks();
    if (!blocks.length) { flash('⚠ No passenger form on this page.'); return ['passenger form']; }
    const bad = [];
    for (let i = 0; i < blocks.length; i++) {
      const d = list[i];
      if (!d || !d.first || !d.last) { bad.push('traveller ' + (i + 1) + ' details'); continue; }
      const r = await fillPassenger(blocks[i], d, i + 1);
      r.forEach(x => bad.push(x));
    }
    flash(bad.length ? ('⚠ Could not set: ' + bad.join(', ')) : ('Filled ✓ (' + blocks.length + ' traveller' + (blocks.length > 1 ? 's' : '') + ')'));
    return bad;
  }

  let statusEl = null, driveStatusEl = null, driveBtn = null, sessionEl = null;
  let lastTargetSeen = null;   // most recent target read in driveTick (for the diagnostic dump)
  // Also mirrored onto <html data-ym-status> so the current state is readable even on pages
  // where neither panel is drawn (the search runs on the home page, which has no drive bar).
  function flash(m) {
    if (statusEl) statusEl.textContent = m;
    if (driveStatusEl) driveStatusEl.textContent = m;
    try { document.documentElement.dataset.ymStatus = m; } catch (e) {}
    publishStatus(m);
  }
  // What the console shows. Written to chrome.storage so the console window can read it live,
  // including whether the operator is needed right now (a captcha, or the card + Pagar) and on
  // which tab — so the console can bring that tab forward instead of the operator hunting for it.
  let lastPublish = 0;
  function publishStatus(m) {
    if (!alive()) return;
    if (Date.now() - lastPublish < 400) return;      // coalesce the 1.5s ticks a little
    lastPublish = Date.now();
    // stamp the running order with its live step, so the queue row shows what it is doing
    try {
      sGet([CURRENT, ORDERS], (st) => {
        const id = st && st[CURRENT]; if (!id) return;
        const list = (st && st[ORDERS]) || [];
        const i = list.findIndex(o => o.id === id); if (i < 0) return;
        if (list[i].step === m && list[i].tabId === TABID) return;
        list[i].step = m; list[i].tabId = TABID; list[i].stepAt = Date.now();
        sSet({ [ORDERS]: list });
      });
    } catch (e) {}
    let need = '';
    try {
      const capBox = qav('.g-recaptcha, [class*="recaptcha"]')[0] || qav('iframe').find(f => /recaptcha\/api2\/anchor/.test(f.src || ''));
      const solved = [...document.querySelectorAll('#g-recaptcha-response, textarea[name="g-recaptcha-response"]')].some(t => (t.value || '').length > 20);
      if (loginFields() && capBox && !solved) need = 'Tick the captcha to sign in';
      else if (onCheckout() && capBox && !solved) need = 'Tick the captcha to confirm payment';
      else if (onCheckout() && qav('input[name="cardHolderName"]')[0]) need = 'Enter the card and press Pagar';
    } catch (e) {}
    try {
      sSet({ ymLiveStatus: {
        text: m || '', need: need, tab: TABID, at: Date.now(),
        loggedIn: !loggedOut(), left: sessionLeftMin(), path: location.pathname
      } });
    } catch (e) {}
  }

  // Which flight row does this fare label belong to? = the nearest ancestor holding exactly ONE
  // #flight-SEGMENT. Returns that segment element (or null if the label isn't inside a flight card).
  function segOfFare(lab) {
    let a = lab.parentElement;
    for (let k = 0; k < 12 && a; k++) {
      const s = a.querySelectorAll('[id^="flight-SEGMENT"]');
      if (s.length === 1) return s[0];
      if (s.length > 1) return null;
      a = a.parentElement;
    }
    return null;
  }
  const visFares = () => qav('label.form-check-label').filter(l => /tasas|millas/i.test(l.innerText || ''));

  // Diagnostic: dump the results-page structure (flight cards + fare labels) so we can see exactly
  // what's on the page when the fare-select gets stuck.
  function dumpFareInfo() {
    const info = { v: VER, url: location.href.replace(/[?#].*/, ''), title: (document.title || '').slice(0, 80), path: location.pathname };
    const segs = [...document.querySelectorAll('[id^="flight-SEGMENT"]')].slice(0, 8);
    info.rows = segs.map(s => {
      let row = s;                                                    // climb to the real flight row
      for (let k = 0; k < 6 && row.parentElement; k++) { row = row.parentElement; if ((row.innerText || '').length > 60) break; }
      const btns = [...row.querySelectorAll('button, a[role="button"], [role="button"]')].filter(b => b.offsetParent).slice(0, 8).map(b => (b.innerText || '').replace(/\s+/g, ' ').slice(0, 44)).filter(Boolean);
      return { id: s.id, text: (row.innerText || '').replace(/\s+/g, ' ').slice(0, 200), btns };
    });
    info.buttons = [...document.querySelectorAll('button')].filter(b => b.offsetParent && (b.innerText || '').trim()).slice(0, 40).map(b => (b.innerText || '').replace(/\s+/g, ' ').slice(0, 44));
    info.checks = [...document.querySelectorAll('input[type=checkbox]')].filter(c => c.offsetParent).slice(0, 10).map(c => ({ id: c.id || '', checked: !!c.checked, lab: ((c.labels && c.labels[0] && c.labels[0].innerText) || (c.closest('label') && c.closest('label').innerText) || '').replace(/\s+/g, ' ').slice(0, 50) }));
    const cont = document.querySelector('#btn-continue') || [...document.querySelectorAll('button')].find(b => /^\s*continuar\s*$/i.test(b.innerText || ''));
    info.continue = cont ? { id: cont.id || '', disabled: !!cont.disabled, cls: (typeof cont.className === 'string' ? cont.className : '').slice(0, 60) } : null;
    info.fareOptions = [...document.querySelectorAll('*')].filter(e => {
      if (!e.offsetParent) return false; const t = e.innerText || '';
      return t.length < 70 && /\d[\d.]{2,}\s*\+?\s*(tasas|millas)/i.test(t) && e.querySelectorAll('*').length < 6;
    }).slice(0, 12).map(e => {
      const clk = e.closest('label, button, [role="button"], a, li, [class*="fare"], [class*="card"]') || e;
      const inp = clk.querySelector && clk.querySelector('input');
      return { tag: e.tagName.toLowerCase(), cls: (typeof e.className === 'string' ? e.className : '').slice(0, 40), text: (e.innerText || '').replace(/\s+/g, ' ').slice(0, 50), clk: clk.tagName.toLowerCase() + '.' + ((typeof clk.className === 'string' ? clk.className : '').split(/\s+/)[0] || ''), checked: inp ? !!inp.checked : null };
    });
    info.target = lastTargetSeen ? { o: lastTargetSeen.origin, d: lastTargetSeen.destination, date: lastTargetSeen.date, dep: lastTargetSeen.dep, cabin: lastTargetSeen.cabin, miles: lastTargetSeen.miles } : null;
    info.flash = driveStatusEl ? driveStatusEl.textContent : '';
    info.fareMap = visFares().slice(0, 12).map(l => { const s = segOfFare(l); return { miles: fareMiles(l), seg: s ? s.id : null }; });
    info.loggedIn = !loggedOut();
    info.fareState = visFares().slice(0, 10).map(l => { const i = fareInput(l); const s2 = segOfFare(l); return { miles: fareMiles(l), seg: s2 ? s2.id : null, input: i ? (i.type || '?') : 'none', checked: i ? !!i.checked : null, disabled: i ? !!i.disabled : null }; });
    info.fareAttempt = fareAttempt;
    // WHERE DOES THE SESSION ACTUALLY LIVE? If a reload loses it, the token is held in memory
    // and nothing can survive a page load. If it is in storage or a cookie, then reload-logout
    // is a bug with a workaround. Every check so far was on a logged-OUT page, so this has been
    // assumed rather than known. NAMES AND LENGTHS ONLY — never the values: a session token in
    // a chat log is a stolen account.
    info.store = (() => {
      const size = (v) => '(' + String(v == null ? '' : v).length + ')';
      const pick = (store) => { try { return Object.keys(store).filter(k => /tok|auth|user|sess|login|oauth|jwt|bearer|member|client/i.test(k)).slice(0, 14).map(k => k + size(store.getItem(k))); } catch (e) { return ['err']; } };
      let lsAll = 0, ssKeys = [];
      try { lsAll = Object.keys(localStorage).length; } catch (e) {}
      try { ssKeys = Object.keys(sessionStorage).slice(0, 14).map(k => k + size(sessionStorage.getItem(k))); } catch (e) {}
      let cookies = [];
      try { cookies = document.cookie.split(';').map(c => c.split('=')[0].trim()).filter(Boolean).slice(0, 20); } catch (e) {}
      // expiresToken is a plain timestamp (not a secret): it says exactly when this session
      // dies. Reported as minutes remaining so we can see whether activity extends it.
      let expiresInMin = null, raw = null;
      try { raw = sessionStorage.getItem('expiresToken'); } catch (e) {}
      if (raw && /^\d{10,13}$/.test(raw)) { const ms = raw.length <= 10 ? +raw * 1000 : +raw; expiresInMin = Math.round((ms - Date.now()) / 60000); }
      return { loggedIn: !loggedOut(), sessionExpiresInMin: expiresInMin, lsTotal: lsAll, lsAuthish: pick(localStorage), ss: ssKeys, cookieNames: cookies };
    })();
    // The trace hook.js wrote to sessionStorage — survives a reload, so it shows what the app
    // did in the seconds BEFORE the session was lost, including who called location.reload().
    // Kept apart from the rolling trace so a long session cannot bury it.
    info.TOKEN = (() => {
      try {
        const arr = JSON.parse(sessionStorage.getItem('__ymTokenLog') || '[]');
        return arr.map(e => Math.round((Date.now() - e.t) / 60000) + 'm ago: ' + e.line);
      } catch (e) { return []; }
    })();
    info.trace = (() => {
      try {
        const arr = JSON.parse(sessionStorage.getItem('__ymTrace') || '[]');
        return arr.slice(-22).map(e => Math.round((Date.now() - e.t) / 1000) + 's ' + e.k + ' ' + e.d);
      } catch (e) { return ['unavailable']; }
    })();
    // Checkout is its own world: Yuno holds the card fields in a cross-origin iframe we can
    // never touch, so what matters is the parts that ARE ours — the payment-method buttons, any
    // saved card to select, the Smiles password box, and the on-screen keypad that fills it.
    if (onCheckout()) {
      info.checkout = {
        methods: qav('button, [role="button"], label, div[class*="method"], div[class*="payment"]')
          .filter(e => /tarjeta|mercado pago|pagar con/i.test(e.innerText || '') && (e.innerText || '').length < 40)
          .slice(0, 8).map(e => ({ tag: e.tagName.toLowerCase(), cls: (e.className || '').toString().slice(0, 40), txt: (e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 34) })),
        radios: qav('input[type=radio]').concat([...document.querySelectorAll('input[type=radio]')].filter(e => !vis(e)))
          .slice(0, 8).map(e => ({ id: e.id || '', name: e.getAttribute('name') || '', checked: !!e.checked, vis: vis(e), near: ((e.closest('li, label, div') || {}).innerText || '').replace(/\s+/g, ' ').trim().slice(0, 44) })),
        passBox: (() => { const i = qav('input').find(e => /contrase/i.test((e.placeholder || '') + ' ' + (e.getAttribute('name') || '')) || e.type === 'password'); return i ? { name: i.getAttribute('name') || '', id: i.id || '', type: i.type, ro: !!i.readOnly, cls: (i.className || '').toString().slice(0, 40), len: (i.value || '').length } : null; })(),
        keypad: (() => { const k = qav('button, div, span, li, a').filter(e => /^[0-9]$/.test((e.innerText || '').trim()) && e.children.length === 0); return { count: k.length, keys: k.slice(0, 12).map(e => ({ tag: e.tagName.toLowerCase(), d: (e.innerText || '').trim(), cls: (e.className || '').toString().slice(0, 34) })) }; })(),
        favourites: (() => { try { return favouriteChips().map(c => c.txt).slice(0, 12); } catch (e) { return []; } })(),
        loaders: visibleLoaders().slice(0, 8).map(e => ({
          tag: (e.tagName || '').toLowerCase(),
          cls: String(e.className || '').slice(0, 60),
          busyAttr: e.getAttribute('aria-busy') || '',
          role: e.getAttribute('role') || ''
        })),
        loaderBusy: loaderBusy(),
        netQuietMs: netQuiet(),
        settledMs: settledFor(),
        allFrames: lastFrames,
        iframes: [...document.querySelectorAll('iframe')].map(f => (f.getAttribute('src') || '').replace(/[?#].*/, '').slice(0, 60)).slice(0, 8),
        // SHAPE ONLY of any iframe we can reach — field names/placeholders, never a value. This
        // is what tells us whether Yuno's card inputs are reachable and what identifies them.
        iframeFields: (() => {
          const out = [];
          [...document.querySelectorAll('iframe')].slice(0, 8).forEach((f, i) => {
            let d = null;
            try { d = f.contentDocument; } catch (e) { out.push({ i: i, reach: false, sandbox: f.getAttribute('sandbox') || '', title: (f.getAttribute('title') || '').slice(0, 30) }); return; }
            if (!d || !d.body) { out.push({ i: i, reach: false, sandbox: f.getAttribute('sandbox') || '', title: (f.getAttribute('title') || '').slice(0, 30) }); return; }
            const ins = [...d.querySelectorAll('input')].map(e => ({
              name: e.name || '', id: e.id || '', ph: e.placeholder || '',
              ac: e.getAttribute('autocomplete') || '', type: e.type || '', len: (e.value || '').length
            }));
            out.push({ i: i, reach: true, inputs: ins.slice(0, 6) });
          });
          return out;
        })(),
        confirmBtn: (() => { const b = btnByText(/confirmar pago/i); return b ? { disabled: !!b.disabled, cls: (b.className || '').toString().slice(0, 40) } : null; })()
      };
    }
    info.errors = errCache.slice(0, 8).map(e => e.n + '× ' + Math.round((Date.now() - e.last) / 60000) + 'm ago: ' + e.msg.slice(0, 70));
    info.expired = { showing: !!redoSearchBtn(), redone: redoCount };
    info.pax = { seenMsAgo: paxSeenAt ? Date.now() - paxSeenAt : null, waitMs: paxWaitMs, submits: paxSubmits, aviso: avisoUp() };
    info.tainted = readTaint();
    info.authFail = lastAuthFail();
    info.lastSearch = lastSearchRun();   // did a search actually run on this page, and what came back
    info.search = {
      qs: location.search.slice(0, 150),
      onTarget: lastTargetSeen ? urlMatchesTarget(lastTargetSeen) : null,
      hasBox: !!byId('airport-origin'), state: searchState, fareTries: fareTries
    };
    // total/visible count per id — Smiles duplicates ids across its mobile + desktop markup
    info.dupIds = ['btn-continue', 'type-taxes-selected', 'firstName', 'passengersConfirmButton', 'calendarGo', 'airport-origin']
      .map(id => { const all = document.querySelectorAll('[id="' + id + '"]'); return id + ' ' + all.length + '/' + [...all].filter(vis).length; });
    // Every field on the page and what it currently holds — SHAPE only: digits become # and
    // letters a, so we can see "##/##/####" vs empty vs a wrong format without the diagnostic
    // ever carrying the passenger's real name, passport or phone number.
    const shape = (s) => String(s == null ? '' : s).replace(/\d/g, '#').replace(/[A-Za-zÀ-ÿ]/g, 'a');
    info.inputs = [...document.querySelectorAll('input, select')]
      .filter(el => el.type !== 'password' && !/^(ymacct_|ymb_)/.test(el.id || ''))   // never dump credentials
      .slice(0, 30).map(el => ({
      vis: vis(el),
      id: el.id || '', name: el.getAttribute('name') || '',
      cls: (typeof el.className === 'string' ? el.className : '').slice(0, 46),
      ph: (el.placeholder || '').slice(0, 24),
      type: el.type || '',
      val: shape(el.value).slice(0, 24),
      len: (el.value || '').length,
      checked: (el.type === 'checkbox' || el.type === 'radio') ? !!el.checked : null
    }));
    info.saveBox = (() => { const c = findSaveCheckbox(); return c ? { found: true, checked: !!c.checked, id: c.id || '' } : { found: false }; })();
    // Passenger page: list every visible form control with its id and name so a TWO-passenger
    // booking reveals the real field pattern (birthday-0 / birthday-1, etc.) without guessing.
    if (onPax()) {
      info.paxForm = qav('input, select').filter(e => e.type !== 'hidden')
        .map(e => ({ id: e.id || '', name: e.getAttribute('name') || '', type: e.type || '', ph: (e.placeholder || '').slice(0, 20) }))
        .filter(e => e.id || e.name).slice(0, 40);
    }
    info.session = sessionLogCache.slice(-24).map(e => Math.round((Date.now() - e.t) / 60000) + 'm [' + (e.tab || '?') + '] ' + (e.in ? 'in' : 'OUT') + ' ' + e.st);
    info.thisTab = TABID;
    return JSON.stringify(info);
  }
  function copyDiag() {
    const t = dumpFareInfo();
    navigator.clipboard.writeText(t).then(() => flash('✓ Copied page info — paste it to Claude.')).catch(() => {
      const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;bottom:80px;right:12px;width:300px;height:150px;z-index:2147483647'; document.body.appendChild(ta); ta.focus(); ta.select(); flash('Select-all in the box + copy by hand.');
    });
  }

  // Find Smiles' "Guardar pasajero para futuras compras" checkbox (saves them to the account
  // favorites — treated as irreversible). We NEVER want it on by accident.
  function findSaveCheckbox() {
    // Visible nodes only: a hidden duplicate reading "unchecked" would let us continue while
    // the real, on-screen box is ticked — exactly the accident this guard exists to prevent.
    const nodes = qav('label, span, div');
    const l = nodes.find(x => { const t = (x.innerText || '').trim(); return t.length < 90 && /guardar\s+pasajero/i.test(t); });
    if (!l) return null;
    // A styled checkbox is often 0x0/opacity:0, so we can't filter the INPUT by visibility —
    // instead take the copy of that id sitting inside the same section as the visible label.
    if (l.htmlFor) { const el = idNear(l.htmlFor, l); if (el && el.type === 'checkbox') return el; }
    let cb = l.querySelector && l.querySelector('input[type=checkbox]'); if (cb) return cb;
    for (const sib of [l.previousElementSibling, l.nextElementSibling]) if (sib && sib.matches && sib.matches('input[type=checkbox]')) return sib;
    cb = l.parentElement && l.parentElement.querySelector('input[type=checkbox]'); if (cb) return cb;
    return null;
  }
  // Returns true only if we can CONFIRM the save box is off. false = don't auto-continue.
  function ensureNotSaving() {
    const cb = findSaveCheckbox();
    if (!cb) return false;              // can't find it → refuse to continue
    if (cb.checked) cb.click();         // uncheck (React-friendly)
    return !cb.checked;                 // confirmed off?
  }

  // ---- fare selection on the results page (from the app's Book target) ----
  const digits = (s) => String(s == null ? '' : s).replace(/[^\d]/g, '');
  // A time like "06h30" / "6:30" → "0630" for comparing departure times.
  const hhmm = (s) => { const m = String(s == null ? '' : s).match(/(\d{1,2})\s*[:h]\s*(\d{2})/); return m ? (m[1].length < 2 ? '0' + m[1] : m[1]) + m[2] : ''; };
  // Logged out? Smiles shows an "Iniciá sesión" button and hides miles/selection until you log in.
  // "Salir" showing = definitely logged in, and it settles the question before we go looking for
  // a login button. Without that first check, a page mid-render (neither control drawn yet)
  // reads as logged OUT and produces false alarms — the spurious OUT entries in the session log.
  const loggedOut = () => {
    // The header LIES once the token has expired: it still shows the account name and "Salir"
    // while the API is already answering 401. Confirmed — the keepalive went 200 at 3 minutes
    // left and 401 at -1. So the clock beats the header.
    const left = sessionLeftMin();
    if (left != null && left <= 0) return true;
    const btns = qav('button, a');
    if (btns.some(b => /^\s*salir\s*$/i.test(b.innerText || ''))) return false;
    return btns.some(b => /inici[aá]r?\s*sesi[oó]n/i.test(b.innerText || ''));
  };

  // ---------- in-page search: drive Smiles' OWN search box, never navigate ----------
  // Measured on the live site: clicking Smiles' "Buscar" swaps the URL to /emission?... through
  // the SPA router WITHOUT reloading the document (a marker set on window survives it). Loading
  // that same URL directly is a real document load: the app reboots, and because the session is
  // held in memory it comes back signed out. That is the "every reload signs me out" problem —
  // so we fill the site's own form and press its own button instead.
  const MES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];




  async function searchInPage(t) {
    // JUST LOAD THE SEARCH URL.
    //
    // This used to drive Smiles' own form — typing the airports, clicking a day in the calendar,
    // pressing Buscar — because loading a URL was believed to sign you out. It does not: the
    // session lives in sessionStorage, which survives a same-tab load, and the owner's logs show
    // reload after reload staying signed in. The logouts were the token's 60-minute life ending,
    // and a reload merely revealed it.
    //
    // So the whole form dance was a workaround for a problem that was not real, and every part of
    // it was fragile: an autocomplete whose handler is on an inner <a>, a react-dates calendar
    // that only opens on focus and hides next month's cells, a Buscar that reloads from the
    // results page but not from home. Loading the URL has none of those failure modes.
    if (!t.date || !/^\d{4}-\d{2}-\d{2}$/.test(t.date)) return 'no usable search date on this flight (need YYYY-MM-DD)';
    const q = new URLSearchParams({
      originAirportCode: t.origin, destinationAirportCode: t.destination, departureDate: t.date,
      adults: String(t.adults || 1), children: '0', infants: '0',
      isFlexibleDateChecked: 'false', tripType: '2', cabinType: 'all', currencyCode: 'ARS'
    });
    const url = 'https://www.smiles.com.ar/emission?' + q.toString();
    const onHome = location.pathname === '/' || (!onEmission() && !!byId('airport-origin'));

    // If the SEARCH EXPIRED ("Límite de tiempo caducado"), reloading /emission just restores the
    // same stale search and the modal comes back — an endless loop. Loading the HOME page first
    // clears that state, so the next /emission load is a genuinely fresh search. This is the fix
    // for "it should click the home page to search" — go home to reset, then load the results.
    if ((redoSearchBtn() || forceHome) && !onHome) {
      const why = redoSearchBtn() ? 'search expired' : 'restarting clean';
      forceHome = false;
      try { sessionStorage.removeItem('ymNav:' + t.origin + t.destination + t.date); } catch (e) {}   // fresh cycle
      logSession({ st: why + ' -> going home to reset', ok: true, in: !loggedOut() });
      try { location.replace('https://www.smiles.com.ar/'); } catch (e) { location.href = 'https://www.smiles.com.ar/'; }
      return '';
    }

    // Count the loads in sessionStorage (a module counter resets on every navigation). Three
    // fruitless loads of the same search -> stop, rather than reload forever.
    const key = 'ymNav:' + t.origin + t.destination + t.date;
    let n = 0;
    try { n = parseInt(sessionStorage.getItem(key) || '0', 10) || 0; } catch (e) {}
    if (n >= 4) return 'loaded this search 4 times and it still is not showing flights';
    try { sessionStorage.setItem(key, String(n + 1)); } catch (e) {}
    logSession({ st: 'search: loading ' + t.origin + '->' + t.destination + ' ' + t.date + ' (try ' + (n + 1) + (onHome ? ', from home' : '') + ')', ok: true, in: !loggedOut() });
    try { location.replace(url); } catch (e) { location.href = url; }
    return '';
  }

  // Are we already looking at the results for the flight we were asked to book?
  // Smiles expires a search after ~15 minutes: "Límite de tiempo caducado … es necesario hacer
  // una nueva búsqueda", with its own "Rehacer búsqueda" button. NOT a logout — only the prices
  // went stale. We never press that button (it reloads the page); we just load a fresh search.
  const redoSearchBtn = () => btnByText(/rehacer\s+b[uú]squeda/i);

  function urlMatchesTarget(t) {
    let p; try { p = new URLSearchParams(location.search); } catch (e) { return false; }
    return (p.get('originAirportCode') || '').toUpperCase() === (t.origin || '').toUpperCase()
      && (p.get('destinationAirportCode') || '').toUpperCase() === (t.destination || '').toUpperCase()
      && (p.get('departureDate') || '') === (t.date || '');
  }

  // Select the target flight by departure time + cabin (each flight is a #flight-SEGMENT_1-N row
  // like "LGA 06h30 … YUL 07h57 Clase Económica"). Click the row's select button (not "Detalles").
  function selectFare(target) {
    const wantTime = hhmm(target.dep);
    const wantExec = /business|ejecutiv/i.test(target.cabin || '');
    const O = (target.origin || '').toUpperCase(), D = (target.destination || '').toUpperCase();
    const segs = qav('[id^="flight-SEGMENT"]');
    if (segs.length && target) {
      try {
        sessionStorage.removeItem('ymNav:' + target.origin + target.destination + target.date);
        sessionStorage.removeItem('ymEmpty:' + target.origin + target.destination + target.date + (target.adults || 1));
      } catch (e) {}
    }
    // CRITICAL: the #flight-SEGMENT element's own text is just "Detalles del vuelo" — the times/
    // route/cabin live on its ancestor CARD. Match the card's text, never the segment's. Stop
    // climbing before an ancestor that holds two flights, or we'd read the neighbour's times.
    const cardOf = (s) => {
      let r = s, best = s;
      for (let k = 0; k < 8 && r.parentElement; k++) {
        r = r.parentElement;
        if (r.querySelectorAll('[id^="flight-SEGMENT"]').length > 1) break;
        best = r;
        if ((r.innerText || '').length > 60) break;
      }
      return best;
    };
    const cards = segs.map(s => {
      const c = cardOf(s), t = c.innerText || '';
      // EVERY time on the card, in order — the first one is NOT always the departure (a
      // duration like "1h27" reads the same), so we match the departure first, then any time.
      return { seg: s, card: c, t: t, T: t.toUpperCase(), times: (t.match(/\d{1,2}\s*[h:]\s*\d{2}/g) || []).map(hhmm) };
    });
    // The customer chose this flight, including how many stops — match its stop count so we book
    // exactly what they picked. A card reads "DIRECTO" (0) or "N ESCALA(S)". Default 0 (direct).
    const wantStops = (target.stops != null) ? target.stops : 0;
    const cardStops = (c) => { const m = (c.t || "").match(/(\d+)\s*ESCALA/i); return m ? +m[1] : 0; };
    const routeOk = (c) => cardStops(c) === wantStops && (!O || c.T.indexOf(O) !== -1) && (!D || c.T.indexOf(D) !== -1);
    const cabinOk = (c) => { const ex = /ejecutiva|business/i.test(c.t); return wantExec ? ex : !ex; };
    const m = cards.find(c => routeOk(c) && cabinOk(c) && c.times[0] === wantTime)
      || cards.find(c => routeOk(c) && cabinOk(c) && c.times.indexOf(wantTime) !== -1)
      || cards.find(c => routeOk(c) && c.times[0] === wantTime)
      || cards.find(c => routeOk(c) && c.times.indexOf(wantTime) !== -1);
    if (!m) return { done: false, flights: segs.length, note: 'no ' + O + '→' + D + ' ' + wantTime + (wantExec ? ' exec' : ' econ') + ' row' };
    // Find the fare labels that BELONG to this flight (walk up from each label to its owning row).
    const fares = visFares().filter(l => segOfFare(l) === m.seg);
    if (!fares.length) {   // no inline fare in this flight's card — click the row to open its fare view
      const pickBtn = (root) => [...root.querySelectorAll('button, [role="button"], a')].filter(vis).find(b => !/detalles/i.test(b.innerText || ''));
      realClick(pickBtn(m.seg) || pickBtn(m.card) || m.seg);
      return { done: true, note: 'clicked row' };
    }
    // One of this flight's fares already selected? Then a previous click landed — touch nothing.
    // (Clicking a selected fare DESELECTS it and takes the booking context with it.)
    if (fares.some(labelChecked)) return { done: true, note: 'fare selected' };
    // We book the fare we QUOTED — normally the Club price, the first entry in target.miles.
    // Never quietly fall back to a dearer fare: taking 13.000 when the quote said 11.400 costs
    // real miles on every booking. If the fare we want won't select, we stop and say so.
    const wants = (target.miles || []).map(digits).filter(Boolean);
    let want = null, lab = null;
    if (wants.length) {
      want = wants.find(w => fares.some(l => fareMiles(l) === w));
      lab = want ? fares.find(l => fareMiles(l) === want) : null;
      if (!lab) return { done: false, flights: segs.length, note: 'no ' + wants[0] + ' fare here (this flight offers ' + fares.map(fareMiles).join('/') + ')' };
    } else {
      // No price quoted — an order queued by hand, say. Take the CLUB fare, which is the one we
      // always book. Not "the cheapest": the fare list also carries Viaje Fácil instalment
      // amounts (1800, 2000, 3300…), and the lowest number on the card is one of those, not a
      // flight. Matching the Club wording picks the real fare every time.
      lab = fares.find(l => /club\s*smiles|diamante/i.test(l.innerText || ''));
      if (!lab) return { done: false, flights: segs.length, note: 'no Club fare on this flight (it offers ' + fares.map(fareMiles).join('/') + ') — pick one yourself' };
      want = fareMiles(lab);
    }
    const inp = fareInput(lab);
    if (inp && inp.disabled) return { done: false, flights: segs.length, note: want + ' is DISABLED for this account — pick the fare yourself' };
    // Which element carries the handler varies (we've already been bitten by it living on an
    // inner <a> and on a row <li>), so work through input → label → row, one per pass, checking
    // in between whether it took. Each target is tried once: a second click would deselect.
    const targets = [inp, lab, lab.closest('li, .form-check')].filter(Boolean);
    if (fareAttempt >= targets.length) return { done: false, flights: segs.length, note: 'clicked the ' + want + ' fare every way I know and it will not select — click it yourself and I\'ll carry on' };
    const hit = targets[fareAttempt++];
    realClick(hit);
    return { done: true, note: 'picked ' + want + ' (via ' + (hit.tagName || '?').toLowerCase() + ')' };
  }

  // Leading miles on a fare label ("11.400 + tasas o impuestos Club…" → "11400").
  const fareMiles = (lab) => digits((lab.innerText || '').split(/\+|tasas|millas/i)[0]);
  // The radio behind a fare label. htmlFor goes through idNear, not getElementById, because a
  // hidden duplicate of that id would otherwise answer for the real one.
  function fareInput(lab) {
    if (!lab) return null;
    if (lab.htmlFor) { const el = idNear(lab.htmlFor, lab); if (el && /^(radio|checkbox)$/.test(el.type || '')) return el; }
    const inside = lab.querySelector && lab.querySelector('input'); if (inside) return inside;
    const prev = lab.previousElementSibling; if (prev && prev.matches && prev.matches('input')) return prev;
    const box = lab.closest && lab.closest('li, .form-check');
    return (box && box.querySelector('input')) || null;
  }
  const labelChecked = (lab) => { const i = fareInput(lab); return !!(i && i.checked); };
  // A fare this account can't take (Club-only pricing, or sold out) — clicking it does nothing.
  function fareDisabled(lab) {
    const inp = fareInput(lab);
    if (inp && inp.disabled) return true;
    const box = lab.closest('li, .form-check');
    return !!(box && /disabled/i.test((box.className || '').toString()));
  }
  // On the fare/tax step, pick the MILLAS fare matching the target miles (prefer club = first want).
  // Don't re-click one that's already selected — some are checkboxes and a 2nd click deselects.
  function selectMilesFare(target) {
    const wants = (target.miles || []).map(digits).filter(Boolean);
    const labels = [...document.querySelectorAll('label.form-check-label')].filter(l => l.offsetParent);
    for (const w of wants) {
      const m = labels.find(l => fareMiles(l) === w);
      if (m) { if (!labelChecked(m)) m.click(); return w; }
    }
    return null;
  }
  // On the fare/tax step? (fare options carrying "tasas/millas" text, the tax slider, or terms box.)
  function onFareTax() {
    return !!(q('#type-taxes-selected') || q('label.form-check-label-emission.check-tc') || visFares().length);
  }
  // Agree the terms checkbox — find it by nearby wording; only click if not already checked.
  function agreeTerms() {
    const cbs = [...document.querySelectorAll('input[type=checkbox]')].filter(c => c.offsetParent);
    for (const c of cbs) {
      const lab = (c.labels && c.labels[0] && c.labels[0].innerText) || (c.closest('label') && c.closest('label').innerText) || (c.parentElement && c.parentElement.innerText) || '';
      if (/acuerdo|acepto|t[eé]rminos|condiciones|pol[ií]tica/i.test(lab)) { if (!c.checked) c.click(); return true; }
    }
    const tc = q('label.form-check-label-emission.check-tc');
    if (tc) { const inp = tc.htmlFor ? idNear(tc.htmlFor, tc) : (tc.querySelector('input') || null); if (!inp || !inp.checked) realClick(tc); return true; }
    return false;
  }
  // Click "Continuar": by id, else by button text. Smiles disables it via a CSS class (not the
  // .disabled property), so check both. Returns 'clicked' | 'disabled' | 'none'.
  function clickContinue() {
    let c = byId('btn-continue');
    if (!c) c = btnByText(/^\s*continuar\s*$/i);
    if (!c) return 'none';
    if (c.disabled || /(^|\s)disabled(\s|$)/.test(typeof c.className === 'string' ? c.className : '')) return 'disabled';
    realClick(c); return 'clicked';
  }


  // ---------------- Smiles' random errors ----------------
  // The site throws popups of its own accord, and most of them clear if you simply start over.
  // So: recognise the dialog, KEEP A TALLY of what it said, dismiss it, and restart from the home
  // page. A message seen many times is a known quirk of theirs; one seen once, next to a failure,
  // is worth reading. Bounded to two restarts per booking — retrying harder than the site can
  // cope with is how a small glitch becomes a mess.
  const ERRLOG = 'ymErrorLog';
  let errRetries = 0, lastErrRetry = 0, errCache = [];
  sGet(ERRLOG, (r) => { errCache = (r && r[ERRLOG]) || []; });

  function recordError(msg) {
    sGet(ERRLOG, (r) => {
      const list = (r && r[ERRLOG]) || [];
      const at = list.findIndex(e => e.msg === msg);
      if (at >= 0) { list[at].n++; list[at].last = Date.now(); }
      else list.push({ msg: msg, n: 1, first: Date.now(), last: Date.now() });
      list.sort((a, b) => b.last - a.last);
      errCache = list.slice(0, 40);
      sSet({ [ERRLOG]: errCache });
    });
  }

  // A dismissable dialog whose wording reads like a failure. The search-expiry notice is handled
  // elsewhere and must not be treated as an error, so it is excluded.
  function errorDialog() {
    if (redoSearchBtn()) return null;
    const btn = btnByText(/^\s*(entend[ií]|aceptar|ok|cerrar|continuar)\s*$/i);
    if (!btn) return null;
    let box = btn.closest('[role="dialog"], [class*="modal"], [class*="Modal"]');
    if (!box) box = btn.parentElement && btn.parentElement.parentElement;
    const txt = ((box && box.innerText) || '').replace(/\s+/g, ' ').trim();
    if (!txt || txt.length > 400) return null;
    if (!/error|aviso|atenci[oó]n|no fue posible|no pudimos|no se pudo|intent|problema|inv[aá]lid|fall[oó]/i.test(txt)) return null;
    return { btn: btn, txt: txt.slice(0, 150) };
  }


  // Move the running order along the queue. The console watches these, so the operator sees
  // where a booking got to without reading the drive bar — and knows when the next can start.
  function setOrderStatus(status, extra) {
    sGet(CURRENT, (sc) => {
      const id = sc && sc[CURRENT];
      if (!id) return;
      sGet(ORDERS, (so) => {
        const list = (so && so[ORDERS]) || [];
        const i = list.findIndex(o => o.id === id);
        if (i < 0 || list[i].status === status) return;
        list[i].status = status;
        if (extra) Object.assign(list[i], extra);
        list[i].at = Date.now();
        sSet({ [ORDERS]: list });
      });
    });
  }

  // Did the booking actually complete? Smiles' last step is "Finalizado" and shows a booking
  // code. Best effort — if it is missed, the console still has a manual "done" button, because
  // guessing wrong about a completed purchase is worse than asking.
  function bookingConfirmed() {
    if (/finalizad|confirmac|success/i.test(location.pathname)) return true;
    try {
      const t = ((document.body && document.body.innerText) || '').slice(0, 3000);
      return /c[oó]digo de reserva|reserva confirmada|felicitaciones|compra realizada/i.test(t);
    } catch (e) { return false; }
  }

  // ---------------- auto-drive state machine ----------------
  // Smiles is a single-page app — navigations don't reload the script. Guard by the path we last
  // acted on (resets automatically when the step changes) instead of a once-per-load flag.
  let actedStep = '';
  let lastAdvance = 0;   // when we last clicked Continuar (cooldown so we don't double-submit)
  let lastFareTry = 0;   // the flight pick RETRIES: one shot was the old bug (a missed click stuck forever)
  let fareTries = 0;
  let fareAttempt = 0;   // which click target we're on for the wanted fare (never repeat one)
  let showAccounts = false;   // the panel is reachable anywhere, not only on the login modal
  let lastRedo = 0, redoCount = 0, lastExpirySeen = 0, lastLogoutLog = 0, lastLoginHop = 0;
  let forceSearch = false;
  let lastStartedAt = 0;     // the drive stamp we have already acted on
  const EMPTY_RETRIES = 3;   // restarts before an empty results page is believed
  const TAINT = 'ymTainted';   // we acted on this page with no session -> everything here is void
  function readTaint() { try { return JSON.parse(sessionStorage.getItem(TAINT) || 'null'); } catch (e) { return null; } }
  function lastAuthFail() { try { return JSON.parse(sessionStorage.getItem('__ymAuthFail') || 'null'); } catch (e) { return null; } }
  let forceHome = false;     // next search should bounce through the home page first
  let sawSignedOut = false;
  const pageStartedAt = Date.now();   // this document's load, to date-stamp searches against
  function lastSearchRun() {
    try { return JSON.parse(sessionStorage.getItem('__ymLastSearch') || 'null'); } catch (e) { return null; }
  }   // a booking was armed while the session was gone
  let armedKey = '', freshStart = false;      // a new Book always restarts from the home page
  let lastHref = location.href, routeAt = 0;  // SPA route changes need a moment to settle   // expiry dialog is up: re-search even though the URL still matches   // Smiles' "Límite de tiempo caducado" -> Rehacer búsqueda
  let paxSeenAt = 0, paxWaitMs = 8000, paxSubmits = 0, paxReadyAt = 0;   // the passenger page needs time to load its booking
  // Smiles' error popup ("Aviso … Entendí") — its OK button is the reliable marker.
  const avisoUp = () => !!btnByText(/^entend[ií]$/i);
  let loggedOutTicks = 0;                                  // the SPA renders "Iniciá sesión" while booting
  let searchState = { key: '', phase: '', err: '', tries: 0 };   // in-page search bookkeeping
  const targetKey = (t) => [t.origin, t.destination, t.date].join('|').toUpperCase();
  // Strip the search params my Book navigation put in the URL, so a plain user reload afterwards
  // does NOT re-run the last search. Called whenever the drive ends.
  // NOTE: we used to strip the query string when a drive ended, so a later reload wouldn't
  // re-run the last search. That belonged to the old flow where Book put the search into the
  // URL itself. It must never come back: rewriting the URL of a live SPA leaves /emission with
  // no route or date, the results page has nothing to render, and you get a WHITE PAGE. Smiles
  // now puts those params there itself, exactly as it would for a person — leave them alone.
  // Stop driving rather than grinding away. Everything stays armed, so pressing Book starts the
  // whole thing again cleanly from the home page — which is the recovery that actually works.
  // Is Smiles itself broken right now? hook.js records every auth-ish API call and its status
  // into sessionStorage, so recent 5xx / network failures are readable from here. Worth saying:
  // "the search failed 3 times" reads like our bug when their gateway is timing out.
  function smilesErroring() {
    try {
      const arr = JSON.parse(sessionStorage.getItem('__ymTrace') || '[]');
      const since = Date.now() - 120000;
      return arr.filter(e => e.t > since && /^auth-(xhr|fetch) (5\d\d|ERR)/.test(e.k || '')).length;
    } catch (e) { return 0; }
  }

  function giveUp(why) {
    setOrderStatus('stopped', { step: '⛔ ' + String(why).slice(0, 80) });
    const bad = smilesErroring();
    if (bad >= 2) why += ' — but the Smiles API is failing right now (' + bad + ' server errors in the last 2 min), so this is on their end, not ours';
    sSet({ [DRIVE]: { on: false } });
    logSession({ st: 'gave up: ' + why, ok: false, in: !loggedOut() });
    flash('⛔ Stopped — ' + why + '. Press Book again to start over from scratch.');
  }

  function resetDriveState() {
    // A deliberate restart starts the evidence fresh. Keeping the old counts meant pressing Book
    // could inherit a previous run's verdict and give up before trying anything.
    try {
      Object.keys(sessionStorage)
        .filter(k => k.indexOf('ymNav:') === 0 || k.indexOf('ymEmpty:') === 0)
        .forEach(k => sessionStorage.removeItem(k));
    } catch (e) {}
    errRetries = 0; lastErrRetry = 0; actedStep = ''; lastHref = location.href; routeAt = Date.now(); fareTries = 0; fareAttempt = 0; forceSearch = false; paxSeenAt = 0; paxWaitMs = 8000; paxSubmits = 0; paxReadyAt = 0; lastFareTry = 0; loggedOutTicks = 0; searchState = { key: '', phase: '', err: '', tries: 0 }; }
  function startDrive() { resetDriveState(); sSet({ [DRIVE]: { on: true, startedAt: Date.now() } }); flash('Auto-drive ON — search → pick the flight → terms → fill → stop at checkout.'); }
  function stopDrive() { sSet({ [DRIVE]: { on: false }, [TARGET]: null }); flash('Auto-drive stopped.'); }
  // Which step of the booking we're on. fare + tax share /emission, so we can't guard by path alone.
  function currentStep() {
    if (onCheckout()) return 'checkout';
    if (onPax()) return 'pax';
    if (!onEmission()) return '';
    // Fare/tax step = the tax slider, terms box, or a Continuar button is present (these appear only
    // after a fare is selected — the plain results list has none of them).
    if (q('#type-taxes-selected') || document.querySelector('label.form-check-label-emission.check-tc') || q('#btn-continue')) return 'tax';
    // Results list = pick a flight/fare here.
    if (document.querySelector('[id^="flight-SEGMENT"]')) return 'fare';
    if (onFareTax()) return 'tax';
    return '';
  }
  // ---- progress watchdog -----------------------------------------------------------------
  // This site is unpredictable and always will be, so handling each failure by name is a losing
  // game: there is always a new one. Instead of asking "what went wrong?", this asks "are we
  // still MOVING?". Every tick builds a signature of where the booking is; while that keeps
  // changing we are fine. When it stops changing — for a known reason, or one we have never seen
  // — the same recovery ladder runs. A brand-new failure needs no new code: it simply stops
  // progress, and the ladder picks it up.
  //
  // The clock only runs while the page is IDLE. A genuinely slow load keeps Smiles' network busy,
  // so slow is never mistaken for stuck; patient with slow, decisive with dead.
  let progAt = 0, progSig = '', recoverStep = 0, lastRecoverAt = 0, headerOutSince = 0;
  const STUCK_MS = 45000;      // idle and unchanged this long -> recover
  const LOAD_MAX = 60000;     // 'loading' this long without finishing -> recover (never act)
  let loadingSince = 0;

  function watchdog(step, target, out) {
    if (!target) { progSig = ''; progAt = 0; recoverStep = 0; return false; }
    // NEVER touch a booking that is waiting on the operator. At checkout they are ticking the
    // captcha, keying the PIN, entering the card, pressing Pagar — all slow, all human, and a
    // "helpful" restart there could throw away a reservation that is mid-payment. Same for the
    // login modal. Those states are legitimately still, not stuck.
    if (step === 'checkout' || onCheckout() || loginFields()) { progAt = Date.now(); recoverStep = 0; return false; }
    const sig = location.pathname + '|' + step + '|' + actedStep + '|' + (out ? 'out' : 'in');
    if (sig !== progSig) { progSig = sig; progAt = Date.now(); recoverStep = 0; loadingSince = 0; return false; }
    if (smilesLoading()) {
      // Waiting on a real load has no time limit — but "loading" that never ends is itself a
      // failure, and the answer is to RESTART, never to press on. That is the difference that
      // matters: a number that decides to give up is safe, a number that decides to act is not.
      if (!loadingSince) loadingSince = Date.now();
      if (Date.now() - loadingSince < LOAD_MAX) { progAt = Date.now(); return false; }
      progAt = Date.now() - STUCK_MS - 1;                           // age it so the ladder runs
    }
    // NOTE: loadingSince is cleared only when the page actually MOVES (the sig change above), not
    // whenever the loading signal flickers off. Smiles' AGUARDÁ overlay drops and returns while
    // nothing progresses, and resetting on each flicker meant this timer never reached its limit —
    // the spinner sat there indefinitely.
    if (!progAt) { progAt = Date.now(); return false; }
    if (Date.now() - progAt < STUCK_MS) return false;
    if (Date.now() - lastRecoverAt < 20000) return true;            // let the last attempt breathe
    lastRecoverAt = Date.now();
    recoverStep++;
    const secs = Math.round((Date.now() - progAt) / 1000);
    logSession({ st: 'watchdog: stuck ' + secs + 's at ' + sig + ' -> recovery ' + recoverStep, ok: false, in: !out });

    // RESTART FIRST. A page load does not cost a sign-in — the session lives in sessionStorage and
    // survives a same-tab load (measured: reload after reload stayed signed in; what ends a session
    // is the 60-minute token). So starting the booking over from the home page is cheap, and it
    // clears nearly everything: a stale render, a dead search, a page that half-loaded, a state
    // neither of us has seen. Diagnosing comes second, because usually there is nothing to diagnose.
    if (recoverStep === 1) {
      resetDriveState(); progAt = Date.now();
      forceHome = true;      // bounce through the home page — that is what clears a stuck overlay
      // NOT armedKey='' — that makes the new-target check below run resetDriveState again, which
      // clears forceSearch and quietly cancels the restart. forceSearch alone re-runs the search.
      forceSearch = true;
      flash('↻ Nothing moved for ' + secs + 's — starting this booking over from the beginning.');
      return true;
    }
    // A restart did not fix it, so now the reason matters. No session is the one cause a restart
    // cannot clear on its own, because every page it lands on will refuse to book.
    if (recoverStep === 2 && out) {
      sGet(ACTIVE, (sa) => sSet({ ymLoginRequest: { dni: (sa && sa[ACTIVE]) || '', at: Date.now() } }));
      flash('↻ A restart did not help and the session is gone — opening the login. One tick and it carries on.');
      return true;
    }
    // Not a session problem and a restart did not help: park it. The queue moves on to the next
    // booking; this one waits in the console with what it saw, instead of holding everything up.
    giveUp('stuck at ' + (step || 'the page') + ' — a restart did not clear it');
    return true;
  }

  function driveTick() {
    // Only drive in the FOREGROUND tab. A hidden tab is a throwaway background search tab that also
    // has this script injected — letting it drive meant two tabs booking at once and logging each
    // other out. The tab the operator is watching is 'visible'; those are not.
    if (document.visibilityState === 'hidden') return;
    sGet([DRIVE, KEY, TARGET, PAXL], (st) => {
      const drive = (st && st[DRIVE]) || {};
      driveOnCache = !!drive.on;
      const data = (st && st[KEY]) || {};
      // every traveller, in order (index 0 is the same person KEY holds)
      let paxAll = (st && st[PAXL]) || [];
      paxAll = paxAll.length ? paxAll.slice() : [data];
      if (!paxAll[0] || !paxAll[0].first) paxAll[0] = data;   // index 0 is whoever KEY holds
      const target = (st && st[TARGET]) || null;
      lastTargetSeen = target;
      // Book pressed again (even on the same flight the tab is already showing) stamps a new
      // startedAt. Without this the driver saw "same target, same URL" and carried on waiting on
      // whatever broken page it was already sitting on, so Book appeared to do nothing.
      if (drive.on && drive.startedAt && drive.startedAt !== lastStartedAt) {
        if (lastStartedAt) { resetDriveState(); forceSearch = true; flash('↻ Starting this booking over…'); }
        lastStartedAt = drive.startedAt;
      }
      setDriveBtn(drive.on);
      if (!drive.on) { if (driveStatusEl) driveStatusEl.textContent = target ? ('Ready: ' + (target.summary || 'a flight') + ' — hit ▶ to book') : ''; return; }
      if (drive.startedAt && Date.now() - drive.startedAt > 6 * 60 * 1000) {
        // Safety net, not a load timer: a booking that has been running six minutes is not going
        // to finish on its own. It stops (never touches the URL) and SAYS SO, rather than the
        // driver quietly disappearing and looking like it broke.
        sSet({ [DRIVE]: { on: false }, [TARGET]: null });
        setOrderStatus('stopped', { step: '⛔ ran 6 minutes without finishing — stopped' });
        flash('⛔ This booking ran 6 minutes without finishing — stopped. Press Book to start it over.');
        return;
      }
      const step = currentStep();
      if (watchdog(step, target, loggedOut())) return;   // recovering — skip this tick's normal work

      // ---- invalid page: restart because of WHAT HAPPENED, not how long it has spun -----------
      // If we filled or submitted something while the session was gone, Smiles had nothing to
      // process it with, so the page will sit on AGUARDÁ forever. That is a fact about what took
      // place, knowable the moment it happens — no loader timer, no waiting to see. Same for a
      // 401/403: the site stating outright that the session is dead. Either one means everything
      // on this page is void, so the booking restarts through the home page immediately.
      //
      // Deliberately ABOVE the busy gate: the whole point is to escape a loader that never clears,
      // and a gate that waits for the page to stop loading could never let us out of one.
      if (target) {
        if (loggedOut() && actedStep) {
          try { sessionStorage.setItem(TAINT, JSON.stringify({ at: Date.now(), step: actedStep })); } catch (e) {}
        }
        const af = lastAuthFail();
        const tainted = readTaint();
        const authDead = af && af.at > pageStartedAt;
        if (tainted || authDead) {
          try { sessionStorage.removeItem(TAINT); sessionStorage.removeItem('__ymAuthFail'); } catch (e) {}
          resetDriveState();
          forceHome = true; forceSearch = true;
          const why = authDead ? 'Smiles rejected the session (' + af.status + ')'
                               : 'this page was filled while signed out, so nothing was accepted';
          logSession({ st: 'invalid page — ' + why + ' -> restarting from home', ok: true, in: !loggedOut() });
          flash('↻ ' + why.charAt(0).toUpperCase() + why.slice(1) + ' — restarting this booking from the beginning.');
          return;
        }
      }

      // NOTHING happens while the page says it is loading, and nothing happens for a beat after it
      // stops. This sits above every step — fare, tax, passenger, continue — so no click and no
      // keystroke can land on a page that is still putting itself together.
      const busyWhy = pageBusy();
      if (busyWhy) { flash('⏳ ' + busyWhy + '…'); return; }
      if (settledFor() < SETTLE_AFTER_LOAD) { flash('⏳ Loaded — settling for a second…'); return; }

      // Spot a NEW booking here, BEFORE the checkout handler below. That handler returns early,
      // so queuing a second flight while the tab sat on the payment page of the first one did
      // nothing at all: the page just stayed put. A new target has to be able to walk away from
      // whatever the last booking left on screen.
      if (target) {
        const nk = targetKey(target);
        if (nk !== armedKey) {
          armedKey = nk;
          resetDriveState();
          freshStart = !urlMatchesTarget(target);
          if (freshStart) flash('↻ New booking — loading its search…');
        }
      } else { armedKey = ''; freshStart = false; }

      if (bookingConfirmed() && !freshStart) {
        setOrderStatus('done');
        sSet({ [DRIVE]: { on: false }, [TARGET]: null, [CURRENT]: '' });
        flash('🎉 Booked. Marked done — open the console to run the next one.');
        return;
      }
      if (step === 'checkout' && !freshStart) {
        setOrderStatus('payment');
        // Don't down tools here any more: pick the card and type the PIN, then hand over for the
        // captcha and Confirmar pago. Keep the drive alive so the stale timer can't kill it while
        // you are paying — nothing here presses Confirmar, so waiting costs nothing.
        if (drive.startedAt && Date.now() - drive.startedAt > 4 * 60 * 1000) sSet({ [DRIVE]: { on: true, startedAt: Date.now() } });
        sGet(ACTIVE, (sa) => {
          const want = sa && sa[ACTIVE];
          sGet(ACCTS, (sb) => {
            const list = (sb && sb[ACCTS]) || [];
            checkoutTick(list.find(x => x.dni === want) || list[0] || null);
          });
        });
        return;
      }

      // Search expired ("Límite de tiempo caducado"). Touch NOTHING here.
      // Measured: Smiles' own "Rehacer búsqueda" reloads the document. And v0.90's idea —
      // quietly re-running our own search from this page instead — reloaded it too, which is
      // how a signed-in tab went straight from "in 200" to "PAGE-LOAD(reload)" and out. From
      // the results page there is currently NO known way to refresh a search without a reload,
      // so we stop and say so rather than spend the session guessing.
      // Search expired ("Límite de tiempo caducado")? Never press Smiles' own button — it
      // reloads. Instead force our own search, which now goes home first and searches from
      // there: the one route measured to refresh results without a document load.
      // Search expired. The dialog greys the page out for a PERSON — the only thing you can
      // click is Smiles' own button, and that reloads. Our clicks go straight to the element,
      // so we can still reach the home link underneath it. That makes this the only route out
      // that keeps the session, and it is now fenced: searchInPage always leaves /emission
      // first and flatly refuses to press Buscar there.
      if (redoSearchBtn() && target) forceSearch = true;

      // A results page loaded while signed OUT shows nothing, and signing in afterwards does not
      // re-run it — the URL still matches the target, so the driver sat on an empty page forever.
      // Note the signed-out spell, and when the session comes back, search again.
      if (loggedOut()) { sawSignedOut = true; }
      else if (sawSignedOut && target) {
        sawSignedOut = false;
        forceSearch = true;
        logSession({ st: 'signed back in — re-running the search (the page loaded signed out)', ok: true, in: true });
        flash('↻ Signed in — running the search again (the page loaded before you were in).');
      }
      // NOTHING happens until we are signed in. Searching does not need an account, which is why
      // this used to run after the search — but with a booking armed that is wrong: it kicked off
      // a search behind the login modal, on a page that was still loading. Sign in first, then
      // work out where we are and what is next.
      // The header read is flaky mid-transition and threw false "Checking the session" prompts.
      // The session CLOCK is reliable (measured: 200 at 3m left, 401 at -1m). So if the clock says
      // there is time left, we are signed in regardless of what the header momentarily shows.
      const clockLeft = sessionLeftMin();
      // The header lies BOTH ways. It shows you signed in after the token died (measured), and it
      // shows you signed out while the token is still valid — a reloaded page whose session never
      // rehydrated, which is what left a booking loading forever with 38 minutes still on the
      // clock. So: ignore a brief blip, but believe a logged-out header that PERSISTS. By then the
      // page genuinely cannot finish a booking, whatever the token says.
      const headerOut = loggedOut();
      if (!headerOut) headerOutSince = 0; else if (!headerOutSince) headerOutSince = Date.now();
      const persistentlyOut = headerOut && headerOutSince && Date.now() - headerOutSince > 25000;
      if (headerOut && (!(clockLeft != null && clockLeft > 0) || persistentlyOut)) {
        const lm = clockLeft;
        // A booking is armed and there is no session: take ourselves to the login page and fill
        // the account in. Nothing is lost by navigating — the session is already gone — and the
        // flight stays armed, so once you clear the captcha the booking carries straight on.
        if (target && !onLogin() && (lm == null || lm <= 0 || loggedOutTicks >= 3) && Date.now() - lastLoginHop > 20000) {
          lastLoginHop = Date.now();
          const li = btnByText(/inici[aá]r?\s*sesi[oó]n/i);
          flash('🔑 Session gone — opening the login so you can sign in; your flight stays armed.');
          if (li) li.click();   // opens the modal in place — no navigation needed
          return;
        }
        if (lm != null && lm <= 0) { flash('⛔ Session EXPIRED (the page still shows you logged in — it is wrong). Log in on this tab; the booking resumes by itself.'); return; }
        if (++loggedOutTicks < 4) { flash('⏳ Checking the session…'); return; }
        // Logging back in means a captcha, which can take a while. Hold the 6-minute stale-drive
        // timer off while we're waiting, so the flight you pressed Book on is still armed when
        // you get back in and the booking carries on instead of starting over.
        if (drive.startedAt && Date.now() - drive.startedAt > 3 * 60 * 1000) {
          sSet({ [DRIVE]: { on: true, startedAt: Date.now() } });
        }
        if (Date.now() - lastLogoutLog > 60000) { lastLogoutLog = Date.now(); logSession({ st: 'LOGGED OUT while driving ' + location.pathname, ok: false, in: false }); }
        flash('⚠ This Smiles tab is logged OUT — log in on THIS tab and I\'ll pick up where I left off (your flight is still armed).');
        return;
      }
      loggedOutTicks = 0;

      // Signed out but the clock still shows time, so the block above chose not to force a login
      // yet — a brief flicker is not worth a captcha. It must NOT license an action, though. This
      // is the gap that filled a passenger form on a signed-out page and left it behind an AGUARDÁ
      // that could never resolve: without a session Smiles cannot answer, so it spins forever.
      // Deciding when to re-login and deciding whether it is safe to act are different questions.
      if (headerOut && target) {
        flash('⏳ This page says you are signed out — nothing will be clicked or filled until the session is back.');
        return;
      }

      // Page still working? Sit still. This is the single most repeated instruction from the
      // owner and it applies to every step below, not just the search.
      if (pageTranslated()) { flash('⛔ This page is TRANSLATED. I match Smiles\' Spanish buttons ("Buscar", "Confirmar pago"), so nothing will be found. Right-click → show original, then press Book.'); return; }
      const busy = pageBusy();
      if (busy) { flash('⏳ ' + busy + ' — waiting…'); return; }

      // Smiles threw one of its own popups? Note what it said, clear it, and start the booking
      // over from the home page — that is what usually clears it.
      const derr = errorDialog();
      if (derr) {
        recordError(derr.txt);
        // Site down vs a one-off glitch are different things. If their API is throwing 5xx, no
        // amount of restarting helps — wait it out instead of spending the retry budget.
        const down = smilesErroring();
        if (down >= 3) { flash('🌐 Smiles is having server trouble (' + down + ' API errors in 2 min) — waiting for them, not retrying.'); return; }
        if (errRetries >= 2) { giveUp('Smiles kept erroring: "' + derr.txt.slice(0, 90) + '"'); return; }
        if (Date.now() - lastErrRetry < 15000) { flash('⏳ Smiles error — letting it settle before retrying…'); return; }
        lastErrRetry = Date.now(); errRetries++;
        logSession({ st: 'error dialog -> restart (' + errRetries + '/2): ' + derr.txt.slice(0, 60), ok: false, in: !loggedOut() });
        realClick(derr.btn);
        freshStart = true; armedKey = '';
        flash('↻ Smiles error, dismissed — starting over from the home page (try ' + errRetries + ' of 2).');
        return;
      }

      // A NEW Book always restarts from scratch. Whatever half-state this tab is in — an expired
      // results page, a passenger form from a previous attempt, a checkout — we go home and
      // search again rather than trying to resume from it. Resuming from wherever the tab
      // happened to be is where the half-filled, half-loaded failures all came from.
      if (target) {
        const key = targetKey(target);
        if (key !== armedKey) { armedKey = key; resetDriveState(); freshStart = !urlMatchesTarget(target); if (freshStart) flash('↻ Loading the search for this flight…'); }
      } else { armedKey = ''; freshStart = false; }

      // The SPA swaps pages without a document load, so readyState stays 'complete' throughout.
      // Give a route change a moment before touching anything on the new page.
      if (location.href !== lastHref) { lastHref = location.href; routeAt = Date.now(); }
      // No cap here either. This used to stop waiting after 25s even while the page was still
      // loading — the same guess, the same damage: act on a half-built page. If a load genuinely
      // never finishes, the watchdog restarts it; that is the safe way out, not pressing on.
      if (smilesLoading()) { flash('⏳ ' + (pageBusy() || 'page loading') + '…'); return; }

      // Smiles' own "no results" state: it offers "Nueva búsqueda" and lists no flights. That is
      // an ANSWER, not a page that has not finished — and reloading it forever is how a booking
      // sits there looking broken. Note the seat count: a flight with one award seat left simply
      // does not exist as a 2-passenger search, which is the usual reason for an empty result.
      if (target && urlMatchesTarget(target) && !qav('[id^="flight-SEGMENT"]').length
          && btnByText(/nueva b[uú]squeda/i) && settledFor() > 3000) {
        // An empty results page has TWO causes that look identical on screen: Smiles searched and
        // found nothing, or it never searched (the page loaded signed out). Guessing wrong either
        // abandons a bookable flight or reloads forever. The hook records every real search, so
        // ask it which happened instead of assuming.
        const ran = lastSearchRun();
        if (ran && ran.at > pageStartedAt && ran.count === 0) {
          // "No flights at all" is not a credible answer. Even with no seats for this party size,
          // the date's flights should still be listed — an entirely empty page is far more often
          // this site glitching than real. So restart through the home page once and search again;
          // only an empty result AFTER a clean restart is believed. Counted in sessionStorage
          // because the restart reloads this script.
          // A date Smiles cannot sell is a REAL reason for an empty page, and no amount of
          // restarting fixes it. Check that before blaming the site.
          const today = new Date();
          const todayStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
          if (target.date && target.date <= todayStr) {
            giveUp(target.date === todayStr
              ? 'the search date is today — Smiles does not sell same-day award seats'
              : 'the search date (' + target.date + ') has already passed');
            return;
          }
          // Otherwise restart. Smiles being briefly broken is far likelier than a date with no
          // flights whatsoever, so give it several clean runs before accepting the answer.
          const ek = 'ymEmpty:' + target.origin + target.destination + target.date + (target.adults || 1);
          let tries = 0;
          try { tries = parseInt(sessionStorage.getItem(ek) || '0', 10) || 0; } catch (e) {}
          if (tries < EMPTY_RETRIES) {
            try { sessionStorage.setItem(ek, String(tries + 1)); } catch (e) {}
            forceHome = true; forceSearch = true;
            logSession({ st: 'empty results — restart ' + (tries + 1) + '/' + EMPTY_RETRIES + ' via home', ok: true, in: true });
            flash('↻ No flights shown — restarting from the home page (' + (tries + 1) + ' of ' + EMPTY_RETRIES + ')…');
            return;
          }
          const who = (target.adults || 1) > 1 ? ' for ' + target.adults + ' passengers' : '';
          giveUp('no flights after ' + EMPTY_RETRIES + ' clean restarts' + who + ' — this looks real, or Smiles is having a bad day');
          return;
        }
        if (!ran || ran.at <= pageStartedAt) {
          // No search happened on this page at all. Run one rather than sit on an empty screen.
          if (!forceSearch) { forceSearch = true; flash('↻ This page never ran a search — running it now…'); }
        }
      }

      // A booking takes about a minute. Starting one with almost no session left just burns the
      // search and strands you mid-flow, so say it up front instead of failing at checkout.
      const leftMin = sessionLeftMin();
      if (target && leftMin != null && leftMin < 2) {
        flash('⛔ Session expires in ' + leftMin + ' min — log in again on this tab first, then press Book. Starting now would die mid-booking.');
        return;
      }

      // Not on the results for this flight yet? Run Smiles' OWN search here, in-page. We never
      // load a URL into this tab: that reboots the app and signs the account out. Searching
      // needs no account, so this runs BEFORE the logged-in check — being signed out should
      // never stop us getting the results on screen.
      // forceSearch means START OVER, so it has to win from ANY page. Previously the page checks
      // came first, so a forced search raised on the passenger page (session restored, search
      // expired, watchdog restart) was silently dropped and the booking sat there.
      if (target && (freshStart || forceSearch || (!onPax() && !onCheckout() && step !== 'tax' && !urlMatchesTarget(target)))) {
        const key = targetKey(target);
        if (searchState.key !== key) searchState = { key: key, phase: '', err: '', tries: 0 };
        const where = target.origin + '→' + target.destination + ' ' + (target.date || '');
        if (searchState.phase === 'running') { flash('🔎 Searching ' + where + ' in this tab…'); return; }
        if (searchState.tries >= 3) { giveUp('the search failed 3 times (' + (searchState.err || '?') + ')'); return; }
        searchState.phase = 'running'; searchState.tries++; forceSearch = false;
        flash('🔎 ' + (redoSearchBtn() ? 'Search expired — running a fresh one for ' : 'Searching ') + where + '…');
        searchInPage(target).then(err => {
          searchState.err = err || ''; searchState.phase = err ? 'failed' : 'done';
          if (!err) freshStart = false;          // clean slate reached; carry on normally
          if (err) flash('⚠ ' + err);
        }).catch(ex => { searchState.err = String(ex); searchState.phase = 'failed'; });
        return;
      }


      if (!step) { if (target) flash('⏳ Loading ' + target.origin + '→' + target.destination + ' ' + (target.date || '') + '…'); return; }
      if (step === 'fare') {
        if (!target) { flash('👉 Click the fare you want — I take over from there.'); return; }
        // selectFare never clicks the same fare twice (that would DESELECT it and throw away the
        // booking context), so retrying here is safe: each pass either confirms the selection
        // took or moves on to the next fare this account can actually use.
        if (Date.now() - lastFareTry < 5000) return;          // give React time to settle
        lastFareTry = Date.now(); fareTries++;
        const r = selectFare(target);
        if (r.done) flash('✓ ' + (r.note || 'Selected ' + (target.summary || 'your flight')) + ' — continuing…');
        else if (fareTries > 8) { giveUp(r.note || 'could not find ' + (target.summary || 'that flight') + ' among ' + r.flights + ' shown'); return; }
        else if (fareTries > 4) flash('⚠ ' + (r.note || 'still looking') + ' — click the fare yourself and I\'ll carry on.');
        else flash('Finding your flight — ' + r.flights + ' shown; ' + (r.note || '') + '…');
        return;
      }
      if (step === 'pax') {
        if (!field('#firstName')) { paxSeenAt = 0; return; }  // form not rendered yet
        if (!paxSeenAt) paxSeenAt = Date.now();

        // Smiles' own "Aviso" popup after we submitted = it took the request while the booking
        // wasn't loaded. Nothing was created, so dismiss it, wait longer, and try once more.
        if (/^pax/.test(actedStep) && avisoUp()) {
          if (paxSubmits >= 2) {
            sSet({ [DRIVE]: { on: false } });
            flash('⛔ Smiles rejected the submit twice. The form IS filled correctly — dismiss the notice and click Continuar yourself.');
            return;
          }
          const ok = btnByText(/^entend[ií]$/i);
          if (ok) realClick(ok);
          actedStep = ''; paxSeenAt = Date.now(); paxWaitMs = 12000;
          flash('↻ Smiles said the request was incomplete — letting the page settle and trying once more…');
          return;
        }

        // THE FORM RENDERS BEFORE THE BOOKING IS LOADED. Filling into that gap makes Smiles answer
        // "los parámetros de la solicitud no fueron informados". So NEVER fill while the page is
        // still working — wait for: (1) Smiles' own loading words gone, (2) the DOM settled,
        // (3) the price summary (Total / pasajero) actually present. Only then, hold 1.5s and fill.
        // If it is STILL not ready after a long wait, the page is genuinely slow/stuck — restart
        // from home rather than fill a half-loaded page (which is what caused the repeated error).
        // Fill ONLY when the page is genuinely, provably ready — never on a hunch that loading
        // 'probably stopped'. All of these must hold:
        const body = document.body.innerText || '';
        const summaryReady = /total/i.test(body) && /pasajer/i.test(body);   // the reservation loaded
        const netSeen = lastSmilesNetAt > 0;                                  // a Smiles call happened here
        const netIdleMs = netSeen ? (Date.now() - lastSmilesNetAt) : 0;       // ms since the last one
        const ready = summaryReady && netSeen && netIdleMs > 3000 && !pageBusy();
        if (!ready) {
          paxReadyAt = 0;
          flash('⏳ ' + (pageBusy() || (!netSeen ? 'loading the booking' : !summaryReady ? 'waiting for the reservation' : 'still loading') ) + '…');
          return;
        }
        if (!paxReadyAt) { paxReadyAt = Date.now(); }          // proven-ready — hold an extra settle
        const SETTLE = 3000;
        if (Date.now() - paxReadyAt < SETTLE) { flash('✓ Loaded — filling in ' + Math.ceil((SETTLE - (Date.now() - paxReadyAt)) / 1000) + 's…'); return; }
        const needPax = Math.max(1, paxBlocks().length);
        const missingPax = [];
        for (let i = 0; i < needPax; i++) { const px = paxAll[i]; if (!px || !px.first || !px.last) missingPax.push(i + 1); }
        if (missingPax.length) {
          flash('⚠ Need details for traveller ' + missingPax.join(' & ') + ' — fill them in the top-right panel (first + last name at minimum).');
          const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#f59e0b';
          return;
        }
        const p = document.getElementById('__ymBook'); if (p) p.style.borderColor = '#2b6cff';

        // ONE TRAVELLER AT A TIME. Smiles shows "Adulto 1", "Adulto 2" and expands only one; each
        // has its OWN Continuar (passengersContinueButton-N), and the final "Confirmar y
        // continuar" stays disabled until every traveller is done. Filling the visible block and
        // pressing the final button — which is what used to happen — clicks something disabled and
        // then waits forever for a checkout that cannot come.
        const firsts = allPaxFirstNames();
        const need = firsts.findIndex(el => !String(el.value || '').trim());

        if (need >= 0) {
          const d = paxAll[need];
          if (!d || !d.first || !d.last) {
            flash('⚠ Need details for traveller ' + (need + 1) + ' — add them in the console under Travellers (first + last name at minimum).');
            const bp = document.getElementById('__ymBook'); if (bp) bp.style.borderColor = '#f59e0b';
            return;
          }
          // Collapsed? A traveller's section is NOT opened by clicking its "Adulto N" header.
          // Smiles reveals the next traveller when the PREVIOUS one's Continuar is pressed. That
          // only showed up on a booking where traveller 1 was already filled: the fill step was
          // skipped, and with it the Continuar that advances the form, so traveller 2 stayed shut
          // however many times the header was clicked.
          if (!vis(firsts[need])) {
            if (Date.now() - lastAdvance < 2500) return;
            lastAdvance = Date.now();
            if (need > 0) {
              if (!ensureNotSaving()) {
                sSet({ [DRIVE]: { on: false } });
                flash('⛔ Could NOT confirm "Guardar pasajero" is unchecked — stopped so no one is saved to the account by accident.');
                return;
              }
              const prev = byId('passengersContinueButton-' + (need - 1));
              if (prev && !prev.disabled) {
                realClick(prev);
                flash('✓ Traveller ' + need + ' confirmed — opening traveller ' + (need + 1) + '…');
                return;
              }
            }
            // Fallback for anything that does not follow that pattern.
            const hdr = qav('div, h2, h3, span, button')
              .filter(e => e.children.length < 3)
              .find(e => new RegExp('^\\s*adulto\\s*' + (need + 1) + '\\s*$', 'i').test(e.innerText || ''));
            if (hdr) { realClick(hdr); flash('👤 Opening traveller ' + (need + 1) + '…'); }
            else flash('⏳ Waiting for traveller ' + (need + 1) + ' to open…');
            return;
          }
          if (actedStep === 'pax' + need) return;              // already filling this one
          actedStep = 'pax' + need;
          fillPassenger(blockOf(firsts[need]), d, need + 1).then((bad) => {
            // Never submit a form we know is incomplete — that is what produces Smiles' useless
            // "los parámetros … no fueron informados" popup. Name the field instead.
            if (bad.length) {
              sSet({ [DRIVE]: { on: false } });
              flash('⛔ Stopped before submitting — Smiles would not accept: ' + bad.join(', ') + '. Fill ' + (bad.length > 1 ? 'those' : 'that') + ' by hand and click Continuar.');
              return;
            }
            setTimeout(() => {
              if (!ensureNotSaving()) {   // couldn't guarantee "Guardar pasajero" is OFF → stop, don't advance
                sSet({ [DRIVE]: { on: false } });
                flash('⛔ Filled, but I could NOT confirm "Guardar pasajero" is unchecked — stopped so no one is saved by accident. Uncheck it + click Continuar yourself.');
                return;
              }
              const cont = byId('passengersContinueButton-' + need)
                || qav('button').find(b => /^\s*continuar\s*$/i.test(b.innerText || ''));
              if (cont && !cont.disabled) {
                realClick(cont);
                actedStep = '';                                 // free the next traveller
                flash('✓ Traveller ' + (need + 1) + ' of ' + firsts.length + ' saved' + (need + 1 < firsts.length ? ' — opening the next…' : '…'));
              } else {
                flash('⏳ Waiting for traveller ' + (need + 1) + '\'s Continuar to become available…');
                actedStep = '';
              }
            }, 1800);
          }).catch((ex) => {
            sSet({ [DRIVE]: { on: false } });
            flash('⛔ Stopped while filling traveller ' + (need + 1) + ': ' + String(ex).slice(0, 80));
          });
          return;
        }

        // Every traveller has a name: now the final submit is legitimate.
        if (actedStep === 'paxAll') return;
        const fin = byId('passengersConfirmButton') || btnByText(/confirmar y continuar/i);
        if (!fin || fin.disabled || /disabled|not-allowed/i.test(fin.className || '')) {
          flash('⏳ Waiting for "Confirmar y continuar" to become available…');
          return;
        }
        actedStep = 'paxAll';
        paxSubmits++;
        realClick(fin);
        flash('✓ All ' + firsts.length + ' traveller' + (firsts.length > 1 ? 's' : '') + ' submitted — waiting for checkout…');
        return;
      }
      if (step === 'tax') {
        // Patient watcher: agree terms (idempotent) and click Continuar the moment it's enabled.
        // Don't touch the fare — you pick 11.400/13.000 (the one flaky click); I do the rest.
        agreeTerms();
        if (Date.now() - lastAdvance < 2500) return;         // just clicked — let the page move
        const r = clickContinue();
        if (r === 'clicked') { lastAdvance = Date.now(); flash('✓ Continuing…'); return; }
        flash(r === 'disabled'
          ? '👉 Pick the millas fare (11.400 / 13.000) — terms done; I continue the instant it\'s selected.'
          : 'Waiting for the fare page…');
        return;
      }
    });
  }

  // ---------------- UI ----------------
  function setDriveBtn(on) {
    if (!driveBtn) return;
    driveBtn.textContent = on ? '■ Stop auto-drive' : '▶ Auto-book to checkout';
    driveBtn.style.background = on ? '#dc2626' : '#4f46e5';
  }
  // ---- console-on-the-page --------------------------------------------------------------------
  // The operator wanted ONE place. A web page cannot hold browser tabs, so instead of the console
  // opening a Smiles tab, the console is painted OVER the Smiles tab as an iframe (console.html is
  // web-accessible for smiles.com.ar). Result: one tab shows the YM console; the real Smiles page
  // sits underneath, revealed only through the captcha hole when a tick is needed.
  let consoleOpen = false;
  try { consoleOpen = localStorage.getItem('ymConsoleOpen') === '1'; } catch (e) {}

  function setConsole(open) {
    consoleOpen = open;
    try { localStorage.setItem('ymConsoleOpen', open ? '1' : '0'); } catch (e) {}
    manageConsole();
  }
  function manageConsole() {
    // a captcha hole is showing -> the console iframe must not cover the checkbox
    const holeUp = !!document.getElementById('__ymCapT');
    let f = document.getElementById('__ymConsoleFrame');
    let btn = document.getElementById('__ymConsoleBtn');
    if (!btn) {
      btn = document.createElement('button'); btn.id = '__ymConsoleBtn';
      btn.style.cssText = 'position:fixed;bottom:12px;left:12px;z-index:2147483625;cursor:pointer;border:0;border-radius:9px;padding:9px 13px;font:700 12px system-ui;background:#4f46e5;color:#fff;box-shadow:0 6px 20px rgba(0,0,0,.4)';
      btn.addEventListener('click', () => setConsole(!consoleOpen));
      document.body.appendChild(btn);
    }
    btn.textContent = consoleOpen ? '✕ close console' : '▣ YM console';
    btn.style.display = holeUp ? 'none' : '';

    if (consoleOpen && !holeUp) {
      if (!f) {
        f = document.createElement('iframe'); f.id = '__ymConsoleFrame';
        f.src = chrome.runtime.getURL('console.html');
        f.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;border:0;z-index:2147483620;background:#0b1220';
        document.body.appendChild(f);
      }
      f.style.display = '';
    } else if (f) {
      f.style.display = 'none';
    }
  }

  function buildDriveBar() {
    if (document.getElementById('__ymDrive')) return;
    const bar = document.createElement('div'); bar.id = '__ymDrive';
    bar.style.cssText = 'position:fixed;bottom:12px;right:12px;z-index:2147483646;background:#0b1220;color:#e6f0ff;font:12px system-ui,sans-serif;border:1px solid #4f46e5;border-radius:11px;padding:10px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
    bar.innerHTML = '<div style="font-weight:700;margin-bottom:6px">YM · auto-drive <span style="opacity:.55;font-weight:400">v' + VER + '</span></div><div style="font-size:11px;opacity:.8;margin-bottom:7px">Press Book in the processor — this tab searches, picks the flight, and stops at checkout.</div>';
    driveBtn = document.createElement('button');
    driveBtn.style.cssText = 'width:100%;cursor:pointer;border:0;border-radius:7px;padding:8px;color:#fff;font:13px system-ui;font-weight:700;background:#4f46e5';
    driveBtn.addEventListener('click', () => { sGet(DRIVE, s => { const on = s && s[DRIVE] && s[DRIVE].on; if (on) stopDrive(); else startDrive(); }); });
    bar.appendChild(driveBtn);
    driveStatusEl = document.createElement('div'); driveStatusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; bar.appendChild(driveStatusEl);
    sessionEl = document.createElement('div'); sessionEl.style.cssText = 'margin-top:5px;font-size:11px;opacity:.75'; bar.appendChild(sessionEl);
    const acctBtn = document.createElement('button');
    acctBtn.textContent = '⚙ Accounts / card details';
    acctBtn.style.cssText = 'width:100%;margin-top:7px;cursor:pointer;border:1px solid #2f6b45;border-radius:7px;padding:6px;color:#a7f3d0;background:transparent;font:11px system-ui';
    acctBtn.addEventListener('click', () => {
      showAccounts = !showAccounts;
      if (!showAccounts) { const b = document.getElementById('__ymLogin'); if (b) b.remove(); }
    });
    bar.appendChild(acctBtn);

    const consoleBtn = document.createElement('button');
    consoleBtn.textContent = '📋 Booking console';
    consoleBtn.style.cssText = 'width:100%;margin-top:7px;cursor:pointer;border:1px solid #33507f;border-radius:7px;padding:6px;color:#cfe3ff;background:transparent;font:11px system-ui';
    consoleBtn.addEventListener('click', () => { try { chrome.runtime.sendMessage({ type: 'openConsole', win: true }); } catch (e) {} });
    bar.appendChild(consoleBtn);

    const diagBtn = document.createElement('button');
    diagBtn.textContent = '🔎 Copy page info';
    diagBtn.style.cssText = 'width:100%;margin-top:7px;cursor:pointer;border:1px solid #33507f;border-radius:7px;padding:6px;color:#cfe3ff;background:transparent;font:11px system-ui';
    diagBtn.addEventListener('click', () => {
      // Fetch the real frame URLs first (only the browser can see them), then dump.
      try {
        chrome.runtime.sendMessage({ type: 'frames' }, (r) => {
          void chrome.runtime.lastError;
          lastFrames = (r && r.ok && r.frames) ? r.frames : [];
          copyDiag();
        });
      } catch (e) { copyDiag(); }
    });
    bar.appendChild(diagBtn);
    document.body.appendChild(bar);
  }


  // ---------------- saved accounts: fill the login, human does the captcha ----------------
  // Fills #dni and #password so signing in is one captcha tick and one click. The captcha is
  // deliberately left alone: it is the site's anti-automation control, and defeating it across a
  // pool of accounts holding bought miles is how the pool gets lost. Credentials live in this
  // browser profile's extension storage, are never transmitted, and never enter the dump.

  // Press "Entrar" once YOU have solved the captcha, so signing in is a single click on the
  // checkbox and nothing else. reCAPTCHA drops its token into #g-recaptcha-response only after a
  // human passes it, so waiting for that token adds no bypass whatsoever — the control is still
  // satisfied by you. We only submit a form we filled and that has a real token in it.
  let loginSubmittedAt = 0, loginSeenAt = 0;
  function loginTick() {
    const f = loginFields();
    if (!f) { loginSubmittedAt = 0; loginSeenAt = 0; return; }
    if (Date.now() - loginSubmittedAt < 15000) return;          // already pressed; let it work
    if (!(f.dni.value || '').trim() || !(f.pass.value || '')) return;   // nothing to submit yet
    const tok = [...document.querySelectorAll('#g-recaptcha-response, textarea[name="g-recaptcha-response"]')]
      .find(t => (t.value || '').length > 20);
    if (!tok) return;                                            // captcha not solved — wait for you
    if (!loginSeenAt) { loginSeenAt = Date.now(); return; }      // let the modal finish rendering
    if (Date.now() - loginSeenAt < 1500) return;
    const form = f.pass.closest('form');
    const btn = (form && [...form.querySelectorAll('button, input[type=submit]')].filter(vis)
      .find(b => /entrar|inici[aá]r?\s*sesi[oó]n/i.test(b.innerText || b.value || ''))) || btnByText(/^\s*entrar\s*$/i);
    if (!btn) return;
    loginSubmittedAt = Date.now();
    const st = document.getElementById('__ymLoginStatus');
    if (st) { st.textContent = '✓ Captcha solved — signing in…'; st.style.color = '#4ade80'; }
    realClick(btn);
  }


  // ---------------- checkout: pick the card, type the PIN on the keypad ----------------
  // Measured from the live page: the payment methods are divs (no real radios) that gain a
  // "checked" class; the Smiles password box is readOnly, so it can ONLY be filled by clicking
  // the on-screen keypad, whose keys are divs classed n0..n9; Confirmar pago is .canje-button.
  //
  // The card NUMBER is unreachable by design — Yuno renders it in a cross-origin iframe, and
  // Chrome's own autofill dropdown is browser UI, not page content. A card saved in the Smiles
  // account shows up as its own row here, and that we can select by name.
  let ckAt = 0, ckConfirmAt = 0;
  function keypadKeys() {
    const k = {};
    qav('div, span, button, li').forEach(d => {
      const c = (typeof d.className === 'string' ? d.className : '').trim();
      if (/^n[0-9]$/.test(c) && (d.innerText || '').trim() === c[1]) k[c[1]] = d;
    });
    return k;
  }
  function payMethodRow(name) {
    const rows = qav('.yuno-payment-list__radio, .yuno-payment-list__payment-method');
    if (!name) return rows[0] || null;
    return rows.find(r => new RegExp(name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(r.innerText || '')) || rows[0] || null;
  }
  const payMethodChosen = () => qav('.yuno-payment-list__radio').some(r => /(^|\s)checked(\s|$)/.test((r.className || '').toString()));

  // Order on the real page, from the operator: choose the card type, type the Smiles PIN on the
  // keypad, tick the captcha, press CONFIRMAR PAGO — and only THEN does the card form appear,
  // where PAGAR actually takes the money.
  //
  // So Confirmar pago is not the purchase, it just advances to the card form: same category as
  // the login's Entrar, and safe to press once a human has passed the captcha. Pagar is the
  // charge, and that one we leave alone.
  // Yuno renders the card number / expiry / CVC into iframes it creates WITHOUT a src (the dump
  // shows their src empty), which makes them about:blank and therefore same-origin — so this
  // content script can reach into them. Anything genuinely cross-origin simply throws and is
  // skipped, so this degrades to "fill what we can" rather than breaking.
  function reachableDocs() {
    const out = [document];
    [...document.querySelectorAll('iframe')].forEach(f => {
      try { const d = f.contentDocument; if (d && d.body) out.push(d); } catch (e) {}   // cross-origin: skip
    });
    return out;
  }
  const CARD_PAT = {
    number: /cc-?number|card.?number|cardnumber|numero.*tarjeta|n[uú]mero de tarjeta/i,
    exp: /cc-?exp|expir|vencim|mm\s*\/?\s*(aa|yy)/i,
    cvv: /cc-?csc|cvc|cvv|security.?code|c[oó]digo.*segur/i
  };
  function findCardField(kind) {
    const pat = CARD_PAT[kind];
    for (const doc of reachableDocs()) {
      let els = [];
      try { els = [...doc.querySelectorAll('input')].filter(e => e.type !== 'hidden' && vis(e)); } catch (e) { continue; }
      const hit = els.find(e => {
        const sig = [e.name, e.id, e.placeholder, e.getAttribute('autocomplete'), e.getAttribute('aria-label'), e.className].join(' ');
        return pat.test(sig);
      });
      if (hit) return hit;
    }
    return null;
  }

  let cardFilledAt = 0;
  function checkoutTick(acct) {
    if (pageBusy()) return;

    // ---- phase 3: the card form is up. Fill what we can; Pagar is yours. ----
    const holder = qav('input[name="cardHolderName"]')[0];
    if (holder) {
      // ONLY what was entered as card details. Falling back to the account label and the
      // passenger's email put the wrong name and address on a payment form — payment details are
      // never something to infer.
      if (!(holder.value || '').trim() && acct && acct.cardHolder) setVal(holder, acct.cardHolder);
      const mail = qav('input[name="email"]')[0];
      if (mail && !(mail.value || '').trim() && acct && acct.cardEmail) setVal(mail, acct.cardEmail);

      // The card itself, if it was saved for this account. Filled once per checkout, never
      // re-typed on every tick, and PAGAR IS NEVER PRESSED — the charge stays the operator's.
      if (acct && acct.cardNumber && Date.now() - cardFilledAt > 15000) {
        const num = findCardField('number'), exp = findCardField('exp'), cvv = findCardField('cvv');
        const got = [];
        if (num && !(num.value || '').trim()) { setVal(num, acct.cardNumber); got.push('number'); }
        if (exp && acct.cardExp && !(exp.value || '').trim()) { setVal(exp, acct.cardExp); got.push('expiry'); }
        if (cvv && acct.cardCvv && !(cvv.value || '').trim()) { setVal(cvv, acct.cardCvv); got.push('CVC'); }
        if (got.length) {
          cardFilledAt = Date.now();
          flash('💳 Card filled (' + got.join(', ') + ') — check it, then press Pagar. That button is the charge, so it stays yours.');
          return;
        }
        if (!num) { flash('💳 Card form ready — I could not reach the card number field (Yuno keeps it isolated). Enter it, then press Pagar.'); return; }
      }
      flash('💳 Card form ready — enter the card, then press Pagar. That button is the actual charge, so it stays yours.');
      return;
    }

    // ---- phase 0: choose "Tarjetas" over "Mercado Pago" ----
    // There are TWO levels of choice here and we were only handling the second. The Yuno card
    // list does not exist until "Tarjetas" is picked at the top, which is why it sat there doing
    // nothing until the operator pressed it by hand.
    const pass = qav('input[type=password]')[0];
    if (!qav('.yuno-payment-list, .yuno-payment-list__radio, .yuno-payment-list__payment-method').length) {
      if (Date.now() - ckAt < 2500) return;
      ckAt = Date.now();
      const tab = qav('div, button, label, li, a')
        .filter(e => e.children.length < 3)
        .find(e => /^\s*tarjetas?\s*$/i.test(e.innerText || ''));
      if (tab) { realClick(tab); flash('💳 Choosing card payment…'); }
      else flash('👉 Pick "Tarjetas" — I could not find that button.');
      return;
    }

    // ---- phase 1: choose the card row ----
    if (!payMethodChosen()) {
      if (Date.now() - ckAt < 2500) return;
      ckAt = Date.now();
      const row = payMethodRow(acct && acct.cardName);
      if (row) { realClick(row); flash('💳 Selecting ' + ((row.innerText || 'the card').replace(/\s+/g, ' ').trim().slice(0, 28)) + '…'); }
      return;
    }

    // ---- phase 2a: tap the PIN in on the keypad (the box is readOnly — no other way) ----
    const pin = (acct && acct.pin || '').replace(/[^0-9]/g, '');
    if (pass && !(pass.value || '').length && pin) {
      if (Date.now() - ckAt < 2000) return;
      ckAt = Date.now();
      const keys = keypadKeys();
      if (Object.keys(keys).length < 10) { flash('💳 Card selected — waiting for the keypad…'); return; }
      let i = 0;
      const tap = () => {
        if (i >= pin.length) { flash('✅ PIN in — tick the captcha and I press Confirmar pago.'); return; }
        const k = keys[pin[i++]];
        if (k) realClick(k);
        setTimeout(tap, 260);
      };
      flash('💳 Entering the checkout PIN…');
      tap();
      return;
    }
    if (pass && !(pass.value || '').length) { flash('👉 Enter the Smiles PIN on the keypad (save it in the accounts panel and I will do it next time).'); return; }

    // ---- phase 2b: captcha solved? then press Confirmar pago ----
    const tok = [...document.querySelectorAll('#g-recaptcha-response, textarea[name="g-recaptcha-response"]')]
      .find(t => (t.value || '').length > 20);
    if (!tok) { flash('👉 Tick the captcha — then I press Confirmar pago and the card form comes up.'); return; }
    if (Date.now() - ckConfirmAt < 20000) return;
    const btn = btnByText(/confirmar pago/i);
    if (!btn || btn.disabled) { flash('⏳ Waiting for Confirmar pago to become available…'); return; }
    ckConfirmAt = Date.now();
    logSession({ st: 'checkout: pressing Confirmar pago', ok: true, in: true });
    flash('✓ Captcha solved — pressing Confirmar pago…');
    realClick(btn);
  }

  function buildLoginPanel() {
    if (document.getElementById('__ymLogin')) return;
    sGet(ACCTS, (st) => {
      if (document.getElementById('__ymLogin')) return;
      const accts = (st && st[ACCTS]) || [];
      const esc = (x) => String(x || '').replace(/"/g, '&quot;').replace(/</g, '&lt;');
      const F = 'width:100%;margin:3px 0;padding:6px 7px;border:1px solid #2f6b45;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box';
      const box = document.createElement('div');
      box.id = '__ymLogin';
      box.style.cssText = 'position:fixed;top:90px;right:12px;z-index:2147483647;background:#0b1220;color:#e6f0ff;font:12px system-ui,-apple-system,sans-serif;border:1px solid #16a34a;border-radius:11px;padding:11px;width:250px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
      box.innerHTML =
        '<div style="font-weight:700;margin-bottom:6px">YM · accounts <span style="opacity:.55;font-weight:400">' + (accts.length ? accts.length + ' saved' : 'none saved yet') + '</span></div>' +
        '<select id="ymacct_pick" style="' + F + '"><option value="">— pick a saved account —</option>' +
        accts.map((a, i) => '<option value="' + i + '">' + esc(a.name || a.dni) + '</option>').join('') + '</select>' +
        '<div style="font-size:11px;opacity:.7;margin:8px 0 2px">Add / update an account</div>' +
        '<input id="ymacct_name" placeholder="Account name (e.g. Antonella)" style="' + F + '">' +
        '<input id="ymacct_dni" placeholder="Login — Smiles number or DNI" style="' + F + '">' +
        '<input id="ymacct_pass" type="password" placeholder="Password" style="' + F + '">' +
        '<input id="ymacct_pin" placeholder="Checkout PIN (the keypad digits)" style="' + F + '">' +
        '<input id="ymacct_card" placeholder="Saved card name at checkout (optional)" style="' + F + '">' +
        '<input id="ymacct_holder" placeholder="Card holder name (as on the card)" style="' + F + '">' +
        '<input id="ymacct_cardnum" type="password" placeholder="Card number" style="' + F + '">' +
        '<div style="display:flex;gap:5px">' +
        '<input id="ymacct_cardexp" placeholder="MM/AA" style="' + F + 'width:76px">' +
        '<input id="ymacct_cardcvv" type="password" placeholder="CVC" style="' + F + 'width:70px">' +
        '</div>' +
        '<input id="ymacct_cardmail" placeholder="Email for the payment receipt" style="' + F + '">';
      const status = document.createElement('div');
      status.id = '__ymLoginStatus';
      status.style.cssText = 'margin-top:8px;font-size:11px;line-height:1.45;font-weight:600';
      const fill = (a) => {
        if (!a) return;
        const f = loginFields();
        if (!f) { status.textContent = 'Login form not on screen — press Iniciá sesión first.'; return; }
        setVal(f.dni, a.dni || '');
        setVal(f.pass, a.pass || '');
        status.textContent = 'Filled ' + (a.name || a.dni) + ' — just tick the captcha. I press Entrar and the booking resumes on its own.';
      };
      const btn = document.createElement('button');
      btn.textContent = 'Save this account';
      btn.style.cssText = 'width:100%;margin-top:8px;cursor:pointer;border:0;border-radius:7px;padding:8px;background:#16a34a;color:#fff;font:12px system-ui;font-weight:700';
      btn.addEventListener('click', () => {
        const g = (id) => (document.getElementById(id) || {}).value || '';
        const a = { name: g('ymacct_name'), dni: g('ymacct_dni'), pass: g('ymacct_pass'), pin: g('ymacct_pin'), cardName: g('ymacct_card'), cardHolder: g('ymacct_holder'), cardEmail: g('ymacct_cardmail'), cardNumber: g('ymacct_cardnum'), cardExp: g('ymacct_cardexp'), cardCvv: g('ymacct_cardcvv') };
        sGet(ACCTS, (s2) => {
          const list = (s2 && s2[ACCTS]) || [];
          // The password box is deliberately never re-populated when an account is picked, so an
          // empty box on re-save means "unchanged", NOT "erase it" — adding card details to an
          // existing account must not silently wipe its login.
          if (!a.pass && a.dni) { const prev = list.find(x => x.dni === a.dni); if (prev && prev.pass) a.pass = prev.pass; }
          // Flag the empty box itself — a line of text under the button was being missed, and the
          // panel then looked like it was doing nothing at all.
          const missing = [];
          if (!a.dni) missing.push('ymacct_dni');
          if (!a.pass) missing.push('ymacct_pass');
          ['ymacct_dni', 'ymacct_pass'].forEach(id => { const el = document.getElementById(id); if (el) el.style.border = '1px solid ' + (missing.indexOf(id) >= 0 ? '#ef4444' : '#2f6b45'); });
          if (missing.length) {
            status.textContent = '⚠ Not saved — fill in the ' + (missing.length > 1 ? 'login and password' : (missing[0] === 'ymacct_pass' ? 'password' : 'login')) + ' (highlighted in red).';
            status.style.color = '#f87171';
            return;
          }
          const at = list.findIndex(x => x.dni === a.dni);
          if (at >= 0) list[at] = a; else list.push(a);
          sSet({ [ACCTS]: list }, () => {
            sSet({ [ACTIVE]: a.dni }, () => {
              fill(a);
              // Rebuild so the dropdown and the "N saved" count refresh — seeing the account
              // listed is the confirmation; a line of small text was too easy to miss.
              const old = document.getElementById('__ymLogin');
              if (old) old.remove();
              buildLoginPanel();
              setTimeout(() => {
                const st2 = document.getElementById('__ymLoginStatus');
                if (st2) { st2.textContent = '✓ Saved "' + (a.name || a.dni) + '" — ' + list.length + ' account' + (list.length === 1 ? '' : 's') + ' stored. Tick the captcha and press Entrar.'; st2.style.color = '#4ade80'; }
              }, 120);
            });
          });
        });
      });
      box.appendChild(btn);
      box.appendChild(status);
      document.body.appendChild(box);
      const pick = document.getElementById('ymacct_pick');
      if (pick) pick.addEventListener('change', () => { const a = accts[+pick.value]; if (a) { sSet({ [ACTIVE]: a.dni }); fill(a); } });
      // Fill by ourselves: the account this booking is for, else the only one saved. This is the
      // point of the whole panel — arriving here mid-booking should cost you a captcha, nothing more.
      const put = (id, v) => { const e = document.getElementById(id); if (e && v) e.value = v; };
      sGet(ACTIVE, (s3) => {
        const want = s3 && s3[ACTIVE];
        const a = (want && accts.find(x => x.dni === want)) || (accts.length === 1 ? accts[0] : null);
        if (!a) return;
        if (pick) pick.value = String(accts.indexOf(a));
        put('ymacct_name', a.name); put('ymacct_dni', a.dni); put('ymacct_pin', a.pin); put('ymacct_card', a.cardName); put('ymacct_holder', a.cardHolder); put('ymacct_cardmail', a.cardEmail);
        put('ymacct_cardnum', a.cardNumber); put('ymacct_cardexp', a.cardExp); put('ymacct_cardcvv', a.cardCvv);
        fill(a);
      });
    });
  }

  // The panel edits ONE traveller at a time; the numbered tabs switch between them. Everything
  // typed is kept per traveller in paxList and written straight to storage, so a second traveller
  // is just a second tab rather than a second panel.
  let paxList = [{}], curPax = 0;
  const savePax = () => sSet({ [PAXL]: paxList, [KEY]: paxList[0] || {} });
  function loadPax() {
    const d = paxList[curPax] || {};
    FIELDS.forEach(k => { const el = document.getElementById('ymb_' + k); if (el) el.value = d[k] || (k === 'ccode' ? '54' : ''); });
    const natEl = document.getElementById('ymb_nationality'); if (natEl) natEl.value = d.nationality || '';
    document.querySelectorAll('input[name="ymb_gender"]').forEach(r => { r.checked = (r.value === (d.gender === 'F' ? 'F' : 'M')); });
    renderPaxTabs();
  }
  function renderPaxTabs() {
    const bar = document.getElementById('__ymPaxTabs');
    if (!bar) return;
    const onPage = paxBlocks().length;                       // what this booking actually needs
    const n = Math.max(1, paxList.length, onPage);
    while (paxList.length < n) paxList.push({});
    let html = '';
    for (let i = 0; i < n; i++) {
      const on = i === curPax, has = paxList[i] && paxList[i].first;
      html += '<button data-pax="' + i + '" style="cursor:pointer;border:1px solid ' + (on ? '#2b6cff' : '#33507f') + ';background:' + (on ? '#2b6cff' : 'transparent') + ';color:#e6f0ff;border-radius:6px;padding:3px 9px;font:700 11px system-ui;margin-right:4px">' + (i + 1) + (has ? '' : ' •') + '</button>';
    }
    html += '<button data-pax="add" title="add a traveller" style="cursor:pointer;border:1px dashed #33507f;background:transparent;color:#9db4d8;border-radius:6px;padding:3px 8px;font:700 11px system-ui">+</button>';
    if (onPage > 1) html += '<div style="font-size:10px;color:#9db4d8;margin-top:4px">This booking needs ' + onPage + ' travellers</div>';
    bar.innerHTML = html;
    bar.querySelectorAll('[data-pax]').forEach(b => b.addEventListener('click', () => {
      paxList[curPax] = collect();                            // keep what is on screen
      const v = b.getAttribute('data-pax');
      if (v === 'add') { paxList.push({}); curPax = paxList.length - 1; }
      else curPax = +v;
      savePax(); loadPax();
    }));
  }

  function buildPanel() {
    if (document.getElementById('__ymBook')) return;
    sGet([KEY, PAXL], (s) => {
      if (document.getElementById('__ymBook')) return;
      const stored = (s && s[PAXL]) || [];
      const first = (s && s[KEY]) || {};
      paxList = stored.length ? stored.slice() : [first];
      if (!paxList[0] || !paxList[0].first) paxList[0] = first;
      curPax = 0;
      const d = paxList[0] || {};
      const box = document.createElement('div'); box.id = '__ymBook';
      box.style.cssText = 'position:fixed;top:74px;right:12px;z-index:2147483647;background:#0b1220;color:#e6f0ff;font:12px system-ui,-apple-system,sans-serif;border:1px solid #2b6cff;border-radius:11px;padding:11px;width:236px;box-shadow:0 8px 24px rgba(0,0,0,.5)';
      const v = (x) => (x || '').replace(/"/g, '&quot;');
      const fld = (id, ph, val, w) => `<input id="ymb_${id}" placeholder="${ph}" value="${v(val)}" style="width:${w || '100%'};margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box">`;
      box.innerHTML =
        '<div style="font-weight:700;margin-bottom:6px">YM · fill passenger</div>' +
        '<div id="__ymPaxTabs" style="margin-bottom:7px"></div>' +
        fld('first', 'First name', d.first) + fld('last', 'Last name', d.last) +
        '<select id="ymb_nationality" style="width:100%;margin:3px 0;padding:6px 7px;border:1px solid #33507f;border-radius:6px;background:#0f1830;color:#e6f0ff;font:12px system-ui;box-sizing:border-box"><option value="">Nationality…</option></select>' +
        `<div style="margin:4px 0">Gender &nbsp;<label><input type="radio" name="ymb_gender" value="M" ${d.gender !== 'F' ? 'checked' : ''}> M</label> &nbsp;<label><input type="radio" name="ymb_gender" value="F" ${d.gender === 'F' ? 'checked' : ''}> F</label></div>` +
        fld('dob', 'DOB  DD/MM/YYYY', d.dob) + fld('passport', 'Passport #', d.passport) + fld('passportExp', 'Passport exp  DD/MM/YYYY', d.passportExp) +
        fld('email', 'Email', d.email) +
        `<div style="display:flex;gap:5px">${fld('ccode', 'Cód', d.ccode || '54', '46px')}${fld('area', 'Area', d.area, '58px')}${fld('phone', 'Phone', d.phone, 'auto')}</div>`;
      const btn = document.createElement('button');
      btn.textContent = 'Fill Smiles form';
      btn.style.cssText = 'width:100%;margin-top:8px;cursor:pointer;border:0;border-radius:7px;padding:8px;background:#16a34a;color:#fff;font:13px system-ui;font-weight:700';
      btn.addEventListener('click', saveAndFill);
      box.appendChild(btn);
      statusEl = document.createElement('div'); statusEl.style.cssText = 'margin-top:7px;opacity:.85;font-size:11px'; box.appendChild(statusEl);
      document.body.appendChild(box);
      const autosave = () => { paxList[curPax] = collect(); savePax(); };   // per traveller; local only, NOT saved to Smiles
      box.querySelectorAll('input, select').forEach(el => { el.addEventListener('input', autosave); el.addEventListener('change', autosave); });
      const smilesNat = q('select[name="nationality"]'), panelNat = document.getElementById('ymb_nationality');
      if (smilesNat && panelNat && smilesNat.options.length) {
        panelNat.innerHTML = '<option value="">Nationality…</option>' + [...smilesNat.options].filter(o => o.value).map(o => `<option value="${(o.value || '').replace(/"/g, '&quot;')}">${(o.text || '').replace(/</g, '&lt;')}</option>`).join('');
        if (d.nationality) panelNat.value = d.nationality;
      }
      renderPaxTabs();
    });
  }
  function collect() {
    const data = {}; FIELDS.forEach(k => { const el = document.getElementById('ymb_' + k); if (el) data[k] = el.value; });
    const gr = document.querySelector('input[name="ymb_gender"]:checked'); data.gender = gr ? gr.value : 'M';
    const natEl = document.getElementById('ymb_nationality'); data.nationality = natEl ? natEl.value : '';
    return data;
  }
  function saveAndFill() { paxList[curPax] = collect(); savePax(); fillForm(paxList); }

  // ---------------- session keepalive + timeout probe ----------------
  // Smiles drops the session after roughly an hour. Whether that clock RESETS on use (idle
  // timeout) or runs regardless (hard expiry) decides whether accounts can be kept warm or need
  // a captcha login every hour — so we poke the session every few minutes and log what came
  // back. The log is the evidence for which of the two it is.
  const SESSLOG = 'ymSessionLog';
  // Every Smiles tab writes to one shared log — including the throwaway tabs the background
  // search opens — so an entry is ambiguous without knowing which tab it came from.
  // sessionStorage is per-tab AND survives a reload, so it gives each tab a stable short name.
  let TABID = '?';
  try {
    TABID = sessionStorage.getItem('__ymTab') || Math.random().toString(36).slice(2, 6);
    sessionStorage.setItem('__ymTab', TABID);
  } catch (e) {}
  let lastKeepAlive = 0, keepAliveWaiting = false;
  let sessionLogCache = [];    // mirrored in memory so the diagnostic dump can read it synchronously
  sGet(SESSLOG, (s) => { sessionLogCache = (s && s[SESSLOG]) || []; });
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || !e.data.__ymKeepAliveRes) return;
    keepAliveWaiting = false;
    logSession({ st: e.data.__ymKeepAliveRes.status, ok: !!e.data.__ymKeepAliveRes.ok, in: !loggedOut() });
  });
  // One log, written by EVERY Smiles tab — including the short-lived tabs the background search
  // opens. Two problems that made the log lie to us: writes are read-modify-write, so entries
  // logged close together overwrote each other (that is why PAGE-LOAD entries went missing),
  // and a search tab's entries are indistinguishable from your booking tab's. So: writes are
  // queued one at a time, and every entry is stamped with its tab.
  let logChain = Promise.resolve();
  function logSession(entry) {
    if (!alive()) return;
    entry.t = Date.now();
    entry.tab = TABID;
    logChain = logChain.then(() => new Promise((done) => {
      sGet(SESSLOG, (s) => {
        let arr = (s && s[SESSLOG]) || [];
        arr.push(entry);
        if (arr.length > 80) arr = arr.slice(-80);
        sessionLogCache = arr;
        sSet({ [SESSLOG]: arr }, () => done());
      });
    })).catch(() => {});
  }
  function keepAliveTick() {
    if (!onSmilesApp()) return;
    if (Date.now() - lastKeepAlive < 4 * 60 * 1000) return;   // every 4 min ≈ 15 calls/hour
    lastKeepAlive = Date.now();
    // The keepalive is CLEARED by the logs: 30+ minutes of 200s with the session intact, and
    // every logout instead lands right after a PAGE-LOAD entry. So it stays.
    const left = sessionLeftMin();
    // Record what the countdown said AT the moment the session actually dropped. That is what
    // proves (or kills) the reading of expiresToken as the session's expiry: if it hits zero and
    // the account drops right then, the interpretation is right. If it drops at 12 minutes left,
    // the number means something else and should be ignored.
    if (loggedOut()) { logSession({ st: 'logged-out (countdown said ' + (left == null ? '?' : left + 'm') + ')', ok: false, in: false }); return; }
    logSession({ st: 'session ' + (left == null ? '?' : left + 'm left'), ok: true, in: true });
    if (keepAliveWaiting) return;
    keepAliveWaiting = true;
    window.postMessage({ __ymKeepAlive: 1 }, '*');
    setTimeout(() => { keepAliveWaiting = false; }, 20000);
  }
  const onSmilesApp = () => /smiles\.com\.ar$/i.test(location.hostname) || /smiles\.com\.ar$/i.test(location.hostname.replace(/^www\./, ''));

  // Clear Smiles' "Límite de tiempo caducado" by pressing its own "Rehacer búsqueda". Runs
  // whether or not a drive is on: that notice makes a results page you left sitting useless,
  // and redoing the search is the only thing to do with it — fresh prices, no page load, still
  // logged in. NOT on the passenger or checkout step: there, redoing the search would throw
  // away a booking in progress, so we leave that decision to you.
  function handleSearchExpiry(driving) {
    const redo = redoSearchBtn();
    if (!redo || onPax() || onCheckout()) return false;
    // Only ever press it as part of a booking you started. v0.86 clicked it on any idle page
    // and logouts began right after — unproven, but this button is Smiles' own and we do not
    // know whether it reloads. Not worth risking an account to save you one click.
    if (!driving) {
      if (Date.now() - lastExpirySeen > 60000) { lastExpirySeen = Date.now(); logSession({ st: 'search-expired notice showing (not touched)', ok: true, in: !loggedOut() }); }
      return false;
    }
    if (Date.now() - lastRedo < 8000) return true;
    lastRedo = Date.now(); redoCount++;
    fareAttempt = 0; lastFareTry = 0;          // the results are about to be replaced
    logSession({ st: 'search expired -> rehacer busqueda', ok: true, in: !loggedOut() });
    realClick(redo);
    return true;
  }


  // ---- the "money-slot" cover ------------------------------------------------------------------
  // A branded YM screen laid over the whole Smiles page while a booking runs, with a HOLE cut
  // exactly where the real reCAPTCHA checkbox is. The cover is four panels (top/bottom/left/right)
  // around that hole — so everything ugly is hidden and styled, while the one control the operator
  // must physically click stays open and clickable underneath. reCAPTCHA needs a real click; this
  // gives it one without them ever dealing with the Smiles page.
  //
  // Only while auto-drive is ON for THIS tab, so idle or other Smiles tabs are untouched.
  let driveOnCache = false;
  const CAP = ['__ymCapT', '__ymCapB', '__ymCapL', '__ymCapR', '__ymCapHint'];
  function removeCover() { CAP.forEach(id => { const e = document.getElementById(id); if (e) e.remove(); }); }
  function findCaptchaBox() {
    const anchor = qav('iframe').find(f => /recaptcha\/api2\/anchor/.test(f.src || ''));
    if (anchor) return anchor.closest('div') || anchor;
    return qav('.g-recaptcha')[0] || null;
  }

  let capLocked = null;   // the captcha element we pinned, so we can release it later
  function releaseCaptcha() {
    if (capLocked) { try { capLocked.style.cssText = capLocked.__ymOld || ''; } catch (e) {} capLocked = null; }
    try { document.documentElement.style.overflow = ''; document.body.style.overflow = ''; } catch (e) {}
  }
  function coverWithHole(driveOn) {
    // Cover removed by request — the operator works on the real Smiles page (captcha / keypad /
    // card / Pagar cannot be automated, so hiding the page only got in the way). Keep this a
    // no-op that tidies up any leftover cover, and never freeze scrolling.
    removeCover(); releaseCaptcha();
    return;
    /* eslint-disable no-unreachable */
    const solved = [...document.querySelectorAll('#g-recaptcha-response, textarea[name="g-recaptcha-response"]')].some(t => (t.value || '').length > 20);
    const box = ((loginFields() || onCheckout()) && !solved) ? findCaptchaBox() : null;
    if (!driveOn || !box) { removeCover(); releaseCaptcha(); return; }

    // LOCK IT: pin the captcha to a fixed spot on screen and stop the page scrolling, so the hole
    // can never drift and you never have to go hunting for it. Done once, when the cover appears.
    if (capLocked !== box) {
      releaseCaptcha();
      capLocked = box;
      try {
        box.__ymOld = box.style.cssText;
        const b = box.getBoundingClientRect();
        // keep it roughly where it is, but fixed so scrolling can't move it
        box.style.cssText = box.__ymOld + ';position:fixed !important;left:' + Math.round(Math.max(12, b.left)) + 'px;top:' + Math.round(Math.max(90, b.top)) + 'px;z-index:2147483635 !important;';
        document.documentElement.style.overflow = 'hidden';
        document.body.style.overflow = 'hidden';
      } catch (e) {}
    }

    const r = box.getBoundingClientRect();
    if (r.width < 10 || r.height < 10) { removeCover(); return; }
    const pad = 10;
    const hx = Math.max(0, r.left - pad), hy = Math.max(0, r.top - pad);
    const hw = r.width + pad * 2, hh = r.height + pad * 2;
    const W = window.innerWidth, H = window.innerHeight;
    const cover = 'position:fixed;z-index:2147483630;background:rgba(11,18,32,.72);backdrop-filter:blur(2px);';

    const set = (id, css, html) => {
      let e = document.getElementById(id);
      if (!e) { e = document.createElement('div'); e.id = id; if (html != null) e.innerHTML = html; document.body.appendChild(e); }
      e.style.cssText = css;
      return e;
    };
    // top panel carries the YM branding + status; the others are plain cover
    set('__ymCapT', cover + 'left:0;top:0;width:100%;height:' + hy + 'px;color:#e6f0ff;font:15px system-ui;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center',
      '<div style="font-weight:800;font-size:20px">YM <span style="color:#6ea8ff">Travels</span></div>' +
      '<div id="__ymCapStat" style="margin-top:6px;font-size:14px;color:#cfe3ff"></div>');
    set('__ymCapB', cover + 'left:0;top:' + (hy + hh) + 'px;width:100%;height:' + Math.max(0, H - hy - hh) + 'px');
    set('__ymCapL', cover + 'left:0;top:' + hy + 'px;width:' + hx + 'px;height:' + hh + 'px');
    set('__ymCapR', cover + 'left:' + (hx + hw) + 'px;top:' + hy + 'px;width:' + Math.max(0, W - hx - hw) + 'px;height:' + hh + 'px');
    // arrow/label just under the hole
    set('__ymCapHint', 'position:fixed;z-index:2147483631;left:' + hx + 'px;top:' + (hy + hh + 6) + 'px;background:#f59e0b;color:#111;font:700 13px system-ui;padding:6px 12px;border-radius:8px;pointer-events:none',
      null);
    const hint = document.getElementById('__ymCapHint');
    if (hint) hint.textContent = '👆 tick the box above — I do the rest';
    const stat = document.getElementById('__ymCapStat');
    if (stat) stat.textContent = loginFields() ? 'Signing you in — one tick and the booking continues.'
                                               : 'Confirming payment — one tick, then enter the card.';
  }

  function tick() {
    if (window.__ymDriverOwner !== ME) { if (timer) clearInterval(timer); return; }  // superseded
    if (!alive()) {                       // orphaned by an extension reload — clean up and stop
      if (timer) clearInterval(timer);
      ['__ymDrive', '__ymBook'].forEach(id => { const e = document.getElementById(id); if (e) e.remove(); });
      driveBtn = driveStatusEl = statusEl = null;
      return;
    }
    noteBusyEdge();    // watch for the moment loading stops, so we can settle after it
    buildDriveBar();   // on EVERY Smiles page: the driver routes through the home page mid-search, and the session countdown is worth seeing anywhere
    coverWithHole(driveOnCache);
    manageConsole();
    if (onPax()) buildPanel(); else { const b = document.getElementById('__ymBook'); if (b) { b.remove(); statusEl = null; } }
    // Never act on a page that is still loading. Waiting costs a second; acting early costs a
    // half-filled form, a click into a control that has not mounted, or a submit that races the
    // page. There is no case where pressing on early is better.
    if (document.readyState !== 'complete') {
      if (sessionEl) sessionEl.textContent = '⏳ page loading…';
      return;
    }
    // The console asked for a sign-in: open Smiles' login modal ourselves so the panel can fill
    // it. Without this, "Sign in" only brought the tab to the front and sat there.
    if (!loginFields()) {
      sGet('ymLoginRequest', (rq) => {
        const r = rq && rq.ymLoginRequest;
        if (!r || Date.now() - r.at > 120000) return;
        if (!loggedOut()) {
          sGet(ACCTS, (sa) => {
            const list = (sa && sa[ACCTS]) || [];
            const acct = list.find(x => x.dni === r.dni);
            let mem = ''; try { mem = sessionStorage.getItem('memberNumber') || ''; } catch (e) {}
            // No stored member, or it matches -> this IS the right account (or unknown yet).
            // Backfill the real member so it is known next time, clear the request, done.
            if (acct && (!acct.member || (mem && String(acct.member) === String(mem)))) {
              if (mem && acct.member !== mem) { acct.member = mem; sSet({ [ACCTS]: list }); }
              sSet({ ymLoginRequest: null });
              return;
            }
            flash('👤 Already signed in as another account — press Salir first, then Sign in again.');
          });
          return;
        }
        if (Date.now() - lastLoginHop < 8000) return;
        lastLoginHop = Date.now();
        const li = btnByText(/inici[aá]r?\s*sesi[oó]n/i);
        if (li) { flash('🔑 Opening the login…'); li.click(); }
      });
    } else {
      sGet('ymLoginRequest', (rq) => { if (rq && rq.ymLoginRequest && !loggedOut()) sSet({ ymLoginRequest: null }); });
    }
    if (loginFields() || showAccounts) { buildLoginPanel(); if (loginFields()) loginTick(); }
    else { const b = document.getElementById('__ymLogin'); if (b) b.remove(); }
    handleSearchExpiry(false);
    if (sessionEl) {
      const m = sessionLeftMin();
      sessionEl.textContent = loggedOut() ? '🔴 signed out' : (m == null ? '' : (m > 5 ? '🟢' : '🟠') + ' session ' + m + ' min left');
    }
    driveTick();
    keepAliveTick();
  }
  // Let the background ask this tab whether it is signed in, so Book can pick the tab you
  // actually logged into instead of whichever Smiles tab happens to be in front.
  try {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg && msg.ymWho) {
        let member = '';
        try { member = sessionStorage.getItem('memberNumber') || ''; } catch (e) {}
        sendResponse({ loggedIn: !loggedOut(), tab: TABID, path: location.pathname, member: member, sessionLeftMin: sessionLeftMin() });
        return true;
      }
    });
  } catch (e) {}

  // Record every DOCUMENT load. This script only re-runs when the page genuinely reloads, so an
  // entry here is proof that a real page load happened — including any Smiles triggers itself,
  // which we cannot prevent. Logging the session state right after, and again once the app has
  // had time to boot, shows whether that load is what signed the account out and exactly which
  // page it happened on.
  (function recordLoad() {
    let nav = '?';
    try { nav = (performance.getEntriesByType('navigation')[0] || {}).type || '?'; } catch (e) {}
    logSession({ st: 'PAGE-LOAD(' + nav + ') ' + location.pathname, ok: true, in: !loggedOut() });
    setTimeout(() => logSession({ st: 'settled ' + location.pathname, ok: true, in: !loggedOut() }), 9000);
  })();

  let timer = null;
  tick();
  timer = setInterval(tick, 1500);
})();
