// Injected into flight-processor. Lets the page ask the extension to run a
// Smiles search and get the flights back. The page talks via window.postMessage;
// this relays to the background service worker and posts the answer back.
(function () {
  'use strict';
  const announce = () => window.postMessage({ __ymBridge: 'ready', version: '0.2' }, '*');

  window.addEventListener('message', e => {
    if (e.source !== window || !e.data) return;

    // Page asks "is the extension there?"
    if (e.data.__ymPing) { announce(); return; }

    // Page asks to STOP the current search.
    if (e.data.__ymReq === 'abort') {
      try { if (chrome.runtime && chrome.runtime.id) chrome.runtime.sendMessage({ type: 'abort' }); } catch (ex) {}
      return;
    }

    // Page turns this computer into the desktop agent (or off).
    if (e.data.__ymReq === 'agentConfig') {
      try { if (chrome.runtime && chrome.runtime.id) chrome.runtime.sendMessage({ type: 'agentConfig', enabled: e.data.enabled, url: e.data.url, token: e.data.token }, () => {}); } catch (ex) {}
      return;
    }

    // Page asks whether this computer is currently connected as the agent.
    if (e.data.__ymReq === 'agentStatus') {
      try {
        chrome.runtime.sendMessage({ type: 'agentStatus' }, (resp) => {
          window.postMessage({ __ymRes: 'agentStatus', connected: !!(resp && resp.connected), enabled: !!(resp && resp.enabled) }, '*');
        });
      } catch (ex) {}
      return;
    }

    // Page hands over a booking target: { __ymReq:'book', target:{...} }. The background opens a
    // fresh Smiles results page for that route/date; smiles-book.js there auto-books to checkout.
    if (e.data.__ymReq === 'book') {
      if (!chrome.runtime || !chrome.runtime.id) {
        window.postMessage({ __ymRes: 'book', ok: false, error: 'Extension was reloaded — refresh this page (Ctrl+Shift+R).' }, '*');
        return;
      }
      try {
        chrome.runtime.sendMessage({ type: 'openBooking', target: e.data.target || null }, (resp) => {
          const err = chrome.runtime.lastError;
          window.postMessage({ __ymRes: 'book', ok: !err && resp && resp.ok, error: err ? err.message : (resp && resp.error) || null }, '*');
        });
      } catch (ex) {
        window.postMessage({ __ymRes: 'book', ok: false, error: String(ex) }, '*');
      }
      return;
    }

    // Page requests a search: { __ymReq:'search', id, params:{origin,destination,date,adults?} }
    if (e.data.__ymReq === 'search') {
      const id = e.data.id;
      if (!chrome.runtime || !chrome.runtime.id) {
        window.postMessage({ __ymRes: 'search', id, ok: false, flights: [], error: 'Extension was reloaded — please refresh this page (Ctrl+Shift+R).' }, '*');
        return;
      }
      try {
        chrome.runtime.sendMessage({ type: 'search', params: e.data.params, verify: e.data.verify, verifyUids: e.data.verifyUids }, resp => {
          const err = chrome.runtime.lastError;
          window.postMessage({
            __ymRes: 'search', id,
            ok: !err && resp && resp.ok,
            flights: resp && resp.flights || [],
            error: err ? err.message : (resp && resp.error) || null
          }, '*');
        });
      } catch (ex) {
        window.postMessage({ __ymRes: 'search', id, ok: false, flights: [], error: String(ex) }, '*');
      }
    }
  });

  announce(); // tell the page we're here as soon as we load
})();
