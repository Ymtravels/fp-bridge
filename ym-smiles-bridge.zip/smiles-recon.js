// TEMP booking-flow recon (ISOLATED world) for Smiles. AUTO-captures each booking page/step
// (buttons, inputs, checkboxes, passenger form, favorites) so we can build the assisted-booking
// automation. Just walk a booking to the payment page — it records each screen on its own.
// Then hit "Copy all" and paste to Claude. Remove after.
(function () {
  'use strict';
  const KEY = 'ymBookingRecon';
  const attr = (el, a) => el.getAttribute(a) || '';
  function cssEscape(s){ try{ return CSS.escape(s); }catch(e){ return s; } }
  function sel(el){
    if(el.id) return '#'+cssEscape(el.id);
    let s = el.tagName.toLowerCase();
    if(el.name) s += `[name="${el.name}"]`;
    else if(el.getAttribute('type')) s += `[type="${el.getAttribute('type')}"]`;
    const cls = (typeof el.className==='string'?el.className:'').trim().split(/\s+/).filter(Boolean).slice(0,2).join('.');
    if(cls && !el.name && !el.id) s += '.'+cls;
    return s;
  }
  function label(el){ return (attr(el,'aria-label')||el.placeholder||(el.labels&&el.labels[0]?el.labels[0].innerText:'')||'').trim().replace(/\s+/g,' ').slice(0,60); }
  function visible(el){ const r=el.getBoundingClientRect(); return (r.width>1||r.height>1); }
  function els(){ return [...document.querySelectorAll('button, a[role="button"], a.btn, [role="button"], input, select, textarea, label')].filter(visible); }

  function capturePage(){
    const seen={}, items=[];
    for(const el of els()){
      if(items.length>=90) break;
      const tag=el.tagName.toLowerCase();
      // NEVER record what the user typed (privacy — passwords, DNI, etc). Only button/link/label text.
      const text=/^(button|a|label)$/.test(tag) ? (el.innerText||'').trim().replace(/\s+/g,' ').slice(0,60) : '';
      if(tag==='label' && !text) continue;
      const item={ tag, type:el.getAttribute('type')||'', sel:sel(el), text, label:label(el) };
      const key=item.sel+'|'+item.text; if(seen[key]) continue; seen[key]=1; // dedup identical
      items.push(item);
    }
    const page={ url:location.href.replace(/[?#].*/,'').slice(0,150), title:(document.title||'').slice(0,80), items };
    chrome.storage.local.get(KEY, s=>{ const arr=(s&&s[KEY])||[]; arr.push(page); chrome.storage.local.set({[KEY]:arr}, ()=>flash('✓ Auto-captured. Screens recorded: '+arr.length)); });
  }

  // Auto-capture whenever the screen changes (new page OR the wizard swaps content in place).
  let lastSig='';
  function sig(){ const e=els(); return location.pathname+'|'+e.length+'|'+e.slice(0,8).map(x=>(x.innerText||x.value||x.placeholder||x.name||'').trim().slice(0,14)).join(','); }
  function tick(){ const s=sig(); if(s && s!==lastSig){ lastSig=s; capturePage(); } }

  function copyAll(){
    chrome.storage.local.get(KEY, s=>{ const arr=(s&&s[KEY])||[]; if(!arr.length){ flash('Nothing captured yet — walk a booking first.'); return; } const t=JSON.stringify(arr); navigator.clipboard.writeText(t).then(()=>flash('✓ Copied '+arr.length+' screens — paste to Claude.')).catch(()=>showBox(t)); });
  }
  function clearAll(){ chrome.storage.local.set({[KEY]:[]}, ()=>{ lastSig=''; flash('Cleared — walk the booking now.'); }); }

  let statusEl=null;
  function flash(m){ if(statusEl) statusEl.textContent=m; }
  function showBox(t){ const ta=document.createElement('textarea'); ta.value=t; ta.style.cssText='position:fixed;bottom:70px;left:10px;width:340px;height:170px;z-index:2147483647'; document.body.appendChild(ta); ta.focus(); ta.select(); flash('Clipboard blocked — select all in the box and copy by hand.'); }

  function build(){
    if(document.getElementById('__ymRecon')) return;
    const box=document.createElement('div'); box.id='__ymRecon';
    box.style.cssText='position:fixed;bottom:10px;left:10px;z-index:2147483647;background:#0b1220;color:#cfe3ff;font:12px monospace;border:1px solid #2b6cff;border-radius:9px;padding:8px;max-width:330px;box-shadow:0 6px 18px rgba(0,0,0,.45)';
    const title=document.createElement('div'); title.textContent='YM recon · auto-capturing'; title.style.cssText='font-weight:700;margin-bottom:6px'; box.appendChild(title);
    const mk=(t,fn,bg)=>{ const b=document.createElement('button'); b.textContent=t; b.style.cssText='margin:2px;cursor:pointer;border:0;border-radius:6px;padding:6px 9px;font:12px monospace;background:'+bg+';color:#fff'; b.addEventListener('click',fn); return b; };
    box.appendChild(mk('📋 Copy all',copyAll,'#16a34a'));
    box.appendChild(mk('🗑 Clear',clearAll,'#64748b'));
    box.appendChild(mk('📸 Capture now',capturePage,'#2b6cff'));
    statusEl=document.createElement('div'); statusEl.style.cssText='margin-top:6px;opacity:.85;word-break:break-word'; box.appendChild(statusEl);
    document.body.appendChild(box);
    flash('Walk your booking — each screen records itself.');
    setTimeout(tick, 1200);        // grab the first screen once it's rendered
    setInterval(tick, 1500);       // and auto-grab whenever the screen changes
  }
  if(document.body) build(); else window.addEventListener('DOMContentLoaded',build);
})();
