// RECON build for Azul pelo Mundo (azulpelomundo.voeazul.com.br).
// MAIN world, document_start. Wraps fetch + XHR, captures the site's own JSON API
// responses (the search list + the per-flight detail that carries the tax), and shows
// them in a small on-page overlay with a Copy button so we can see the exact field
// shapes — same recon we did for Smiles. This is TEMPORARY; the real parser replaces it.
(function () {
  'use strict';
  const origFetch = window.fetch;
  const captured = []; // { method, url, status, body }

  const isAsset = u => /\.(js|css|png|jpg|jpeg|gif|svg|woff2?|ttf|ico|map)(\?|$)/i.test(u);
  const looksJson = t => { const s = (t || '').trim(); return s.startsWith('{') || s.startsWith('['); };

  function add(method, url, status, body) {
    try {
      if (isAsset(url)) return;
      if (!looksJson(body)) return;
      if (body.length < 40) return;
      captured.unshift({ method, url: String(url), status, body });
      if (captured.length > 25) captured.pop();
      render();
    } catch (e) {}
  }

  // ---- overlay ----
  let box = null;
  function ensureBox() {
    if (box) return box;
    box = document.createElement('div');
    box.style.cssText = 'position:fixed;top:0;right:0;width:390px;max-height:46vh;overflow:auto;' +
      'background:#fff;color:#111;font:11px/1.4 monospace;border:2px solid #1e3a8a;z-index:2147483647;' +
      'box-shadow:0 4px 18px rgba(0,0,0,.35);padding:6px';
    document.documentElement.appendChild(box);
    return box;
  }
  function shortUrl(u) { try { const x = new URL(u); return x.host.replace('www.', '') + x.pathname; } catch (e) { return u; } }
  function render() {
    ensureBox();
    box.innerHTML = '';
    const head = document.createElement('div');
    head.style.cssText = 'font-weight:700;color:#1e3a8a;margin-bottom:4px;position:sticky;top:0;background:#fff';
    head.textContent = 'AZUL RECON — Copy the search + flight-detail calls (' + captured.length + ')';
    box.appendChild(head);
    captured.forEach((c, i) => {
      const row = document.createElement('div');
      row.style.cssText = 'border-top:1px solid #ddd;padding:4px 0;display:flex;gap:6px;align-items:flex-start';
      const info = document.createElement('div');
      info.style.cssText = 'flex:1;word-break:break-all';
      info.textContent = `[${c.status}] ${c.method} ${shortUrl(c.url)}  (${(c.body.length / 1024).toFixed(1)}kb)`;
      const btn = document.createElement('button');
      btn.textContent = 'Copy';
      btn.style.cssText = 'flex:0 0 auto;cursor:pointer;font:11px monospace;background:#1e3a8a;color:#fff;border:0;border-radius:3px;padding:3px 8px';
      btn.addEventListener('click', () => {
        const payload = 'URL: ' + c.url + '\nSTATUS: ' + c.status + '\n\n' + c.body;
        navigator.clipboard.writeText(payload).then(() => { btn.textContent = 'Copied!'; setTimeout(() => btn.textContent = 'Copy', 1200); })
          .catch(() => { btn.textContent = 'err'; });
      });
      row.appendChild(info); row.appendChild(btn);
      box.appendChild(row);
    });
  }

  // ---- capture ----
  const oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__m = m; this.__u = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    this.addEventListener('load', () => { try { add(this.__m || 'GET', this.__u, this.status, this.responseText); } catch (e) {} });
    return os.apply(this, arguments);
  };
  window.fetch = function (...a) {
    const url = (a[0] && a[0].url) || a[0];
    const method = (a[1] && a[1].method) || (a[0] && a[0].method) || 'GET';
    return origFetch.apply(this, a).then(res => {
      try { res.clone().text().then(b => add(method, url, res.status, b)).catch(() => {}); } catch (e) {}
      return res;
    });
  };
})();
