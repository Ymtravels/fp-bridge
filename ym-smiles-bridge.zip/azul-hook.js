// PAGE (MAIN world), document_start. On Azul pelo Mundo (azulpelomundo.voeazul.com.br),
// catches the site's own availability API response and parses it into the same flight
// shape the app uses — keeping AWARD fares only (real awards, not points-priced cash
// fares). The tax rides along in the search (recommendations[0].fee.total.value, BRL),
// so no per-flight click-in is needed. relay.js forwards the flights to the background.
(function () {
  'use strict';
  const AIRLINE = {
    UA: 'United Airlines', AC: 'Air Canada', AA: 'American Airlines', DL: 'Delta',
    LH: 'Lufthansa', LX: 'Swiss', TP: 'TAP', SA: 'South African', ET: 'Ethiopian',
    TK: 'Turkish', AV: 'Avianca', CM: 'Copa', SQ: 'Singapore', NH: 'ANA', BR: 'EVA',
    AR: 'Aerolineas', AD: 'Azul', AZ: 'ITA', BA: 'British Airways', AF: 'Air France',
    KL: 'KLM', QR: 'Qatar', EK: 'Emirates', EY: 'Etihad', NZ: 'Air New Zealand'
  };
  const hm = t => String(t || '').replace(':', 'h'); // "20:27" -> "20h27" (matches Smiles)
  const origFetch = window.fetch;

  function cabinFromUrl(u) { const m = /cabinCategory=([A-Za-z]+)/.exec(u || ''); return (m ? m[1] : 'ECONOMY').toUpperCase(); }
  function paxFromUrl(u) { const m = /adult=(\d+)/.exec(u || ''); return Math.max(1, m ? +m[1] : 1); }

  function parseAzul(json, url) {
    const cab = cabinFromUrl(url);
    const pax = paxFromUrl(url); // tax below is whole-party; divide by pax for per-person
    const classType = /BUSINESS|FIRST/.test(cab) ? 'business' : (/PREMIUM/.test(cab) ? 'premium' : 'economy');
    const out = [];
    const root = json.data || json; // Azul now wraps the payload in { data: {...} }
    const flights = (root.departureFlights && root.departureFlights.flights) || [];
    flights.forEach(f => {
      if (f.fareOriginType !== 'AWARD') return; // real awards only (skip points-priced cash fares)
      const rec = (f.recommendations && f.recommendations[0]) || {};
      const tax = (rec.fee && rec.fee.total && rec.fee.total.value != null) ? rec.fee.total.value / pax : null;
      const grp = f.flightGroup || [];
      const carrier = (f.operatingCarriers && f.operatingCarriers[0]) || (grp[0] && (grp[0].operatingCarrier || grp[0].marketingCarrier)) || '';
      const stopover = (f.connection > 0 && grp.length > 1) ? { airport: grp[0].destination || '', duration: '' } : null;
      out.push({
        source: 'azul',
        origin: f.originAirport,
        departure: hm(f.departureTime),
        destination: f.finalDestination,
        arrival: hm(f.finalArrivalTime),
        airline: AIRLINE[carrier] || carrier || 'Unknown',
        classType: classType,
        stopover: stopover,
        seats: null,               // Azul doesn't expose seat counts; search already filters to bookable
        miles: f.points ? f.points.value : null,
        milesClub: null,
        taxARS: tax,               // BRL tax; source=azul → priced with the BRL exchange box
        flightNumber: (carrier || '') + (f.firstFlightNumber || '')
      });
    });
    return out;
  }

  function ingest(url, body) {
    try {
      const json = JSON.parse(body);
      const root = json.data || json;
      const raw = ((root.departureFlights && root.departureFlights.flights) || []).length;
      window.postMessage({ __ym: 'flights', url: String(url), flights: parseAzul(json, url), rawCount: raw, seen: true }, '*');
    } catch (e) {
      // The availability XHR fired but the body wasn't JSON (blocked / Access Denied / empty).
      // Report it so the app can say WHY instead of a blank "no flights".
      window.postMessage({ __ym: 'flights', url: String(url), flights: [], rawCount: 0, seen: true, note: 'availability blocked/non-JSON: ' + String(body || '').replace(/\s+/g, ' ').slice(0, 80) }, '*');
    }
  }

  // Match the availability payload by CONTENT (it always contains "departureFlights"),
  // not by a fixed URL — so an endpoint rename doesn't break capture.
  const looksLikeAvailability = (url, body) =>
    typeof body === 'string' && (body.indexOf('departureFlights') !== -1 || /catalog\/api\/v1\/availability/.test(url || ''));

  const oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__u = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    const u = this.__u;
    this.addEventListener('load', () => { try { if (looksLikeAvailability(u, this.responseText)) ingest(u, this.responseText); } catch (e) {} });
    return os.apply(this, arguments);
  };
  window.fetch = function (...a) {
    const url = (a[0] && a[0].url) || a[0];
    return origFetch.apply(this, a).then(res => {
      try { res.clone().text().then(b => { if (looksLikeAvailability(url, b)) ingest(url, b); }).catch(() => {}); } catch (e) {}
      return res;
    });
  };
})();
