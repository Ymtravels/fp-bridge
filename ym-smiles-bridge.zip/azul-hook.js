// PAGE (MAIN world), document_start. On Azul pelo Mundo (azulpelomundo.voeazul.com.br),
// catches the site's own availability API response and parses it into the same flight
// shape the app uses — keeping AWARD fares only (real awards, not points-priced cash
// fares). The tax rides along in the search (recommendations[0].fee.total.value, BRL),
// so no per-flight click-in is needed. relay.js forwards the flights to the background.
(function () {
  'use strict';
  const AIRLINE = {
    UA: 'United Airlines', AC: 'Air Canada', AA: 'American Airlines', DL: 'Delta',
    LH: 'Lufthansa', LX: 'Swiss', TP: 'TAP', SA: 'South African', ET: 'Ethiopian',
    TK: 'Turkish', AV: 'Avianca', CM: 'Copa', SQ: 'Singapore', NH: 'ANA', BR: 'EVA',
    AR: 'Aerolineas', AD: 'Azul', AZ: 'ITA', BA: 'British Airways', AF: 'Air France',
    KL: 'KLM', QR: 'Qatar', EK: 'Emirates', EY: 'Etihad', NZ: 'Air New Zealand'
  };
  const hm = t => String(t || '').replace(':', 'h'); // "20:27" -> "20h27" (matches Smiles)
  const origFetch = window.fetch;

  function cabinFromUrl(u) { const m = /cabinCategory=([A-Za-z]+)/.exec(u || ''); return (m ? m[1] : 'ECONOMY').toUpperCase(); }
  function paxFromUrl(u) { const m = /adult=(\d+)/.exec(u || ''); return Math.max(1, m ? +m[1] : 1); }

  function parseAzul(json, url) {
    const cab = cabinFromUrl(url);
    const pax = paxFromUrl(url); // tax below is whole-party; divide by pax for per-person
    const classType = /BUSINESS|FIRST/.test(cab) ? 'business' : (/PREMIUM/.test(cab) ? 'premium' : 'economy');
    const out = [];
    const flights = (json.departureFlights && json.departureFlights.flights) || [];
    flights.forEach(f => {
      if (f.fareOriginType !== 'AWARD') return; // real awards only (skip points-priced cash fares)
      const rec = (f.recommendations && f.recommendations[0]) || {};
      const tax = (rec.fee && rec.fee.total && rec.fee.total.value != null) ? rec.fee.total.value / pax : null;
      const grp = f.flightGroup || [];
      const carrier = (f.operatingCarriers && f.operatingCarriers[0]) || (grp[0] && (grp[0].operatingCarrier || grp[0].marketingCarrier)) || '';
      const stopover = (f.connection > 0 && grp.length > 1) ? { airport: grp[0].destination || '', duration: '' } : null;
      out.push({
        source: 'azul',
        origin: f.originAirport,
        departure: hm(f.departureTime),
        destination: f.finalDestination,
        arrival: hm(f.finalArrivalTime),
        airline: AIRLINE[carrier] || carrier || 'Unknown',
        classType: classType,
        stopover: stopover,
        seats: null,               // Azul doesn't expose seat counts; search already filters to bookable
        miles: f.points ? f.points.value : null,
        milesClub: null,
        taxARS: tax,               // BRL tax; source=azul → priced with the BRL exchange box
        flightNumber: (carrier || '') + (f.firstFlightNumber || '')
      });
    });
    return out;
  }

  // TEMP diagnostic: show, right on the Azul page, what the availability call returned —
  // so we can see if the data's there and what shape it's in. Remove once Azul capture is fixed.
  function showDiag(url, body) {
    try {
      let box = document.getElementById('__ymAzulDiag');
      if (!box) {
        box = document.createElement('div');
        box.id = '__ymAzulDiag';
        box.style.cssText = 'position:fixed;top:0;left:0;right:0;max-height:45vh;overflow:auto;background:#0b0b0b;color:#39ff14;font:12px/1.4 monospace;z-index:2147483647;padding:8px;border-bottom:2px solid #39ff14';
        document.documentElement.appendChild(box);
      }
      let summary;
      try {
        const j = JSON.parse(body);
        const dep = (j.departureFlights && j.departureFlights.flights) || [];
        const ret = (j.returnFlights && j.returnFlights.flights) || [];
        const award = dep.filter(f => f && f.fareOriginType === 'AWARD').length;
        summary = 'CAUGHT availability ✓  departureFlights=' + dep.length + '  AWARD=' + award + '  returnFlights=' + ret.length + '\ntop-level keys: ' + Object.keys(j).join(', ');
      } catch (e) {
        summary = 'availability response was NOT JSON (blocked/empty):\n' + String(body || '').slice(0, 200);
      }
      box.innerHTML = '';
      const s = document.createElement('div'); s.style.whiteSpace = 'pre-wrap'; s.textContent = 'YM DIAG — ' + summary;
      const btn = document.createElement('button'); btn.textContent = 'Copy full response'; btn.style.cssText = 'margin-top:6px;cursor:pointer;background:#39ff14;color:#000;border:0;border-radius:3px;padding:5px 10px;font:12px monospace';
      btn.onclick = () => { navigator.clipboard.writeText('URL: ' + url + '\n\n' + body).then(() => { btn.textContent = 'Copied!'; setTimeout(() => btn.textContent = 'Copy full response', 1500); }).catch(() => { btn.textContent = 'copy failed'; }); };
      const x = document.createElement('button'); x.textContent = '✕'; x.style.cssText = 'float:right;cursor:pointer;background:transparent;color:#39ff14;border:1px solid #39ff14;border-radius:3px;padding:2px 7px';
      x.onclick = () => box.remove();
      box.appendChild(x); box.appendChild(s); box.appendChild(btn);
    } catch (e) {}
  }

  function ingest(url, body) {
    if (!/catalog\/api\/v1\/availability/.test(url)) return;
    showDiag(url, body); // TEMP

    try {
      const json = JSON.parse(body);
      const raw = ((json.departureFlights && json.departureFlights.flights) || []).length;
      window.postMessage({ __ym: 'flights', url: String(url), flights: parseAzul(json, url), rawCount: raw, seen: true }, '*');
    } catch (e) {
      // The availability XHR fired but the body wasn't JSON (blocked / Access Denied / empty).
      // Report it so the app can say WHY instead of a blank "no flights".
      window.postMessage({ __ym: 'flights', url: String(url), flights: [], rawCount: 0, seen: true, note: 'availability blocked/non-JSON: ' + String(body || '').replace(/\s+/g, ' ').slice(0, 80) }, '*');
    }
  }

  const oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__u = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    const u = this.__u;
    if (typeof u === 'string' && /catalog\/api\/v1\/availability/.test(u)) this.addEventListener('load', () => ingest(u, this.responseText));
    return os.apply(this, arguments);
  };
  window.fetch = function (...a) {
    const url = (a[0] && a[0].url) || a[0];
    return origFetch.apply(this, a).then(res => {
      if (typeof url === 'string' && /catalog\/api\/v1\/availability/.test(url)) res.clone().text().then(b => ingest(url, b)).catch(() => {});
      return res;
    });
  };

  // TEMP: announce the hook the instant it loads, so "no bar at all" (extension not active)
  // is distinguishable from "bar shows but never updates" (call not intercepted).
  (function mark() {
    try {
      const el = document.documentElement;
      if (!el) return setTimeout(mark, 150);
      if (document.getElementById('__ymAzulDiag')) return;
      const box = document.createElement('div');
      box.id = '__ymAzulDiag';
      box.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#0b0b0b;color:#39ff14;font:12px monospace;z-index:2147483647;padding:6px;border-bottom:2px solid #39ff14';
      box.textContent = 'YM DIAG — extension hook ACTIVE ✓  Now search a route; this bar updates with what Azul returned.';
      el.appendChild(box);
    } catch (e) {}
  })();
})();
