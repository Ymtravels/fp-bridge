// Isolated content-script world. Bridges page <-> extension both ways.
let vCounter = 0;

// page -> extension: captured flights
window.addEventListener('message', e => {
  if (e.source === window && e.data && e.data.__ym === 'flights') {
    try { chrome.runtime.sendMessage({ type: 'flights', flights: e.data.flights, rawCount: e.data.rawCount, url: e.data.url }); } catch (err) {}
  }
});

// extension -> page: run a seat-verify, return the confirmed seats
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.ymVerify) {
    const id = 'v' + (++vCounter);
    const onMsg = e => {
      if (e.source === window && e.data && e.data.__ymVerifyRes && e.data.__ymVerifyRes.id === id) {
        window.removeEventListener('message', onMsg);
        sendResponse(e.data.__ymVerifyRes);
      }
    };
    window.addEventListener('message', onMsg);
    window.postMessage({ __ymVerify: Object.assign({ id: id }, msg.ymVerify) }, '*');
    setTimeout(() => { window.removeEventListener('message', onMsg); try { sendResponse({ ok: false, status: 'timeout' }); } catch (e) {} }, 13000);
    return true; // async sendResponse
  }
});
