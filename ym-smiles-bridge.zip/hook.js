// PAGE (MAIN world), document_start. Captures the site's own API auth headers +
// environment (green/blue), catches the /airlines/search response, and answers
// verify requests by calling boardingtax with those SAME headers, so Smiles
// treats it exactly like a real click instead of blocking it (452).
(function () {
  'use strict';
  const AIRLINE = { AA: 'American Airlines', AC: 'Air Canada', UA: 'United Airlines', DL: 'Delta', WN: 'Southwest', B6: 'JetBlue', PD: 'Porter Airlines' };
  const CABIN = { ECONOMIC: 'economy', BUSINESS: 'business', PREMIUM_ECONOMIC: 'premium', PREMIUM: 'premium' };
  const hm = iso => { const t = String(iso).split('T')[1] || '00:00:00'; return t.slice(0, 2) + 'h' + t.slice(3, 5); };
  const dur = ts => { if (!ts) return ''; const h = ts.hours || 0, m = ts.minutes || 0; return ((h ? h + 'h ' : '') + (m ? m + 'min' : '')).trim(); };
  const origFetch = window.fetch;

  // ---- reload/auth trace -------------------------------------------------------------
  // sessionStorage SURVIVES a reload, so a trace written here can be read back afterwards —
  // which is the only way to see what the app did in the seconds before it lost the session.
  // Records: page loads, who called location.reload(), SPA route changes, and the status of
  // auth-ish API calls. URLs and statuses only, never response bodies or tokens.
  const TRACE = '__ymTrace';
  // A 401/403 from Smiles is PROOF the session is gone — not a guess from a spinner that will not
  // stop, and not something a timer has to wait out. Whatever the page is waiting on can never be
  // answered, so the driver can restart the moment this appears.
  // Two Smiles accounts open in one Chrome profile contaminate each other: measured on the live
  // site, one tab showed ARON in its header while calling the API with Antonella's member number,
  // and the other tab showed the reverse. The session token is per-tab but the member identity is
  // not, so a booking could be charged to the wrong account's miles.
  //
  // Smiles puts the member number straight into its request URLs, so the mismatch is visible: if a
  // call goes out for a member this tab is not signed in as, the page is crossed. Recorded here;
  // the driver refuses to touch a booking while it stands.
  function noteCrossed(url) {
    const m = /[?&]memberNumber=(\d+)/.exec(url || '');
    if (!m) return;
    let mine = '';
    try { mine = sessionStorage.getItem('memberNumber') || ''; } catch (e) {}
    if (!mine || m[1] === mine) return;
    try {
      sessionStorage.setItem('__ymCrossed', JSON.stringify({
        at: Date.now(), calledFor: m[1], thisTab: mine, url: String(url).slice(0, 100)
      }));
    } catch (e) {}
  }

  function noteAuthFail(status, url) {
    if (status !== 401 && status !== 403) return;
    if (!/smiles\.com\.(ar|br)/i.test(url || '')) return;
    try {
      sessionStorage.setItem('__ymAuthFail', JSON.stringify({
        at: Date.now(), status: status, url: String(url).slice(0, 120)
      }));
    } catch (e) {}
  }

  function trace(kind, detail) {
    try {
      const arr = JSON.parse(sessionStorage.getItem(TRACE) || '[]');
      arr.push({ t: Date.now(), k: kind, d: String(detail).replace(/[?&](access_token|id_token|code)=[^&]*/gi, '$1=***').slice(0, 150) });
      while (arr.length > 45) arr.shift();
      sessionStorage.setItem(TRACE, JSON.stringify(arr));
    } catch (e) {}
  }
  try { trace('LOAD', location.pathname + ' nav=' + ((performance.getEntriesByType('navigation')[0] || {}).type || '?')); } catch (e) {}

  // Who calls reload? Patch it to record a stack, then call through unchanged.
  try {
    const origReload = location.reload.bind(location);
    Object.defineProperty(location, 'reload', {
      configurable: true, writable: true,
      value: function () {
        let who = ''; try { who = String(new Error().stack || '').slice(0, 220); } catch (e) {}
        trace('RELOAD-CALLED', who);
        return origReload();
      }
    });
    trace('patch', 'location.reload patched OK');
  } catch (e) { trace('patch', 'location.reload NOT patchable: ' + (e && e.message)); }

  // SPA route changes — proves whether a click routed in-page instead of reloading.
  try {
    const ps = history.pushState, rs = history.replaceState;
    history.pushState = function () { try { trace('pushState', arguments[2]); } catch (e) {} return ps.apply(this, arguments); };
    history.replaceState = function () { try { trace('replaceState', arguments[2]); } catch (e) {} return rs.apply(this, arguments); };
  } catch (e) {}
  window.addEventListener('beforeunload', () => trace('UNLOAD', location.pathname));

  let siteHeaders = null; // {Authorization, x-api-key, Region, Language, Channel} lifted from the site's own calls
  let apiEnv = 'blue';    // 'green' | 'blue' — read from the live API host

  function grabHeaders(url, h) {
    if (!h) return;
    if (h['x-api-key'] || h['X-Api-Key'] || h['Authorization'] || h['authorization']) siteHeaders = h;
    const m = /-(green|blue)\.smiles\.com\.ar/.exec(url);
    if (m) apiEnv = m[1];
  }

  function fareMiles(list, type) { const f = (list || []).find(x => x.type === type); return f ? f.miles : null; }
  function parseSmiles(json) {
    const out = [];
    (json.requestedFlightSegmentList || []).forEach(seg => {
      (seg.flightList || []).forEach(f => {
        const code = f.airline && f.airline.code;
        const fSmiles = (f.fareList || []).find(x => x.type === 'SMILES');
        const fClub = (f.fareList || []).find(x => x.type === 'SMILES_CLUB');
        // Keep anything bookable with miles — true award OR "comercial" fares paid in
        // miles (some routes, esp. Caribbean/long-haul, only have the latter).
        if (!fSmiles && !fClub) return;
        out.push({
          sourceFare: f.sourceFare || null,
          origin: f.departure.airport.code, departure: hm(f.departure.date),
          destination: f.arrival.airport.code, arrival: hm(f.arrival.date),
          airline: AIRLINE[code] || (f.airline && f.airline.name) || code || 'Unknown',
          classType: CABIN[f.cabin] || 'economy',
          stops: f.stops || 0,
          stopover: (f.stops > 0 && f.airportMainStop && f.airportMainStop.code)
            ? { airport: f.airportMainStop.code, duration: dur(f.timeStop) } : null,
          seats: f.availableSeats,
          miles: fSmiles ? fSmiles.miles : null,
          milesClub: fClub ? fClub.miles : null,
          uid: f.uid,
          type: seg.type || 'SEGMENT_1',
          fareUid: fSmiles ? fSmiles.uid : null
        });
      });
    });
    return out;
  }

  function ingest(url, body) {
    if (!/\/airlines\/search/.test(url)) return;
    try {
      const json = JSON.parse(body);
      let raw = 0;
      (json.requestedFlightSegmentList || []).forEach(s => raw += (s.flightList || []).length);
      // Leave proof that a search RAN and what it returned. Without this an empty results page is
      // ambiguous: it looks identical whether Smiles searched and found nothing, or never searched
      // at all (a page that loaded signed out). Those need opposite responses — stop, or retry.
      try {
        sessionStorage.setItem('__ymLastSearch', JSON.stringify({
          at: Date.now(), count: raw, url: String(url).slice(0, 200)
        }));
      } catch (e) {}
      window.postMessage({ __ym: 'flights', url: String(url), flights: parseSmiles(json), rawCount: raw }, '*');
    } catch (e) {}
  }

  // A read-only authenticated GET the site itself made and that SUCCEEDED. Replaying exactly
  // this is the keepalive: it is by definition a real, valid, harmless call for this session,
  // so we never have to guess at an endpoint.
  let lastGet = null;

  const oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send, oh = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.open = function (m, u) { this.__m = m; this.__u = u; this.__h = {}; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.setRequestHeader = function (k, v) { if (this.__h) this.__h[k] = v; return oh.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function () {
    const u = this.__u;
    if (typeof u === 'string' && /api-[\w-]*\.smiles\.com\.ar/.test(u)) grabHeaders(u, this.__h);
    if (typeof u === 'string' && /\/airlines\/search/.test(u)) this.addEventListener('load', () => ingest(u, this.responseText));
    if (typeof u === 'string' && /^get$/i.test(this.__m || '') && /api-[\w-]*\.smiles\.com\.ar/.test(u) && !/\/airlines\/search/.test(u)) {
      this.addEventListener('load', () => { if (this.status === 200) lastGet = { url: u, headers: this.__h || {} }; });
    }
    if (typeof u === 'string' && /token|oauth|auth|login|session|refresh|member|customer/i.test(u)) {
      this.addEventListener('load', () => {
        trace('auth-xhr ' + this.status, u);
        noteAuthFail(this.status, u);
        noteCrossed(u);
      });
      this.addEventListener('error', () => trace('auth-xhr ERR', u));
    }
    // THE token question. /api/oauth/token returns 200 minutes after login — is it renewing the
    // member session, or only the app-level token? Capture the SHAPE of the exchange: which
    // fields are sent, the grant_type (a type name, not a secret), which fields come back, and
    // whether sessionStorage.expiresToken moves as a result. Never any values: a token in a log
    // is a stolen session.
    if (typeof u === 'string' && /\/oauth\/token|\/api\/login/.test(u)) {
      const before = (() => { try { return sessionStorage.getItem('expiresToken') || '-'; } catch (e) { return '-'; } })();
      let sent = '';
      try {
        const raw = arguments[0];
        if (typeof raw === 'string') {
          const keys = raw.trim().startsWith('{') ? Object.keys(JSON.parse(raw)) : [...new URLSearchParams(raw).keys()];
          const gt = raw.match(/grant_type["'=:\s]+([a-z_]+)/i);
          sent = keys.join(',') + (gt ? ' grant_type=' + gt[1] : '');
        }
      } catch (e) { sent = '?'; }
      this.addEventListener('load', () => {
        let got = '';
        try { got = Object.keys(JSON.parse(this.responseText || '{}')).join(','); } catch (e) { got = 'non-json'; }
        setTimeout(() => {
          let after = '-';
          try { after = sessionStorage.getItem('expiresToken') || '-'; } catch (e) {}
          const moved = (before !== '-' && after !== '-' && after !== before)
            ? ('SESSION EXTENDED by ' + Math.round((+after - +before) / 60000) + ' min')
            : 'session clock UNCHANGED';
          const line = 'TOKENCALL ' + this.status + ' ' + (this.__m || '') + ' ' + u.replace(/^https?:\/\/[^/]+/, '') +
                       ' sent[' + sent + '] got[' + got + '] -> ' + moved;
          trace('TOKENCALL', line);
          // Its own store: the rolling trace holds 45 entries and one booking produces dozens,
          // so the very line we are trying to capture would be flushed away before it was read.
          try {
            const arr = JSON.parse(sessionStorage.getItem('__ymTokenLog') || '[]');
            arr.push({ t: Date.now(), line: line });
            while (arr.length > 12) arr.shift();
            sessionStorage.setItem('__ymTokenLog', JSON.stringify(arr));
          } catch (e) {}
        }, 400);
      });
    }
    return os.apply(this, arguments);
  };

  window.fetch = function (...a) {
    const url = (a[0] && a[0].url) || a[0];
    return origFetch.apply(this, a).then(res => {
      try { noteAuthFail(res.status, String(url)); noteCrossed(String(url)); } catch (e) {}
      if (typeof url === 'string' && /\/airlines\/search/.test(url)) res.clone().text().then(b => ingest(url, b)).catch(() => {});
      if (typeof url === 'string' && /token|oauth|auth|login|session|refresh|member|customer/i.test(url)) trace('auth-fetch ' + res.status, url);
      return res;
    });
  };

  // Keepalive: re-issue the site's own last successful authenticated GET. If Smiles' hour is an
  // IDLE timeout this keeps the account logged in; if it's a hard expiry the session dies anyway
  // and the reply tells us so (401/403). Either way we learn which, from real data.
  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || !e.data.__ymKeepAlive) return;
    if (!lastGet) { window.postMessage({ __ymKeepAliveRes: { ok: false, status: 'no-call-captured' } }, '*'); return; }
    const headers = Object.assign({ 'Accept': 'application/json, text/plain, */*' }, siteHeaders || {}, lastGet.headers || {});
    origFetch(lastGet.url, { credentials: 'include', headers: headers })
      .then(r => window.postMessage({ __ymKeepAliveRes: { ok: r.ok, status: r.status } }, '*'))
      .catch(() => window.postMessage({ __ymKeepAliveRes: { ok: false, status: 'neterr' } }, '*'));
  });

  // Verify a flight the way a real click does: boardingtax on the correct env host,
  // carrying the site's own auth headers.
  window.addEventListener('message', function (e) {
    if (e.source !== window || !e.data || !e.data.__ymVerify) return;
    const v = e.data.__ymVerify;
    const host = 'api-airlines-boarding-tax-' + apiEnv + '.smiles.com.ar';
    const url = 'https://' + host + '/v1/airlines/flight/boardingtax?adults=' + (v.adults || 1) + '&children=0&infants=0'
      + '&fareuid=' + encodeURIComponent(v.fareUid)
      + '&uid=' + encodeURIComponent(v.uid)
      + '&type=' + encodeURIComponent(v.type || 'SEGMENT_1')
      + '&highlightText=SMILES&currency=ARS';
    const headers = Object.assign({ 'Accept': 'application/json, text/plain, */*' }, siteHeaders || {});
    origFetch(url, { credentials: 'include', headers: headers })
      .then(r => r.text().then(t => ({ status: r.status, ok: r.ok, t: t })))
      .then(o => {
        let seats = null, gotFl = false, taxMoney = null;
        if (o.ok) { try {
          const j = JSON.parse(o.t);
          const fl = j.flightList && j.flightList[0];
          if (fl) {
            seats = fl.availableSeats; gotFl = true;
            const totals = j.totals || {};
            const bt = fl.boardingTax || {};
            const pax = v.adults || 1;
            // "tasas e impuestos (dinero)" is the WHOLE-PARTY tax. Miles are per-person, so
            // divide the tax by the passenger count → per-person tax → per-person price.
            const rawTax = (totals.total && totals.total.money != null) ? totals.total.money
              : (bt.boardingTaxMoney != null ? bt.boardingTaxMoney : (bt.money != null ? bt.money : null));
            taxMoney = rawTax != null ? rawTax / pax : null;
          }
        } catch (e) {} }
        window.postMessage({ __ymVerifyRes: { id: v.id, ok: gotFl, seats: seats, status: o.status, hadHeaders: !!siteHeaders, taxMoney: taxMoney } }, '*');
      })
      .catch(err => window.postMessage({ __ymVerifyRes: { id: v.id, ok: false, status: 'neterr' } }, '*'));
  });
})();
