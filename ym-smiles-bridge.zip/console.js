// Operator console. The piece between "the automation works" and "this is usable at scale":
// which accounts have a live session, what is queued, and which booking runs next.
//
// Everything lives in chrome.storage.local on this machine — the same store the driver reads —
// so the console and the booking driver are never out of step with each other.
const $ = (id) => document.getElementById(id);
const ACCTS = 'ymAccounts', ACTIVE = 'ymActiveAccount', ORDERS = 'ymOrders', TARGET = 'ymBookTarget', DRIVE = 'ymAutoDrive', CURRENT = 'ymCurrentOrder';
const sGet = (k) => new Promise(r => chrome.storage.local.get(k, (v) => r(v || {})));
const sSet = (o) => new Promise(r => chrome.storage.local.set(o, r));
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
setInterval(() => { $('clock').textContent = new Date().toLocaleTimeString(); }, 1000);

// A session's remaining minutes live in the Smiles tab's sessionStorage, which only that tab can
// read — so ask each open Smiles tab about itself rather than guessing from here.
async function tabSessions() {
  const out = {};
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: '*://*.smiles.com.ar/*' }); } catch (e) { return out; }
  await Promise.all(tabs.map(t => new Promise(res => {
    try {
      chrome.tabs.sendMessage(t.id, { ymWho: 1 }, (r) => {
        void chrome.runtime.lastError;
        if (r && r.loggedIn) out[t.id] = { tab: t, member: r.member || '', left: r.sessionLeftMin };
        res();
      });
    } catch (e) { res(); }
  })));
  return out;
}

function sessionPill(left) {
  if (left == null) return '<span class="pill bad">no session</span>';
  if (left <= 0) return '<span class="pill bad">expired</span>';
  if (left <= 5) return '<span class="pill warn">' + left + ' min left</span>';
  return '<span class="pill ok">' + left + ' min left</span>';
}


// Which accounts have a live session, tolerant of a missing member number. The tab always reports
// its real member (from sessionStorage), but a saved account only knows its member after a panel
// login — so match by member when we can, else trust a signed-in tab for the active/only account,
// and BACKFILL the real member onto the account so every future match just works.
async function liveAccounts() {
  const { [ACCTS]: accts = [], [ACTIVE]: active } = await sGet([ACCTS, ACTIVE]);
  const live = await tabSessions();
  const tabsLive = Object.values(live).filter(v => (v.left == null || v.left > 0));
  const byMember = {}; tabsLive.forEach(v => { if (v.member) byMember[String(v.member)] = v; });
  const map = {};   // dni -> { left }
  let changed = false;
  for (const a of accts) {
    let t = a.member ? byMember[String(a.member)] : null;
    if (!t && tabsLive.length && (accts.length === 1 || a.dni === active)) {
      t = tabsLive[0];
      if (t.member && a.member !== t.member) { a.member = t.member; changed = true; }  // self-heal
    }
    if (t) map[a.dni] = { left: t.left };
  }
  if (changed) await sSet({ [ACCTS]: accts });
  return map;
}

async function renderAccounts() {
  const { [ACCTS]: accts = [] } = await sGet(ACCTS);
  const anyTab = Object.keys(await tabSessions()).length > 0;
  const liveMap = await liveAccounts();

  if (!accts.length) return;
  $('accounts').innerHTML = accts.map(a => {
    const left = liveMap[a.dni] ? liveMap[a.dni].left : null;
    // "no session" is only honest when we actually asked a signed-in tab. With no Smiles tab
    // open, the truthful state is "not open", not "no session".
    const pill = left != null ? sessionPill(left)
      : (anyTab ? '<span class="pill bad">no session</span>' : '<span class="pill dim">not open</span>');
    return '<div class="row">' +
      '<div class="grow"><div class="name">' + esc(a.name || a.dni) + '</div>' +
      '<div class="sub">' + esc(a.dni) + (a.cardName ? ' · card: ' + esc(a.cardName) : '') + '</div></div>' +
      pill +
      '<button class="ghost" data-signin="' + esc(a.dni) + '">' + (left > 0 ? 'Switch to' : 'Sign in') + '</button>' +
      '</div>';
  }).join('');

  document.querySelectorAll('[data-signin]').forEach(b => {
    b.addEventListener('click', () => signIn(b.getAttribute('data-signin')));
  });
}

// Make this the account bookings run on, then open Smiles so the login panel fills it. The
// captcha is the only part left — it has to be ticked on the page it belongs to.
async function signIn(dni) {
  // Focusing the tab is not enough: the login is a modal that has to be opened. Leave a request
  // the driver picks up, so it clicks "Iniciá sesión" and the panel fills the account in.
  await sSet({ [ACTIVE]: dni, ymLoginRequest: { dni: dni, at: Date.now() } });
  const tabs = await chrome.tabs.query({ url: '*://*.smiles.com.ar/*' });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    try { await chrome.windows.update(tabs[0].windowId, { focused: true }); } catch (e) {}
  } else {
    await chrome.tabs.create({ url: 'https://www.smiles.com.ar/', active: true });
  }
}

async function renderOrders() {
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  const { [ACCTS]: accts = [] } = await sGet(ACCTS);
  const nameOf = (dni) => { const a = accts.find(x => x.dni === dni); return a ? (a.name || a.dni) : (dni || '—'); };
  if (!orders.length) { $('orders').innerHTML = '<div class="empty">Nothing queued.</div>'; return; }
  const running = (o) => o.status === 'booking' || o.status === 'payment';
  const acctOptions = (sel) => '<option value=""' + (!sel ? ' selected' : '') + '>— pick account —</option>' +
    accts.map(a => '<option value="' + esc(a.dni) + '"' + (a.dni === sel ? ' selected' : '') + '>' + esc(a.name || a.dni) + '</option>').join('');
  $('orders').innerHTML = orders.map(o => {
    const live = running(o) && o.step ? '<div class="sub" style="color:#6ea8ff;margin-top:2px">' + esc(o.step) + '</div>' : '';
    const acctCell = (o.status === 'queued')
      ? '<select class="acctPick" data-id="' + esc(o.id) + '" style="max-width:150px">' + acctOptions(o.account) + '</select>'
      : '<span class="sub">' + esc(nameOf(o.account)) + '</span>';
    const btn = running(o)
      ? '<button class="ghost" data-watch="' + esc(o.id) + '">watch</button><button data-done="' + esc(o.id) + '">Done → next</button>'
      : '<button data-book="' + esc(o.id) + '"' + (o.account ? '' : ' disabled title="pick an account first"') + '>Book</button>';
    return '<div class="row">' +
      '<div class="grow"><div class="name">' + esc(o.origin) + ' → ' + esc(o.destination) + ' · ' + esc(o.dep || '') + '</div>' +
      '<div class="sub">' + esc(o.date) + ' · ' + esc(o.cabin) + ' · ' + (o.miles || []).join('–') + ' mi</div>' + live + '</div>' +
      acctCell +
      '<span class="pill ' + (o.status === 'done' ? 'ok' : o.status === 'failed' ? 'bad' : running(o) ? 'warn' : 'dim') + '">' + esc(o.status || 'queued') + '</span>' +
      btn +
      '<button class="x" data-del="' + esc(o.id) + '">✕</button>' +
      '</div>';
  }).join('');

  document.querySelectorAll('.acctPick').forEach(sel => sel.addEventListener('change', async () => {
    const { [ORDERS]: list = [] } = await sGet(ORDERS);
    const o = list.find(x => x.id === sel.getAttribute('data-id'));
    if (o) { o.account = sel.value; await sSet({ [ORDERS]: list, ymDefaultAccount: sel.value }); renderOrders(); }
  }));
  document.querySelectorAll('[data-book]').forEach(b => b.addEventListener('click', () => bookOrder(b.getAttribute('data-book'))));
  document.querySelectorAll('[data-done]').forEach(b => b.addEventListener('click', () => finishOrder(b.getAttribute('data-done'))));
  document.querySelectorAll('[data-watch]').forEach(b => b.addEventListener('click', openSmiles));
  document.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    const { [ORDERS]: list = [] } = await sGet(ORDERS);
    await sSet({ [ORDERS]: list.filter(x => x.id !== b.getAttribute('data-del')) });
    renderOrders();
  }));
}

// Hand one order to the driver: make its account the active one, arm the flight, focus Smiles.
// From there it is the flow already built — restart from home, search, flight, fare, passenger.
async function bookOrder(id, useAccount) {
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  const o = orders.find(x => x.id === id);
  if (!o) return;
  const acct = o.account || useAccount || '';
  if (acct) { o.account = acct; await sSet({ [ACTIVE]: acct }); }
  await sSet({
    [TARGET]: {
      origin: o.origin, destination: o.destination, date: o.date, dep: o.dep,
      cabin: o.cabin, stops: o.stops || 0, miles: o.miles || [], adults: o.adults || 1,
      summary: o.origin + ' ' + (o.dep || '') + ' → ' + o.destination + ' ' + o.date
    },
    [DRIVE]: { on: true, startedAt: Date.now() }
  });
  o.status = 'booking';
  await sSet({ [ORDERS]: orders, [CURRENT]: o.id });
  renderOrders();
  const tabs = await chrome.tabs.query({ url: '*://*.smiles.com.ar/*' });
  if (tabs.length) { await chrome.tabs.update(tabs[0].id, { active: true }); try { await chrome.windows.update(tabs[0].windowId, { focused: true }); } catch (e) {} }
  else await chrome.tabs.create({ url: 'https://www.smiles.com.ar/', active: true });
}

// Mark the running order finished and start the next one waiting on the SAME account — that
// account already has a live session, so the next booking costs no captcha at all. This is the
// whole point of batching by account.
async function finishOrder(id) {
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  const o = orders.find(x => x.id === id);
  if (o) { o.status = 'done'; o.at = Date.now(); }
  await sSet({ [ORDERS]: orders, [CURRENT]: '' });
  const next = orders.find(x => x.status === 'queued' && (!o || x.account === o.account));
  await renderOrders();
  if (next) { await bookOrder(next.id); return; }
  const other = orders.find(x => x.status === 'queued');
  if (other) alert('Done. The next queued booking is on a different account — press Book on it when you are ready to switch.');
}


// ---- auto-run ---------------------------------------------------------------------------------
// The queue drives itself: when nothing is mid-booking and an account with queued work has a live
// session, start its next order. You never press Book per booking — the only thing that reaches
// you is a captcha (surfaced by the driver's money-slot cover). Off by default; a toggle turns it
// on. It never starts a booking on an account with no session — that needs a captcha first.
let autoRun = false;
try { autoRun = localStorage.getItem('ymAutoRun') === '1'; } catch (e) {}

let lastAutoStart = 0;
async function autoTick() {
  if (!autoRun) return;
  const { [ORDERS]: orders = [], [CURRENT]: current } = await sGet([ORDERS, CURRENT]);
  // Something already running — booking, at payment, OR stopped/failed and waiting for a human —
  // leave it alone. A 'failed'/'stopped' order must NOT be auto-restarted: that is the "I xed out
  // and it just redid the same flight" loop. Only a human clears it (Done, retry, or delete).
  if (orders.some(o => ['booking', 'payment', 'failed', 'stopped', 'needs-you'].includes(o.status))) return;
  // 'current' only blocks if it still points to a running order (guard against a stale id).
  if (current && orders.some(o => o.id === current && (o.status === 'booking' || o.status === 'payment'))) return;
  // Never fire two starts back to back — give a fresh booking room to settle before the next.
  if (Date.now() - lastAutoStart < 8000) return;
  const liveMap = await liveAccounts();
  // A queued order whose ASSIGNED account is signed in -> book it.
  const next = orders.find(o => o.status === 'queued' && o.account && liveMap[o.account]);
  if (next) { lastAutoStart = Date.now(); await bookOrder(next.id); return; }

  // Nothing runnable because the account it needs is NOT signed in. Don't just sit there —
  // open that account's login and surface the captcha, so one tick starts the session and the
  // booking then runs on its own. This is the difference between "auto-run does nothing" and
  // "auto-run asks for the one thing it can't do itself".
  const waiting = orders.find(o => o.status === 'queued' && o.account && !liveMap[o.account]);
  if (!waiting) return;
  // ONE ask, not a stream of them. If a login request is already outstanding (the modal is open
  // and waiting on the captcha), leave it alone however many more orders arrive — they all need
  // that same session, so re-asking just nags and can reopen the modal under your hands.
  const { ymLoginRequest: pending } = await sGet('ymLoginRequest');
  if (pending && Date.now() - (pending.at || 0) < 180000) return;
  lastAutoStart = Date.now();
  await signIn(waiting.account);                          // opens the login pre-filled; you tick the captcha
}

// The manual search form is gone — bookings come from the customer page, which already carries
// route, date, departure and the real miles from Smiles' own search. Nothing to retype here.

$('openSmiles').addEventListener('click', openSmiles);

// Walk the accounts that queued work needs and that have no live session, one at a time. Each
// opens pre-filled; you tick its captcha and the next follows. That is the batching that makes
// the hourly login cost bearable across a pool of accounts.
$('signAll').addEventListener('click', async () => {
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  const { [ACCTS]: accts = [] } = await sGet(ACCTS);
  const live = await tabSessions();
  const haveMembers = Object.values(live).map(v => String(v.member || ''));
  const needed = [...new Set(orders.filter(o => o.status !== 'done').map(o => o.account).filter(Boolean))];
  const list = (needed.length ? needed : accts.map(a => a.dni))
    .filter(dni => { const a = accts.find(x => x.dni === dni); return a && haveMembers.indexOf(String(a.member || '')) === -1; });
  if (!list.length) { alert('Every account you need already has a live session.'); return; }
  await signIn(list[0]);
  alert('Signing in ' + list.length + ' account' + (list.length === 1 ? '' : 's') + '.\n\nTick the captcha on the Smiles tab — the details are filled in for you. Come back here and press this again for the next one.');
});

// The driver publishes its live status to storage every tick; show it here so the whole
// booking is watched from the console and the Smiles tab never has to be looked at.
async function renderLive() {
  const { ymLiveStatus: live } = await sGet('ymLiveStatus');
  const wrap = $('live');
  // stale (driver idle / tab closed) after ~15s
  if (!live || !live.text || (Date.now() - (live.at || 0) > 15000)) { wrap.style.display = 'none'; return; }
  wrap.style.display = 'block';
  $('liveText').textContent = live.text;
  $('liveSub').textContent = (live.left != null ? 'Session ' + live.left + ' min left · ' : '') + (live.loggedIn ? 'signed in' : 'signed out');
  const act = $('liveAction');
  if (live.need) {
    wrap.classList.add('need');
    act.innerHTML = '<button id="jump">👉 ' + esc(live.need) + ' — open the Smiles tab</button>';
    $('jump').onclick = openSmiles;
  } else {
    wrap.classList.remove('need');
    act.innerHTML = '';
  }
}

async function openSmiles() {
  // A compact window docked to the side — enough to click the captcha, not a full page to read.
  const tabs = await chrome.tabs.query({ url: '*://*.smiles.com.ar/*' });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    try {
      const sw = (window.screen && window.screen.availWidth) || 1280;
      await chrome.windows.update(tabs[0].windowId, { focused: true, state: 'normal', width: 480, height: 620, left: Math.max(0, sw - 500), top: 60 });
    } catch (e) {}
  } else {
    await chrome.windows.create({ url: 'https://www.smiles.com.ar/', type: 'normal', width: 480, height: 620, focused: true });
  }
}

function renderAutoToggle() {
  let b = document.getElementById('autoRunBtn');
  if (!b) {
    const bar = document.querySelector('.bar');
    if (!bar) return;
    b = document.createElement('button'); b.id = 'autoRunBtn'; b.className = 'ghost';
    b.addEventListener('click', () => { autoRun = !autoRun; try { localStorage.setItem('ymAutoRun', autoRun ? '1' : '0'); } catch (e) {} renderAutoToggle(); });
    bar.appendChild(b);
  }
  b.textContent = autoRun ? '⏸ auto-run ON' : '▶ auto-run OFF';
  b.style.background = autoRun ? 'rgba(74,222,128,.15)' : 'transparent';
  b.style.color = autoRun ? '#4ade80' : '#e6f0ff';
}

async function refresh() { await renderAccounts(); await renderOrders(); await renderLive(); renderAutoToggle(); await autoTick(); }
refresh();
setInterval(refresh, 2000);
