// Operator console. The piece between "the automation works" and "this is usable at scale":
// which accounts have a live session, what is queued, and which booking runs next.
//
// Everything lives in chrome.storage.local on this machine — the same store the driver reads —
// so the console and the booking driver are never out of step with each other.
const $ = (id) => document.getElementById(id);
const ACCTS = 'ymAccounts', ACTIVE = 'ymActiveAccount', ORDERS = 'ymOrders', TARGET = 'ymBookTarget', DRIVE = 'ymAutoDrive', CURRENT = 'ymCurrentOrder';
const sGet = (k) => new Promise(r => chrome.storage.local.get(k, (v) => r(v || {})));
const sSet = (o) => new Promise(r => chrome.storage.local.set(o, r));
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

$('ver').textContent = 'v' + chrome.runtime.getManifest().version;
setInterval(() => { $('clock').textContent = new Date().toLocaleTimeString(); }, 1000);

// A session's remaining minutes live in the Smiles tab's sessionStorage, which only that tab can
// read — so ask each open Smiles tab about itself rather than guessing from here.
async function tabSessions() {
  const out = {};
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: '*://*.smiles.com.ar/*' }); } catch (e) { return out; }
  await Promise.all(tabs.map(t => new Promise(res => {
    try {
      chrome.tabs.sendMessage(t.id, { ymWho: 1 }, (r) => {
        void chrome.runtime.lastError;
        if (r && r.loggedIn) out[t.id] = { tab: t, member: r.member || '', left: r.sessionLeftMin };
        res();
      });
    } catch (e) { res(); }
  })));
  return out;
}

function sessionPill(left) {
  if (left == null) return '<span class="pill bad">no session</span>';
  if (left <= 0) return '<span class="pill bad">expired</span>';
  if (left <= 5) return '<span class="pill warn">' + left + ' min left</span>';
  return '<span class="pill ok">' + left + ' min left</span>';
}

async function renderAccounts() {
  const { [ACCTS]: accts = [], [ACTIVE]: active } = await sGet([ACCTS, ACTIVE]);
  const live = await tabSessions();
  const byMember = {};
  Object.values(live).forEach(v => { if (v.member) byMember[String(v.member)] = v; });

  const sel = $('q_acct');
  sel.innerHTML = accts.length
    ? accts.map((a, i) => '<option value="' + esc(a.dni) + '"' + (a.dni === active ? ' selected' : '') + '>' + esc(a.name || a.dni) + '</option>').join('')
    : '<option value="">no accounts</option>';

  if (!accts.length) return;
  $('accounts').innerHTML = accts.map(a => {
    const s = byMember[String(a.member || '')] || null;
    const left = s ? s.left : null;
    return '<div class="row">' +
      '<div class="grow"><div class="name">' + esc(a.name || a.dni) + '</div>' +
      '<div class="sub">' + esc(a.dni) + (a.cardName ? ' · card: ' + esc(a.cardName) : '') + '</div></div>' +
      sessionPill(left) +
      '<button class="ghost" data-signin="' + esc(a.dni) + '">' + (left > 0 ? 'Switch to' : 'Sign in') + '</button>' +
      '</div>';
  }).join('');

  document.querySelectorAll('[data-signin]').forEach(b => {
    b.addEventListener('click', () => signIn(b.getAttribute('data-signin')));
  });
}

// Make this the account bookings run on, then open Smiles so the login panel fills it. The
// captcha is the only part left — it has to be ticked on the page it belongs to.
async function signIn(dni) {
  // Focusing the tab is not enough: the login is a modal that has to be opened. Leave a request
  // the driver picks up, so it clicks "Iniciá sesión" and the panel fills the account in.
  await sSet({ [ACTIVE]: dni, ymLoginRequest: { dni: dni, at: Date.now() } });
  const tabs = await chrome.tabs.query({ url: '*://*.smiles.com.ar/*' });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    try { await chrome.windows.update(tabs[0].windowId, { focused: true }); } catch (e) {}
  } else {
    await chrome.tabs.create({ url: 'https://www.smiles.com.ar/', active: true });
  }
}

async function renderOrders() {
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  const { [ACCTS]: accts = [] } = await sGet(ACCTS);
  const nameOf = (dni) => { const a = accts.find(x => x.dni === dni); return a ? (a.name || a.dni) : (dni || '—'); };
  if (!orders.length) { $('orders').innerHTML = '<div class="empty">Nothing queued.</div>'; return; }
  $('orders').innerHTML = orders.map(o =>
    '<div class="row">' +
    '<div class="grow"><div class="name">' + esc(o.origin) + ' → ' + esc(o.destination) + ' · ' + esc(o.dep || '') + '</div>' +
    '<div class="sub">' + esc(o.date) + ' · ' + esc(o.cabin) + ' · ' + (o.miles || []).join('–') + ' mi · ' + esc(nameOf(o.account)) + '</div></div>' +
    '<span class="pill ' + (o.status === 'done' ? 'ok' : o.status === 'failed' ? 'bad' : 'warn') + '">' + esc(o.status || 'queued') + '</span>' +
    (o.status === 'payment' || o.status === 'booking'
      ? '<button data-done="' + esc(o.id) + '">Done → next</button>'
      : '<button data-book="' + esc(o.id) + '">Book</button>') +
    '<button class="ghost" data-del="' + esc(o.id) + '">✕</button>' +
    '</div>').join('');

  document.querySelectorAll('[data-book]').forEach(b => b.addEventListener('click', () => bookOrder(b.getAttribute('data-book'))));
  document.querySelectorAll('[data-done]').forEach(b => b.addEventListener('click', () => finishOrder(b.getAttribute('data-done'))));
  document.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    const { [ORDERS]: list = [] } = await sGet(ORDERS);
    await sSet({ [ORDERS]: list.filter(x => x.id !== b.getAttribute('data-del')) });
    renderOrders();
  }));
}

// Hand one order to the driver: make its account the active one, arm the flight, focus Smiles.
// From there it is the flow already built — restart from home, search, flight, fare, passenger.
async function bookOrder(id) {
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  const o = orders.find(x => x.id === id);
  if (!o) return;
  if (o.account) await sSet({ [ACTIVE]: o.account });
  await sSet({
    [TARGET]: {
      origin: o.origin, destination: o.destination, date: o.date, dep: o.dep,
      cabin: o.cabin, miles: o.miles || [], adults: o.adults || 1,
      summary: o.origin + ' ' + (o.dep || '') + ' → ' + o.destination + ' ' + o.date
    },
    [DRIVE]: { on: true, startedAt: Date.now() }
  });
  o.status = 'booking';
  await sSet({ [ORDERS]: orders, [CURRENT]: o.id });
  renderOrders();
  const tabs = await chrome.tabs.query({ url: '*://*.smiles.com.ar/*' });
  if (tabs.length) { await chrome.tabs.update(tabs[0].id, { active: true }); try { await chrome.windows.update(tabs[0].windowId, { focused: true }); } catch (e) {} }
  else await chrome.tabs.create({ url: 'https://www.smiles.com.ar/', active: true });
}

// Mark the running order finished and start the next one waiting on the SAME account — that
// account already has a live session, so the next booking costs no captcha at all. This is the
// whole point of batching by account.
async function finishOrder(id) {
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  const o = orders.find(x => x.id === id);
  if (o) { o.status = 'done'; o.at = Date.now(); }
  await sSet({ [ORDERS]: orders, [CURRENT]: '' });
  const next = orders.find(x => x.status === 'queued' && (!o || x.account === o.account));
  await renderOrders();
  if (next) { await bookOrder(next.id); return; }
  const other = orders.find(x => x.status === 'queued');
  if (other) alert('Done. The next queued booking is on a different account — press Book on it when you are ready to switch.');
}

// The driver matches a flight row by its departure written as Smiles writes it — "15h15". A
// date input already gives us YYYY-MM-DD; the time needs converting, including from 12-hour,
// because "3:15 pm" matched nothing and the booking failed with "no search date".
function normDep(t) {
  if (!t) return '';
  const m = String(t).match(/(\d{1,2})\s*[:h.]?\s*(\d{2})?\s*(am|pm)?/i);
  if (!m) return '';
  let h = parseInt(m[1], 10);
  const min = m[2] || '00';
  const ap = (m[3] || '').toLowerCase();
  if (ap === 'pm' && h < 12) h += 12;
  if (ap === 'am' && h === 12) h = 0;
  return String(h).padStart(2, '0') + 'h' + min;
}

$('add').addEventListener('click', async () => {
  const v = (id) => ($(id).value || '').trim();
  if (!v('q_origin') || !v('q_dest') || !v('q_date')) { alert('Need at least From, To and Date.'); return; }
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  orders.push({
    id: 'o' + Date.now().toString(36),
    origin: v('q_origin').toUpperCase(), destination: v('q_dest').toUpperCase(),
    date: v('q_date'), dep: normDep(v('q_dep')), cabin: $('q_cabin').value,
    miles: v('q_miles') ? v('q_miles').split(/[^0-9]+/).filter(Boolean).map(Number) : [],
    account: $('q_acct').value, adults: 1, status: 'queued', createdAt: Date.now()
  });
  await sSet({ [ORDERS]: orders });
  ['q_origin', 'q_dest', 'q_date', 'q_dep', 'q_miles'].forEach(id => { $(id).value = ''; });
  renderOrders();
});

$('openSmiles').addEventListener('click', openSmiles);

// Walk the accounts that queued work needs and that have no live session, one at a time. Each
// opens pre-filled; you tick its captcha and the next follows. That is the batching that makes
// the hourly login cost bearable across a pool of accounts.
$('signAll').addEventListener('click', async () => {
  const { [ORDERS]: orders = [] } = await sGet(ORDERS);
  const { [ACCTS]: accts = [] } = await sGet(ACCTS);
  const live = await tabSessions();
  const haveMembers = Object.values(live).map(v => String(v.member || ''));
  const needed = [...new Set(orders.filter(o => o.status !== 'done').map(o => o.account).filter(Boolean))];
  const list = (needed.length ? needed : accts.map(a => a.dni))
    .filter(dni => { const a = accts.find(x => x.dni === dni); return a && haveMembers.indexOf(String(a.member || '')) === -1; });
  if (!list.length) { alert('Every account you need already has a live session.'); return; }
  await signIn(list[0]);
  alert('Signing in ' + list.length + ' account' + (list.length === 1 ? '' : 's') + '.\n\nTick the captcha on the Smiles tab — the details are filled in for you. Come back here and press this again for the next one.');
});

// The driver publishes its live status to storage every tick; show it here so the whole
// booking is watched from the console and the Smiles tab never has to be looked at.
async function renderLive() {
  const { ymLiveStatus: live } = await sGet('ymLiveStatus');
  const wrap = $('liveWrap');
  // stale (driver idle / tab closed) after ~15s
  if (!live || !live.text || (Date.now() - (live.at || 0) > 15000)) { wrap.style.display = 'none'; return; }
  wrap.style.display = 'block';
  $('liveText').textContent = live.text;
  $('liveSub').textContent = (live.left != null ? 'Session ' + live.left + ' min left · ' : '') + (live.loggedIn ? 'signed in' : 'signed out');
  const act = $('liveAction');
  if (live.need) {
    wrap.style.borderColor = '#fbbf24';
    act.innerHTML = '<button id="jump" style="background:#f59e0b;color:#111">👉 ' + esc(live.need) + ' — open the Smiles tab</button>';
    $('jump').onclick = openSmiles;
  } else {
    wrap.style.borderColor = '#223355';
    act.innerHTML = '';
  }
}

async function openSmiles() {
  const tabs = await chrome.tabs.query({ url: '*://*.smiles.com.ar/*' });
  if (tabs.length) { await chrome.tabs.update(tabs[0].id, { active: true }); try { await chrome.windows.update(tabs[0].windowId, { focused: true }); } catch (e) {} }
  else await chrome.tabs.create({ url: 'https://www.smiles.com.ar/', active: true });
}

async function refresh() { await renderAccounts(); await renderOrders(); await renderLive(); }
refresh();
setInterval(refresh, 2000);
