// Opens a background Smiles tab, lets the site run its own search, collects the
// flights, optionally verifies each one's real seats (boardingtax) in the same
// tab/session, then closes the tab.
const waiters = {}; // tabId -> resolver for the search flights
const sleep = ms => new Promise(r => setTimeout(r, ms));

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'search') { runSearch(msg.params).then(sendResponse); return true; }
  if (msg.type === 'flights' && sender.tab && waiters[sender.tab.id]) waiters[sender.tab.id](msg);
});

function emissionUrl(p) {
  const q = new URLSearchParams({
    originAirportCode: p.origin, destinationAirportCode: p.destination, departureDate: p.date,
    adults: String(p.adults || 1), children: '0', infants: '0',
    isFlexibleDateChecked: 'false', tripType: '2', cabinType: 'all', currencyCode: 'ARS'
  });
  return 'https://www.smiles.com.ar/emission?' + q.toString();
}

function verifyInTab(tabId, f, adults) {
  return new Promise(resolve => {
    try {
      chrome.tabs.sendMessage(tabId, { ymVerify: { uid: f.uid, fareUid: f.fareUid, type: f.type, adults: adults || 1 } }, resp => {
        if (chrome.runtime.lastError) { resolve({ ok: false }); return; }
        resolve(resp || { ok: false });
      });
    } catch (e) { resolve({ ok: false }); }
  });
}

async function runSearch(params) {
  let tab;
  try { tab = await chrome.tabs.create({ url: emissionUrl(params), active: false }); }
  catch (e) { return { ok: false, error: 'Could not open Smiles tab: ' + e.message }; }

  const result = await new Promise(resolve => {
    let done = false, acc = [], rawTotal = 0, msgs = 0, settle = null;
    const finish = () => {
      if (done) return; done = true; delete waiters[tab.id];
      // Same flight+cabin can arrive at two prices (real award vs pricier congener) —
      // keep the CHEAPEST, which is what the site shows you.
      const best = {};
      acc.forEach(f => {
        const k = [f.origin, f.departure, f.destination, f.classType, f.stopover ? f.stopover.airport : ''].join('|');
        const mi = f.milesClub || f.miles || 1e9;
        const cur = best[k];
        if (!cur || mi < (cur.milesClub || cur.miles || 1e9)) best[k] = f;
      });
      resolve({ flights: Object.values(best), rawCount: rawTotal, msgs: msgs });
    };
    waiters[tab.id] = m => {
      if (done) return;
      msgs++;
      rawTotal += (m.rawCount || 0);
      if (m.flights && m.flights.length) {          // a response WITH flights keeps the window open;
        acc = acc.concat(m.flights);                 // early empty responses are ignored so we keep waiting
        if (settle) clearTimeout(settle);
        settle = setTimeout(finish, 9000);           // wait for the slower award query before finishing
      }
    };
    setTimeout(() => { if (done) return; done = true; delete waiters[tab.id]; resolve({ flights: [], rawCount: rawTotal, msgs: msgs }); }, 60000);
  });

  if (!result) { chrome.tabs.remove(tab.id).catch(() => {}); return { ok: false, error: 'Timed out — no search response (are you logged into Smiles?)' }; }
  const flights = result.flights || [];
  const rawCount = result.rawCount || 0;

  if (params.verify) {
    const deep = !!params.deep;
    const cap = deep ? 40 : 12;
    let n = 0;
    for (const f of flights) {
      if (!f.uid || !f.fareUid) continue;
      // American Airlines is the only carrier with the phantom-seat problem;
      // Air Canada etc. are trusted, so we never spend a confirm-call on them.
      if (!/American/i.test(f.airline || '')) continue;
      const isDirect = !f.stopover;
      // Smart = AA DIRECT flights under the mileage ceiling only — never stopovers, never
      // near-cash-price fares (those would be 50+ pointless checks). Deep = all AA flights.
      if (!(deep || isDirect)) continue;
      const mi = f.milesClub || f.miles || 0;
      if (!deep && mi > (params.verifyMaxMiles || 100000)) continue;
      if (n++ >= cap) break;
      let r = await verifyInTab(tab.id, f, params.adults);
      // A 452 is either a transient rate-limit OR the fare is genuinely gone.
      // Retry once after a pause: a rate-limit clears -> 200; a truly-gone fare stays 452.
      if (r && r.status === 452) { await sleep(1600); r = await verifyInTab(tab.id, f, params.adults); }
      else if (r && !r.ok) { await sleep(1200); r = await verifyInTab(tab.id, f, params.adults); }
      f.confirmedSeats = (r && r.ok) ? r.seats : null;
      f.verifyStatus = r ? (r.status || null) : null;
      // 200 = real & available; persistent 452 = phantom/gone; anything else = unknown.
      f.available = r ? (r.ok ? true : (r.status === 452 ? false : null)) : null;
      await sleep(500);
    }
  }

  chrome.tabs.remove(tab.id).catch(() => {});
  return { ok: true, flights, rawCount };
}
