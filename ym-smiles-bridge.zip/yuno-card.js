// Runs INSIDE Yuno's card frames (sdk-web-card.prod.y.uno), one instance per secure field.
//
// The card number, expiry and CVV each live in their own cross-origin frame, which is exactly the
// point of that design: nothing in Smiles' page can read or write them. A content script is not in
// Smiles' page though — the extension is granted that origin directly, so it runs INSIDE the frame
// with ordinary DOM access. This is the same mechanism a password manager uses to fill a card.
//
// Each frame holds exactly ONE field and its URL says which, so an instance only ever fills its
// own. Nothing is stored here and nothing is read back out; the value arrives, goes into the input,
// and that is the end of it. Pressing Pagar is still the operator's.
(() => {
  const m = /secure-field\/([a-z-]+)/i.exec(location.href || '');
  const field = m ? m[1].toLowerCase() : '';
  if (!field || field === 'mediator') return;          // the mediator frame holds no input

  // Yuno's inputs are React-controlled, so assigning .value is ignored — React tracks its own
  // copy. Going through the native setter and then firing 'input' is what makes React accept it.
  function setNative(el, value) {
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = Object.getOwnPropertyDescriptor(proto, 'value');
      if (desc && desc.set) desc.set.call(el, value); else el.value = value;
    } catch (e) { el.value = value; }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function fill(value) {
    let el = null;
    try {
      el = [...document.querySelectorAll('input')].find(i => i.type !== 'hidden' && !i.disabled);
    } catch (e) {}
    if (!el) return { ok: false, why: 'no input in this frame yet' };
    if ((el.value || '').trim()) return { ok: true, why: 'already filled' };
    el.focus();
    setNative(el, String(value));
    return { ok: !!(el.value || '').trim(), why: (el.value || '').trim() ? '' : 'the field did not take it' };
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== 'ymFillCard') return;
    const value = { 'pan': msg.number, 'expiration-date': msg.exp, 'cvv': msg.cvv }[field];
    if (!value) return;                                 // nothing saved for this field — leave it
    const r = fill(value);
    // Report the OUTCOME only — which field, whether it took. Never the value.
    try { chrome.runtime.sendMessage({ type: 'ymCardFilled', field: field, ok: r.ok, why: r.why }); } catch (e) {}
  });
})();
